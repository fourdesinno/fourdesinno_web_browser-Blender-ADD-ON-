bl_info = {
    "name": "FOURDESINNO ASSET BROWSER",
    "author": "FOURDESINNO",
    "version": (1, 1, 9),
    "blender": (5, 0, 0),
    "location": "View3D",
    "description": "Browse FOURDESINNO assets in a viewport strip.",
    "category": "Import-Export",
}

def register():
    from . import core
    core.register()

def unregister():
    from . import core
    core.unregister()
