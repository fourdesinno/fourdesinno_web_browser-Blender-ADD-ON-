bl_info = {
    "name": "FOURDESINNO ASSET BROWSER",
    "author": "FOURDESINNO",
    "version": (1, 0, 24),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > FOURDESINNO",
    "description": "Browse FOURDESINNO assets in a viewport strip, drag a placeholder into the scene, and download cached .blend files after placement.",
    "category": "Import-Export",
}

from .core import register, unregister