import os

PACKAGE_NAME = __package__ or "fourdesinno_asset_browser"
ADDON_ROOT = os.path.dirname(__file__)


def _ensure(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def _extension_user_root() -> str:
    """Return a user-writable directory for extension data (works for read-only installs)."""
    try:
        import bpy  # type: ignore
        fn = getattr(getattr(bpy, "utils", None), "extension_path_user", None)
        if callable(fn):
            # Blender creates/manages this folder for the extension.
            return _ensure(fn(PACKAGE_NAME, path="", create=True))
    except Exception:
        pass

    # Fallback for older/legacy setups: keep data next to the addon (may be read-only in Extensions repos).
    return _ensure(os.path.join(ADDON_ROOT, ".fourdesinno_user"))


def default_asset_storage_dir() -> str:
    return _ensure(os.path.join(_extension_user_root(), "downloaded_assets"))


def default_preview_cache_dir() -> str:
    return _ensure(os.path.join(_extension_user_root(), "preview_cache"))


def default_user_data_dir() -> str:
    return _ensure(os.path.join(_extension_user_root(), "user_data"))
