import bpy
import blf
import gpu
from gpu_extras.batch import batch_for_shader
from gpu_extras.presets import draw_texture_2d

import json
import filecmp
import os
import re
import shutil
import tempfile
import threading
import urllib.parse
import urllib.request
import subprocess
import sys
import time
import math
from collections import deque
from html.parser import HTMLParser
try:
    from PIL import Image
except Exception:
    Image = None

from bpy.props import BoolProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import AddonPreferences, Operator, PropertyGroup
from bpy_extras import view3d_utils
from bpy.app.handlers import persistent
from mathutils import Vector
from mathutils.geometry import intersect_line_plane
from .package_info import PACKAGE_NAME, ADDON_ROOT, default_asset_storage_dir, default_preview_cache_dir, default_user_data_dir

ADDON_ID = "fourdesinno_asset_browser"
FOURDESINNO_SITE = "https://www.fourdesinno.com"
USER_AGENT = "FOURDESINNO-Asset-Browser/1.0.24"
UPDATE_INFO_URL = FOURDESINNO_SITE + "/wp-json/fourdesinno/v1/asset-browser-update"
UPDATE_CHECK_DELAY = 4.0
UPDATE_DOWNLOAD_TIMEOUT = 180
REQUEST_TIMEOUT = 45
AUTO_LOAD_BATCH = 12
AUTO_LOAD_PAGE_SCAN = 48
DRAW_HANDLE = None
STATE_LOCK = threading.Lock()

STATE = {
    "assets": [],
    "status": "Idle.",
    "preview_dir": "",
    "modal_running": False,
    "active_asset_id": "",
    "dragging": False,
    "drag_from_strip": False,
    "drag_hover_index": -1,
    "strip_area_pointer": None,
    "strip_window_pointer": None,
    "strip_move_dragging": False,
    "strip_move_hover_area": None,
    "download": {
        "title": "",
        "phase": "",
        "bytes_done": 0,
        "bytes_total": 0,
        "percent": 0,
    },
    "next_page": 1,
    "has_more": True,
    "loading_more": False,
    "asset_type": "model",
    "search_editing": False,
    "search_buffer": "",
    "pending_assets": [],
    "favorites_only": False,
    "downloaded_only": False,
    "browse_snapshot": None,
    "favorites": set(),
    "thumb_queue": [],
    "asset_catalog_by_type": {"model": {}, "texture": {}, "hdri": {}},
    "asset_catalog_complete_by_type": {"model": False, "texture": False, "hdri": False},
    "category_terms": [],
    "category_usage_by_type": {},
    "category_count_by_type": {},
    "dropdown_open": "",
    "dropdown_hover_kind": "",
    "dropdown_hover_id": "",
    "dropdown_hover_parent_id": "",
    "settings_open": False,
    "settings_panel": {},
    "settings_anchor_x2": 0,
    "settings_edit_kind": "",
    "settings_edit_buffer": "",
    "update_checked": False,
    "update_popup_version": "",
    "update_info": {},
    "update_panel_open": False,
    "update_deferred_version": "",
    "online_mode": True,
}

IMAGE_CACHE = {}
GPU_TEXTURE_CACHE = {}

PREVIEW_BG_BOTTOM = (0.82, 0.82, 0.82, 1.0)
PREVIEW_BG_TOP = (0.88, 0.88, 0.88, 1.0)

UI_STRIP_BG = (0.965, 0.965, 0.970, 0.96)
UI_STRIP_OUTLINE = (0.78, 0.78, 0.80, 1.0)
UI_BUTTON_BG = (0.94, 0.94, 0.95, 1.0)
UI_BUTTON_OUTLINE = (0.70, 0.70, 0.73, 1.0)
UI_BUTTON_ACTIVE = (0.2117647059, 0.4470588235, 0.7764705882, 1.0)
UI_BUTTON_ACTIVE_ALT = (0.2117647059, 0.4470588235, 0.7764705882, 1.0)
UI_TEXT_DARK = (0.12, 0.12, 0.14, 1.0)
UI_TEXT_MUTED = (0.45, 0.45, 0.49, 1.0)
UI_TOP_BORDER_1 = (0.3333333333, 0.3333333333, 0.3333333333, 1.0)  # #555555
UI_TOP_BORDER_2 = (0.2549019608, 0.2549019608, 0.2549019608, 1.0)  # #414141
UI_SLOT_OUTLINE = UI_BUTTON_OUTLINE
UI_MORE_BG = (0.92, 0.92, 0.94, 0.95)
UI_MORE_OUTLINE = (0.72, 0.72, 0.75, 1.0)

# ---------------------------------------------------------
# updater
# ---------------------------------------------------------


def _update_state_file_path():
    return os.path.join(default_user_data_dir(), "addon_update_state.json")


def _load_update_state_file():
    path = _update_state_file_path()
    try:
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_update_state_file(data):
    path = _update_state_file_path()
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data if isinstance(data, dict) else {}, handle, indent=2)
    except Exception:
        pass

def _external_update_state_path():
    return os.path.join(_external_update_runtime_dir(), "pending_update.json")


def _load_external_update_state():
    path = _external_update_state_path()
    try:
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_external_update_state(data):
    path = _external_update_state_path()
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data if isinstance(data, dict) else {}, handle, indent=2)
    except Exception:
        pass


def _clear_external_update_state():
    path = _external_update_state_path()
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def _helper_python_executable():
    candidates = []

    current_exe = str(getattr(sys, "executable", "") or "").strip()
    if current_exe and os.path.basename(current_exe).lower().startswith("python") and os.path.exists(current_exe):
        candidates.append(current_exe)

    for prefix in [getattr(sys, "prefix", ""), getattr(sys, "base_prefix", ""), getattr(sys, "exec_prefix", "")]:
        prefix = str(prefix or "").strip()
        if not prefix:
            continue
        if os.name == "nt":
            candidates.extend([
                os.path.join(prefix, "python.exe"),
                os.path.join(prefix, "bin", "python.exe"),
                os.path.join(prefix, "Scripts", "python.exe"),
                os.path.join(prefix, "bin", "pythonw.exe"),
            ])
        else:
            candidates.extend([
                os.path.join(prefix, "bin", "python3"),
                os.path.join(prefix, "bin", "python"),
            ])

    blender_bin = str(getattr(bpy.app, "binary_path", "") or "").strip()
    if blender_bin:
        base_dir = os.path.dirname(blender_bin)
        if os.name == "nt":
            for rel in [
                os.path.join("5.0", "python", "bin", "python.exe"),
                os.path.join("5.0", "python", "bin", "pythonw.exe"),
                os.path.join("python", "bin", "python.exe"),
                os.path.join("python", "bin", "pythonw.exe"),
            ]:
                candidates.append(os.path.join(base_dir, rel))
        else:
            for rel in [
                os.path.join("5.0", "python", "bin", "python3"),
                os.path.join("python", "bin", "python3"),
                os.path.join("python", "bin", "python"),
            ]:
                candidates.append(os.path.join(base_dir, rel))

    seen = set()
    for candidate in candidates:
        candidate = os.path.normpath(str(candidate or "").strip())
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        if os.path.exists(candidate):
            return candidate

    if current_exe and os.path.exists(current_exe):
        return current_exe
    raise RuntimeError("Python interpreter for update helper was not found.")


def _get_ignored_update_version():
    return str((_load_update_state_file() or {}).get("ignored_version") or "").strip()


def _set_ignored_update_version(version_text):
    data = _load_update_state_file()
    if str(version_text or "").strip():
        data["ignored_version"] = str(version_text).strip()
    else:
        data.pop("ignored_version", None)
    _save_update_state_file(data)


def _local_addon_version():
    try:
        mod = __import__(PACKAGE_NAME)
        info = getattr(mod, "bl_info", {}) if mod is not None else {}
        version = info.get("version", (0, 0, 0))
        return tuple(int(v) for v in version)
    except Exception:
        return (0, 0, 0)


def _version_to_text(version):
    try:
        return ".".join(str(int(v)) for v in tuple(version or (0, 0, 0)))
    except Exception:
        return "0.0.0"


def _parse_version_value(value):
    try:
        if isinstance(value, (list, tuple)):
            parts = [int(v) for v in value]
        else:
            parts = [int(v) for v in re.findall(r"\d+", str(value or ""))]
        if not parts:
            return ()
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts[:3])
    except Exception:
        return ()


def _invoke_update_prompt():
    try:
        wm = bpy.context.window_manager
        if wm is None:
            return None
        for window in wm.windows:
            screen = window.screen
            if not screen:
                continue
            try:
                with bpy.context.temp_override(window=window, screen=screen):
                    result = bpy.ops.fourdesinno.update_prompt('INVOKE_DEFAULT')
                if result == {'RUNNING_MODAL'} or result == {'FINISHED'}:
                    return None
            except Exception:
                continue
    except Exception:
        pass
    return None


def _check_for_updates_once(force=False):
    if not _online_mode_enabled():
        return None
    update_url = str(UPDATE_INFO_URL or "").strip()
    if not update_url:
        return None

    with STATE_LOCK:
        if STATE.get("update_checked") and not force:
            return None
        STATE["update_checked"] = True

    try:
        payload = _request_json(update_url)
    except Exception:
        return None

    if not isinstance(payload, dict):
        return None
    if str(payload.get("enabled", True)).lower() in {"0", "false", "no"}:
        return None

    latest_raw = payload.get("version") or payload.get("latest_version") or ""
    latest_version = _parse_version_value(latest_raw)
    if not latest_version:
        return None

    current_version = _local_addon_version()
    latest_text = _version_to_text(latest_version)
    download_url = str(payload.get("download_url") or payload.get("url") or "").strip()
    message = str(payload.get("message") or "Update ready!").strip()
    changelog_url = str(payload.get("changelog_url") or "").strip()

    with STATE_LOCK:
        STATE["update_info"] = {
            "latest_version": latest_text,
            "download_url": download_url,
            "message": message,
            "changelog_url": changelog_url,
        }

    if latest_version <= current_version:
        _set_ignored_update_version("")
        return None

    ignored_version = _get_ignored_update_version()
    with STATE_LOCK:
        deferred_version = str(STATE.get("update_deferred_version", "") or "")

    if not force and ignored_version == latest_text:
        return None
    if not force and deferred_version == latest_text:
        return None

    with STATE_LOCK:
        if str(STATE.get("update_popup_version", "") or "") == latest_text and not force:
            return None
        STATE["update_popup_version"] = latest_text

    try:
        pass  # Update prompt handled by in-strip UPDATE AVAILABLE button.
    except Exception:
        try:
            pass  # Update prompt handled by in-strip UPDATE AVAILABLE button.
        except Exception:
            pass
    return None


def _schedule_update_check(delay=None, force=False):
    first_interval = float(delay if delay is not None else UPDATE_CHECK_DELAY)

    def _deferred():
        return _check_for_updates_once(force=force)

    try:
        bpy.app.timers.register(_deferred, first_interval=max(0.1, first_interval))
    except Exception:
        try:
            _check_for_updates_once(force=force)
        except Exception:
            pass


def _process_completed_staged_update_notice():
    state = _load_external_update_state()
    status = str(state.get("status") or "").strip().lower()
    if status == "applied":
        latest_version = str(state.get("latest_version") or "").strip()
        _clear_external_update_state()
        _set_status(f"Addon updated to {latest_version or 'new version'}.")
        _show_update_result_popup("FOURDESINNO Update Complete", [f"Addon updated to {latest_version or 'the new version'}."], icon='CHECKMARK')
    elif status == "failed":
        last_error = str(state.get("last_error") or "Update failed.").strip()
        _set_status(f"Addon update failed: {last_error}")


def _download_update_zip(download_url, latest_version_text=""):
    download_url = str(download_url or "").strip()
    if not download_url:
        raise RuntimeError("No update ZIP URL was provided by the website.")

    req = urllib.request.Request(download_url, headers={"User-Agent": USER_AGENT, "Accept": "application/zip, application/octet-stream, */*"})
    with urllib.request.urlopen(req, timeout=UPDATE_DOWNLOAD_TIMEOUT) as response:
        suffix = os.path.splitext(urllib.parse.urlparse(response.geturl()).path)[1].lower()
        if suffix != ".zip":
            suffix = ".zip"
        handle = tempfile.NamedTemporaryFile(delete=False, suffix=suffix, prefix=f"fourdesinno_update_{_sanitize_filename(latest_version_text or 'latest', 'latest')}_")
        temp_path = handle.name
        try:
            with handle:
                shutil.copyfileobj(response, handle)
        except Exception:
            try:
                os.remove(temp_path)
            except Exception:
                pass
            raise
    return temp_path





def _merge_tree_skip_existing(src, dst):
    if not os.path.isdir(src):
        return
    os.makedirs(dst, exist_ok=True)
    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        target_root = os.path.join(dst, rel) if rel != "." else dst
        os.makedirs(target_root, exist_ok=True)
        for d in dirs:
            os.makedirs(os.path.join(target_root, d), exist_ok=True)
        for f in files:
            s = os.path.join(root, f)
            t = os.path.join(target_root, f)
            if os.path.exists(t):
                continue
            try:
                shutil.copy2(s, t)
            except Exception:
                pass


def _cleanup_legacy_old_addon_folder():
    """Remove legacy <addon>_old folder left behind by earlier updater builds.
    Preserves downloaded_assets, preview_cache and user_data by merging into the current addon folder first.
    """
    try:
        addon_root = os.path.dirname(__file__)
        old_root = addon_root + "_old"
        if not os.path.isdir(old_root):
            return
        for folder_name in ("downloaded_assets", "preview_cache", "user_data"):
            src = os.path.join(old_root, folder_name)
            dst = os.path.join(addon_root, folder_name)
            _merge_tree_skip_existing(src, dst)
        shutil.rmtree(old_root, ignore_errors=True)
    except Exception:
        pass

def _external_update_runtime_dir():
    path = os.path.join(tempfile.gettempdir(), f"{PACKAGE_NAME}_updater_runtime")
    os.makedirs(path, exist_ok=True)
    return path


def _write_external_update_helper(zip_path, latest_version_text=""):
    if not zip_path or not os.path.exists(zip_path):
        raise RuntimeError("Downloaded update ZIP was not found.")

    runtime_dir = _external_update_runtime_dir()
    helper_path = os.path.join(runtime_dir, "apply_update.py")
    helper_code = r"""import json
import os
import shutil
import sys
import tempfile
import time
import traceback
import zipfile


def _load_json(path):
    try:
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data if isinstance(data, dict) else {}, handle, indent=2)
    except Exception:
        pass


def _write_log(log_path, message):
    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as handle:
            handle.write(str(message) + "\n")
    except Exception:
        pass


def _safe_rmtree(path):
    if not path or not os.path.exists(path):
        return
    shutil.rmtree(path, ignore_errors=True)


def _is_addon_package_dir(path):
    if not os.path.isdir(path):
        return False
    return os.path.isfile(os.path.join(path, "__init__.py")) and os.path.isfile(os.path.join(path, "core.py"))


def _find_package_root(extract_root, package_name):
    direct = os.path.join(extract_root, package_name)
    if _is_addon_package_dir(direct):
        return direct

    for root, _dirs, _files in os.walk(extract_root):
        if os.path.basename(root) == package_name and _is_addon_package_dir(root):
            return root

    for root, _dirs, _files in os.walk(extract_root):
        if _is_addon_package_dir(root):
            return root

    return ""


def _copytree_overwrite(src, dst, exclude_names):
    if not os.path.isdir(src):
        return
    os.makedirs(dst, exist_ok=True)
    for name in os.listdir(src):
        if name in exclude_names:
            continue
        sp = os.path.join(src, name)
        dp = os.path.join(dst, name)

        # Never copy pycache from update zips
        if name == "__pycache__":
            continue

        try:
            if os.path.isdir(sp):
                os.makedirs(dp, exist_ok=True)
                _copytree_overwrite(sp, dp, exclude_names)
            else:
                os.makedirs(os.path.dirname(dp), exist_ok=True)
                # overwrite in place
                shutil.copy2(sp, dp)
        except Exception:
            # keep going; log at a higher level if needed
            raise


def main():
    if len(sys.argv) < 8:
        raise RuntimeError("Updater helper arguments are incomplete.")

    zip_path = sys.argv[1]
    addon_root = sys.argv[2]
    package_name = sys.argv[3]
    runtime_dir = sys.argv[4]
    _wait_pid = sys.argv[5]  # kept for backwards compatibility, not used
    state_path = sys.argv[6]
    latest_version = sys.argv[7] if len(sys.argv) > 7 else ""

    os.makedirs(runtime_dir, exist_ok=True)
    log_path = os.path.join(runtime_dir, "update_log.txt")

    _write_log(log_path, f"Starting helper for {package_name} -> {latest_version}")

    state = _load_json(state_path)
    state.update({"status": "applying", "latest_version": latest_version, "zip_path": zip_path, "addon_root": addon_root})
    _save_json(state_path, state)

    extract_root = tempfile.mkdtemp(prefix=f"{package_name}_extract_", dir=runtime_dir)
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_root)

        new_root = _find_package_root(extract_root, package_name)
        if not new_root:
            raise RuntimeError("Addon package folder was not found in the update ZIP.")

        # Apply update in-place to avoid rename failures when downloaded_assets is locked.
        os.makedirs(addon_root, exist_ok=True)

        exclude = {
            "downloaded_assets",
            "user_data",
            "preview_cache",
            ".fourdesinno_user",
        }

        _copytree_overwrite(new_root, addon_root, exclude)

        state.update({"status": "applied", "latest_version": latest_version, "last_error": ""})
        _save_json(state_path, state)
        _write_log(log_path, "Update applied successfully")
    except Exception as exc:
        _write_log(log_path, traceback.format_exc())
        state.update({"status": "failed", "latest_version": latest_version, "last_error": str(exc)})
        _save_json(state_path, state)
    finally:
        _safe_rmtree(extract_root)
        try:
            if os.path.exists(zip_path):
                os.remove(zip_path)
        except Exception:
            pass


if __name__ == "__main__":
    main()
"""
    try:
        with open(helper_path, "w", encoding="utf-8") as handle:
            handle.write(helper_code)
    except Exception as exc:
        raise RuntimeError(f"Could not write external update helper: {exc}")
    return helper_path

def _launch_external_update_helper(zip_path, latest_version_text=""):
    runtime_dir = _external_update_runtime_dir()
    state_path = _external_update_state_path()
    helper_path = _write_external_update_helper(zip_path, latest_version_text=latest_version_text)
    python_bin = _helper_python_executable()
    # Avoid launching multiple concurrent helpers (can happen if Update Now is clicked repeatedly).
    try:
        existing = _load_external_update_state()
        if str(existing.get("status") or "").strip().lower() in {"waiting", "staged"}:
            return str(existing.get("helper_path") or helper_path)
    except Exception:
        pass


    state = _load_external_update_state()
    state.update({
        "status": "staged",
        "latest_version": str(latest_version_text or "").strip(),
        "zip_path": zip_path,
        "helper_path": helper_path,
        "runtime_dir": runtime_dir,
        "addon_root": ADDON_ROOT,
        "package_name": PACKAGE_NAME,
        "wait_pid": int(os.getpid()),
        "updated_at": time.time(),
    })
    _save_external_update_state(state)

    argv = [python_bin, helper_path, zip_path, ADDON_ROOT, PACKAGE_NAME, runtime_dir, str(os.getpid()), state_path, str(latest_version_text or "").strip()]
    kwargs = {
        "cwd": runtime_dir,
        "close_fds": True,
    }
    if os.name == "nt":
        kwargs["creationflags"] = (
            getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )
    try:
        subprocess.Popen(argv, **kwargs)
    except Exception as exc:
        raise RuntimeError(f"Could not launch external update helper: {exc}")
    return helper_path


def _schedule_blender_restart_for_update(delay=0.8):
    return None


def _show_update_result_popup(title, lines, icon='INFO'):
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return
    text_lines = [str(line or "").strip() for line in (lines or []) if str(line or "").strip()]

    def _draw(self, context):
        layout = self.layout
        for line in text_lines:
            layout.label(text=line)

    try:
        wm.popup_menu(_draw, title=str(title or "FOURDESINNO Update"), icon=icon)
    except Exception:
        pass


def _current_browser_settings():
    scene = getattr(bpy.context, "scene", None)
    return getattr(scene, "fourdesinno_browser", None) if scene is not None else None


def _online_mode_enabled(settings=None):
    settings = settings or _current_browser_settings()
    if settings is None:
        with STATE_LOCK:
            return bool(STATE.get("online_mode", True))
    enabled = bool(getattr(settings, "online_enabled", True))
    with STATE_LOCK:
        STATE["online_mode"] = enabled
    return enabled


def _local_asset_title_from_slug(slug):
    words = re.sub(r"[_-]+", " ", str(slug or "").strip()).split()
    return " ".join(word.capitalize() for word in words) or "Untitled"


def _local_preview_paths_for_asset(host, asset_folder_name):
    preview_root = _preview_image_cache_root_dir()
    if not preview_root:
        return "", ""
    asset_dir = os.path.join(preview_root, host, asset_folder_name)
    if not os.path.isdir(asset_dir):
        return "", ""

    raw_path = ""
    display_path = ""
    for name in sorted(os.listdir(asset_dir)):
        path = os.path.join(asset_dir, name)
        if not os.path.isfile(path):
            continue
        low = name.lower()
        if not low.endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff")):
            continue
        if "_display" in low and not display_path:
            display_path = path
        elif not raw_path:
            raw_path = path
    if not raw_path and display_path:
        raw_path = display_path
    if raw_path and display_path and _files_are_same_or_equal(raw_path, display_path):
        display_path = raw_path
    return raw_path, display_path


def _load_local_downloaded_assets(settings):
    asset_type_key = _asset_type_key(getattr(settings, "asset_type", "model"))
    if asset_type_key != "model":
        return []

    search = str(getattr(settings, "search_text", "") or "").strip().lower()
    root = _cache_root_dir()
    rows = []

    if not os.path.isdir(root):
        return rows

    for host in sorted(os.listdir(root)):
        host_dir = os.path.join(root, host)
        if not os.path.isdir(host_dir):
            continue
        for asset_folder_name in sorted(os.listdir(host_dir)):
            asset_dir = os.path.join(host_dir, asset_folder_name)
            if not os.path.isdir(asset_dir):
                continue

            blend_files = sorted([name for name in os.listdir(asset_dir) if name.lower().endswith(".blend")])
            if not blend_files:
                continue

            asset_id = asset_folder_name
            slug = asset_folder_name
            if "_" in asset_folder_name:
                asset_id, slug = asset_folder_name.split("_", 1)

            title = _local_asset_title_from_slug(slug)
            if search and search not in title.lower() and search not in slug.lower():
                continue

            raw_preview, display_preview = _local_preview_paths_for_asset(host, asset_folder_name)
            site_url = f"https://{host}" if host else FOURDESINNO_SITE
            rows.append({
                "id": str(asset_id or slug),
                "slug": str(slug or asset_folder_name),
                "title": title,
                "excerpt": "",
                "link": "",
                "thumb": "",
                "kind": "MODEL",
                "site_url": site_url,
                "preview_path": raw_preview or "",
                "display_preview_path": display_preview or raw_preview or "",
                "strip_preview_path": raw_preview or "",
            })

    rows.sort(key=lambda a: (str(a.get("title") or "").lower(), str(a.get("id") or "")))
    return rows


# ---------------------------------------------------------
# preferences / folders
# ---------------------------------------------------------


def _addon_prefs():
    addons = bpy.context.preferences.addons
    return addons.get(PACKAGE_NAME).preferences if PACKAGE_NAME in addons else None


class F3D_AddonPreferences(AddonPreferences):
    bl_idname = PACKAGE_NAME

    cache_folder: StringProperty(
        name="Asset Storage Folder",
        subtype='DIR_PATH',
        default="",
        description="Folder where each downloaded asset gets its own subfolder (asset.blend and textures)",
    )

    hover_preview_scale: IntProperty(
        name="Hover Preview Size",
        default=6,
        min=1,
        description="Scale multiplier for the larger hover preview image",
    )

    preview_card_size: IntProperty(
        name="Preview Card Size",
        default=108,
        min=72,
        description="Controls the small preview size in the strip. Larger values make the addon strip taller and show fewer previews at once",
    )




    def draw(self, context):
        layout = self.layout
        layout.prop(self, "cache_folder")
        layout.prop(self, "hover_preview_scale")
        layout.prop(self, "preview_card_size")
        box = layout.box()
        box.label(text="Each asset gets its own folder here and is reused.")
        box.label(text=f"Default: {_default_cache_root()}")



def _default_cache_root():
    return default_asset_storage_dir()



def _cache_root_dir():
    prefs = _addon_prefs()
    chosen = ""
    if prefs:
        chosen = bpy.path.abspath((prefs.cache_folder or "").strip())
    directory = chosen if chosen else _default_cache_root()
    os.makedirs(directory, exist_ok=True)
    return directory





def _assets_folder_to_open():
    """Return the best folder to open for the user's downloaded assets.

    Rules:
    - If the user has set a custom Asset Storage Folder in Preferences, open that folder (top-level).
    - Otherwise use the default cache root, but if it points into a per-host subfolder
      (e.g. .../downloaded_assets/www.example.com), open the parent downloaded_assets folder.
    """
    # Prefer custom storage folder if set
    try:
        prefs = _addon_prefs()
        custom_root = str(getattr(prefs, "cache_folder", "") or "").strip() if prefs else ""
        if custom_root:
            return custom_root
    except Exception:
        pass

    try:
        directory = _cache_root_dir()
    except Exception:
        directory = ""

    directory = (directory or "").strip()
    if not directory:
        return ""

    try:
        base = os.path.basename(directory.rstrip(r"\/"))
        parent = os.path.dirname(directory.rstrip(r"\/"))
        parent_name = os.path.basename(parent.rstrip(r"\/")).lower()

        # If storage folder points to a host subfolder, open the parent root.
        if parent_name == "downloaded_assets" and "." in base:
            return parent

        return directory
    except Exception:
        return directory

def _user_data_root_dir():
    directory = default_user_data_dir()
    os.makedirs(directory, exist_ok=True)
    return directory


def _favorites_file_path():
    return os.path.join(_user_data_root_dir(), "favorites.json")


def _category_cache_file_path():
    return os.path.join(_user_data_root_dir(), "category_terms.json")


def _category_usage_cache_file_path():
    return os.path.join(_user_data_root_dir(), "category_term_usage_by_type.json")


def _category_count_cache_file_path():
    return os.path.join(_user_data_root_dir(), "category_term_count_by_type.json")


def _normalize_usage_id_list(values):
    ids = []
    seen = set()
    for value in values or []:
        try:
            term_id = int(value or 0)
        except Exception:
            term_id = 0
        if term_id <= 0 or term_id in seen:
            continue
        seen.add(term_id)
        ids.append(term_id)
    ids.sort()
    return ids


def _load_category_usage_cache_from_disk():
    path = _category_usage_cache_file_path()
    try:
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        rows = {}
        if isinstance(data, dict):
            for key in ("model", "texture", "hdri"):
                values = data.get(key)
                rows[key] = None if values is None else _normalize_usage_id_list(values)
        return rows
    except Exception:
        return {}


def _save_category_usage_cache_to_disk(usage_map):
    path = _category_usage_cache_file_path()
    try:
        rows = {}
        for key in ("model", "texture", "hdri"):
            values = (usage_map or {}).get(key)
            rows[key] = None if values is None else _normalize_usage_id_list(values)
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(rows, handle, indent=2)
    except Exception:
        pass


def _normalize_count_map_row(values):
    rows = {}
    if isinstance(values, dict):
        for key, value in values.items():
            try:
                term_id = int(key)
                count = int(value or 0)
            except Exception:
                continue
            if term_id > 0 and count > 0:
                rows[str(term_id)] = count
    return rows


def _load_category_count_cache_from_disk():
    path = _category_count_cache_file_path()
    try:
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        rows = {}
        if isinstance(data, dict):
            for key in ("model", "texture", "hdri"):
                rows[key] = _normalize_count_map_row(data.get(key) or {})
        return rows
    except Exception:
        return {}


def _save_category_count_cache_to_disk(count_map):
    path = _category_count_cache_file_path()
    try:
        rows = {}
        for key in ("model", "texture", "hdri"):
            rows[key] = _normalize_count_map_row((count_map or {}).get(key) or {})
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(rows, handle, indent=2)
    except Exception:
        pass


def _fetch_category_count_map_from_site():
    if not _online_mode_enabled():
        return {}
    endpoint = FOURDESINNO_SITE + "/wp-json/wp/v2/f3d_model"
    page = 1
    count_map = {"model": {}, "texture": {}, "hdri": {}}
    saw_category_field = False

    # IMPORTANT:
    # WordPress can assign BOTH a parent and a child term to the same asset.
    # If we count both and later roll-up children into parents, parents will look "doubled".
    # Fix: count only the most-specific (leaf) terms per asset, then roll-up works correctly.
    parent_by_id = {}
    try:
        terms = _ensure_category_cache(force=True) or []
        parent_by_id = {int(t.get("id") or 0): int(t.get("parent") or 0) for t in (terms or []) if int(t.get("id") or 0) > 0}
    except Exception:
        parent_by_id = {}

    def _leaf_terms_for_selected(selected_ids):
        selected_ids = {int(v) for v in (selected_ids or set()) if int(v) > 0}
        if not selected_ids or not parent_by_id:
            return selected_ids
        ancestors = set()
        for term_id in list(selected_ids):
            seen = set()
            cur = term_id
            steps = 0
            while steps < 20:
                steps += 1
                parent = int(parent_by_id.get(cur) or 0)
                if parent <= 0 or parent in seen:
                    break
                seen.add(parent)
                if parent in selected_ids:
                    ancestors.add(parent)
                cur = parent
        return selected_ids - ancestors if ancestors else selected_ids

    while page <= 40:
        params = {
            "per_page": "100",
            "page": str(page),
            "orderby": "date",
            "order": "desc",
            "_fields": "id,link,f3d_category",
        }
        url = endpoint + "?" + urllib.parse.urlencode(params)
        try:
            payload = _request_json(url)
        except urllib.error.HTTPError as exc:
            if getattr(exc, "code", None) == 400:
                break
            raise
        except Exception:
            break

        if not isinstance(payload, list) or not payload:
            break

        for row in payload:
            if not isinstance(row, dict):
                continue
            if "f3d_category" not in row:
                continue
            saw_category_field = True
            link = str(row.get("link") or "").strip()
            kind = _guess_kind_from_link(link)
            bucket = "model"
            if kind == "TEXTURE":
                bucket = "texture"
            elif kind == "HDRI":
                bucket = "hdri"

            values = row.get("f3d_category") or []
            if not isinstance(values, list):
                continue

            selected_ids = set()
            for value in values:
                try:
                    term_id = int(value or 0)
                except Exception:
                    term_id = 0
                if term_id > 0:
                    selected_ids.add(term_id)

            for term_id in _leaf_terms_for_selected(selected_ids):
                key = str(int(term_id))
                count_map[bucket][key] = int(count_map[bucket].get(key, 0)) + 1

        if len(payload) < 100:
            break
        page += 1

    return count_map if saw_category_field else {}



def _ensure_category_count_cache(force=False):
    disk_rows = _load_category_count_cache_from_disk()
    if not _online_mode_enabled():
        with STATE_LOCK:
            STATE["category_count_by_type"] = dict(disk_rows)
        return disk_rows

    with STATE_LOCK:
        cached = dict(STATE.get("category_count_by_type", {}) or {})
    if cached and not force:
        has_any = any(bool(cached.get(k)) for k in ("model", "texture", "hdri"))
        if has_any:
            return cached

    if disk_rows and not force:
        has_any = any(bool(disk_rows.get(k)) for k in ("model", "texture", "hdri"))
        if has_any:
            with STATE_LOCK:
                STATE["category_count_by_type"] = dict(disk_rows)
            return disk_rows

    count_map = _fetch_category_count_map_from_site()
    if count_map:
        _save_category_count_cache_to_disk(count_map)
        with STATE_LOCK:
            STATE["category_count_by_type"] = dict(count_map)
        return count_map

    return disk_rows


def _fetch_category_usage_for_asset_type(asset_type):
    if not _online_mode_enabled():
        return None
    endpoint = FOURDESINNO_SITE + "/wp-json/wp/v2/f3d_model"
    page = 1
    used_ids = set()
    saw_category_field = False

    while page <= 30:
        params = {
            "per_page": "100",
            "page": str(page),
            "orderby": "date",
            "order": "desc",
            "_fields": "id,f3d_category",
        }
        asset_type = str(asset_type or "model").strip().lower()
        if asset_type in {"texture", "hdri", "game"}:
            params["f3d_type"] = asset_type
        url = endpoint + "?" + urllib.parse.urlencode(params)
        try:
            payload = _request_json(url)
        except urllib.error.HTTPError as exc:
            if getattr(exc, "code", None) == 400:
                break
            raise
        except Exception:
            break

        if not isinstance(payload, list) or not payload:
            break

        for row in payload:
            if not isinstance(row, dict):
                continue
            if "f3d_category" not in row:
                continue
            saw_category_field = True
            values = row.get("f3d_category") or []
            if isinstance(values, list):
                for value in values:
                    try:
                        term_id = int(value or 0)
                    except Exception:
                        term_id = 0
                    if term_id > 0:
                        used_ids.add(term_id)

        if len(payload) < 100:
            break
        page += 1

    if not saw_category_field:
        return None
    return sorted(used_ids)


def _fetch_category_usage_map_from_site():
    if not _online_mode_enabled():
        return {}
    endpoint = FOURDESINNO_SITE + "/wp-json/wp/v2/f3d_model"
    page = 1
    usage_map = {"model": set(), "texture": set(), "hdri": set()}
    saw_category_field = False
    saw_link_field = False

    while page <= 40:
        params = {
            "per_page": "100",
            "page": str(page),
            "orderby": "date",
            "order": "desc",
            "_fields": "id,link,f3d_category",
        }
        url = endpoint + "?" + urllib.parse.urlencode(params)
        try:
            payload = _request_json(url)
        except urllib.error.HTTPError as exc:
            if getattr(exc, "code", None) == 400:
                break
            raise
        except Exception:
            break

        if not isinstance(payload, list) or not payload:
            break

        for row in payload:
            if not isinstance(row, dict):
                continue
            if "f3d_category" not in row:
                continue
            saw_category_field = True
            link = str(row.get("link") or "").strip()
            if link:
                saw_link_field = True
            kind = _guess_kind_from_link(link)
            bucket = "model"
            if kind == "TEXTURE":
                bucket = "texture"
            elif kind == "HDRI":
                bucket = "hdri"

            values = row.get("f3d_category") or []
            if isinstance(values, list):
                for value in values:
                    try:
                        term_id = int(value or 0)
                    except Exception:
                        term_id = 0
                    if term_id > 0:
                        usage_map[bucket].add(term_id)

        if len(payload) < 100:
            break
        page += 1

    if saw_category_field and saw_link_field:
        return {
            "model": sorted(usage_map["model"]),
            "texture": sorted(usage_map["texture"]),
            "hdri": sorted(usage_map["hdri"]),
        }

    # Fallback if the site REST response does not expose enough data.
    return {
        "model": _fetch_category_usage_for_asset_type("model"),
        "texture": _fetch_category_usage_for_asset_type("texture"),
        "hdri": _fetch_category_usage_for_asset_type("hdri"),
    }


def _ensure_category_usage_cache(force=False):
    if not _online_mode_enabled():
        disk_rows = _load_category_usage_cache_from_disk()
        with STATE_LOCK:
            STATE["category_usage_by_type"] = dict(disk_rows)
        return disk_rows
    with STATE_LOCK:
        cached = dict(STATE.get("category_usage_by_type", {}) or {})
    if cached and not force:
        has_any = any(cached.get(k) not in ({}, [], None) for k in ("model", "texture", "hdri"))
        if has_any:
            return cached

    disk_rows = _load_category_usage_cache_from_disk()
    if disk_rows and not force:
        values = [disk_rows.get(k) for k in ("model", "texture", "hdri")]
        has_any = any(v not in ({}, [], None) for v in values)
        all_equal = values[0] == values[1] == values[2] if len(values) == 3 else False
        if has_any and not all_equal:
            with STATE_LOCK:
                STATE["category_usage_by_type"] = dict(disk_rows)
            return disk_rows

    usage_map = _fetch_category_usage_map_from_site()
    if usage_map:
        _save_category_usage_cache_to_disk(usage_map)
        with STATE_LOCK:
            STATE["category_usage_by_type"] = dict(usage_map)
        return usage_map

    return disk_rows


def _visible_term_ids_for_asset_type(settings, terms=None, usage_map=None):
    terms = list(terms or [])
    asset_type = str(getattr(settings, "asset_type", "model") or "model").strip().lower() if settings is not None else "model"
    usage_map = dict(usage_map or {})
    direct_ids = usage_map.get(asset_type, None)

    # None means the site did not expose per-item taxonomy fields in REST; fall back to all terms.
    if direct_ids is None:
        return {int(t.get("id") or 0) for t in terms if int(t.get("id") or 0) > 0}

    visible_ids = set(int(v) for v in (direct_ids or []) if int(v) > 0)
    parent_by_id = {}
    for term in terms:
        try:
            term_id = int(term.get("id") or 0)
        except Exception:
            term_id = 0
        try:
            parent_id = int(term.get("parent") or 0)
        except Exception:
            parent_id = 0
        if term_id > 0:
            parent_by_id[term_id] = parent_id

    stack = list(visible_ids)
    while stack:
        term_id = stack.pop()
        parent_id = int(parent_by_id.get(term_id) or 0)
        if parent_id > 0 and parent_id not in visible_ids:
            visible_ids.add(parent_id)
            stack.append(parent_id)
    return visible_ids


def _normalize_category_term_row(row):
    try:
        term_id = int(row.get("id") or 0)
    except Exception:
        term_id = 0
    if term_id <= 0:
        return None
    try:
        parent = int(row.get("parent") or 0)
    except Exception:
        parent = 0
    return {
        "id": term_id,
        "name": str(row.get("name") or "").strip().upper(),
        "slug": str(row.get("slug") or "").strip(),
        "parent": parent,
    }


def _load_category_cache_from_disk():
    path = _category_cache_file_path()
    try:
        if not os.path.exists(path):
            return []
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        rows = []
        if isinstance(data, list):
            for row in data:
                if isinstance(row, dict):
                    norm = _normalize_category_term_row(row)
                    if norm:
                        rows.append(norm)
        rows.sort(key=lambda t: ((int(t.get("parent") or 0) != 0), str(t.get("name") or "").lower()))
        return rows
    except Exception:
        return []


def _save_category_cache_to_disk(terms):
    path = _category_cache_file_path()
    try:
        rows = []
        for row in terms or []:
            norm = _normalize_category_term_row(row)
            if norm:
                rows.append(norm)
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(rows, handle, indent=2)
    except Exception:
        pass


def _sync_selected_category_filters(settings, terms, usage_map=None):
    if settings is None:
        return
    terms = list(terms or [])
    visible_ids = _visible_term_ids_for_asset_type(settings, terms, usage_map=usage_map)

    current_cat = _find_term_in_list(terms, getattr(settings, "category_term_id", ""))
    current_sub = _find_term_in_list(terms, getattr(settings, "subcategory_term_id", ""))

    if current_cat is not None and int(current_cat.get("id") or 0) not in visible_ids:
        current_cat = None
    if current_sub is not None and int(current_sub.get("id") or 0) not in visible_ids:
        current_sub = None

    if getattr(settings, "category_term_id", "") and current_cat is None:
        _set_category_term(settings, None)
    elif current_cat is not None:
        settings.category_term_name = str(current_cat.get("name") or "ALL CATEGORIES").upper()

    if getattr(settings, "subcategory_term_id", "") and current_sub is None:
        settings.subcategory_term_id = ""
        settings.subcategory_term_slug = ""
        settings.subcategory_term_name = "ALL SUBCATEGORIES"
    elif current_sub is not None:
        settings.subcategory_term_name = str(current_sub.get("name") or "ALL SUBCATEGORIES").upper()


def _favorite_key(asset):
    site = _normalize_site_url(asset.get("site_url") or FOURDESINNO_SITE)
    asset_id = str(asset.get("id") or "")
    slug = str(asset.get("slug") or "")
    return f"{site}|{asset_id}|{slug}"


def _load_favorites():
    path = _favorites_file_path()
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, list):
                with STATE_LOCK:
                    STATE["favorites"] = set(str(x) for x in data if x)
                return
    except Exception:
        pass
    with STATE_LOCK:
        STATE["favorites"] = set()


def _save_favorites():
    path = _favorites_file_path()
    try:
        with STATE_LOCK:
            data = sorted(str(x) for x in STATE.get("favorites", set()))
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2)
    except Exception:
        pass


def _is_favorite(asset):
    key = _favorite_key(asset)
    with STATE_LOCK:
        return key in STATE.get("favorites", set())


def _toggle_favorite(asset):
    key = _favorite_key(asset)
    with STATE_LOCK:
        favorites = set(STATE.get("favorites", set()))
        if key in favorites:
            favorites.remove(key)
            is_now = False
        else:
            favorites.add(key)
            is_now = True
        STATE["favorites"] = favorites
    _save_favorites()
    if is_now:
        _store_asset_preview_in_cache(asset)
    _redraw_view3d()
    return is_now


def _asset_is_downloaded(asset):
    site_url = asset.get("site_url") or ""
    parsed = urllib.parse.urlparse(_normalize_site_url(site_url) or "")
    host = _sanitize_filename(parsed.netloc or "default_site", "default_site")
    root = os.path.join(_cache_root_dir(), host)

    asset_id = _sanitize_filename(asset.get("id") or "asset", "asset")
    slug = _sanitize_filename(asset.get("slug") or asset.get("title") or asset.get("id") or "asset", "asset")
    asset_folder = os.path.join(root, f"{asset_id}_{slug}")
    blend_path = os.path.join(asset_folder, f"{slug}.blend")
    return bool(os.path.exists(blend_path) and os.path.getsize(blend_path) > 0)


def _site_cache_dir(site_url):
    parsed = urllib.parse.urlparse(_normalize_site_url(site_url) or "")
    host = _sanitize_filename(parsed.netloc or "default_site", "default_site")
    directory = os.path.join(_cache_root_dir(), host)
    os.makedirs(directory, exist_ok=True)
    return directory


def _asset_dir(asset):
    site_url = asset.get("site_url") or ""
    asset_id = _sanitize_filename(asset.get("id") or "asset", "asset")
    slug = _sanitize_filename(asset.get("slug") or asset.get("title") or "asset", "asset")
    directory = os.path.join(_site_cache_dir(site_url), f"{asset_id}_{slug}")
    os.makedirs(directory, exist_ok=True)
    return directory


def _asset_cache_path(asset):
    slug = _sanitize_filename(asset.get("slug") or asset.get("title") or asset.get("id") or "asset", "asset")
    return os.path.join(_asset_dir(asset), f"{slug}.blend")


def _asset_texture_dir(asset):
    directory = os.path.join(_asset_dir(asset), "textures")
    os.makedirs(directory, exist_ok=True)
    return directory



def _preview_image_cache_root_dir():
    chosen = os.path.join(ADDON_ROOT, "preview_cache")
    try:
        os.makedirs(chosen, exist_ok=True)
    except Exception:
        return ""
    return chosen


def _preview_image_cache_asset_dir(asset, create=False):
    root = _preview_image_cache_root_dir()
    if not root:
        return ""
    site_url = asset.get("site_url") or ""
    parsed = urllib.parse.urlparse(_normalize_site_url(site_url) or "")
    host = _sanitize_filename(parsed.netloc or "default_site", "default_site")
    asset_id = _sanitize_filename(asset.get("id") or "asset", "asset")
    slug = _sanitize_filename(asset.get("slug") or asset.get("title") or "asset", "asset")
    directory = os.path.join(root, host, f"{asset_id}_{slug}")
    if create:
        os.makedirs(directory, exist_ok=True)
    elif not os.path.isdir(directory):
        return ""
    return directory


def _preview_image_cache_paths(asset, create=False):
    directory = _preview_image_cache_asset_dir(asset, create=create)
    if not directory:
        return {"raw": "", "display": ""}
    thumb_url = asset.get("thumb") or ""
    ext = os.path.splitext(urllib.parse.urlparse(thumb_url).path)[1] or ".jpg"
    return {
        "raw": os.path.join(directory, _sanitize_filename(f"{asset.get('id','asset')}_{asset.get('slug','preview')}{ext}", "preview.jpg")),
        "display": os.path.join(directory, _sanitize_filename(f"{asset.get('id','asset')}_{asset.get('slug','preview')}_display.png", "preview_display.png")),
    }


def _files_are_same_or_equal(path_a, path_b):
    try:
        if not path_a or not path_b:
            return False
        if not os.path.exists(path_a) or not os.path.exists(path_b):
            return False
        try:
            if os.path.samefile(path_a, path_b):
                return True
        except Exception:
            pass
        return filecmp.cmp(path_a, path_b, shallow=False)
    except Exception:
        return False


def _special_mode_sort_key(asset):
    asset_id = str(asset.get("id") or "").strip()
    title = str(asset.get("title") or "").strip().lower()
    if asset_id.isdigit():
        return (0, -int(asset_id), title)
    return (1, title, asset_id.lower())


def _merge_special_mode_assets_preserve_existing(existing_assets, new_assets):
    existing_assets = [dict(a) for a in (existing_assets or [])]
    new_assets = [dict(a) for a in (new_assets or [])]

    existing_by_id = {}
    ordered = []
    for asset in existing_assets:
        asset_id = str(asset.get("id") or "")
        if not asset_id or asset_id in existing_by_id:
            continue
        existing_by_id[asset_id] = dict(asset)
        ordered.append(dict(asset))

    new_by_id = {}
    for asset in new_assets:
        asset_id = str(asset.get("id") or "")
        if not asset_id:
            continue
        new_by_id[asset_id] = dict(asset)

    merged = []
    seen = set()

    # Keep already visible assets in exactly their current order.
    for asset in ordered:
        asset_id = str(asset.get("id") or "")
        if asset_id in seen:
            continue
        merged.append(dict(new_by_id.get(asset_id) or asset))
        seen.add(asset_id)

    # Only append newly discovered assets after the current visible ones.
    for asset in sorted(new_by_id.values(), key=_special_mode_sort_key):
        asset_id = str(asset.get("id") or "")
        if not asset_id or asset_id in seen:
            continue
        merged.append(dict(asset))
        seen.add(asset_id)

    return merged


def _images_look_identical(path_a, path_b):
    if not path_a or not path_b:
        return False
    if not os.path.exists(path_a) or not os.path.exists(path_b):
        return False

    try:
        if os.path.samefile(path_a, path_b):
            return True
    except Exception:
        pass

    try:
        if filecmp.cmp(path_a, path_b, shallow=False):
            return True
    except Exception:
        pass

    if Image is None:
        return False

    try:
        with Image.open(path_a) as im_a, Image.open(path_b) as im_b:
            im_a.load()
            im_b.load()
            rgba_a = im_a.convert("RGBA")
            rgba_b = im_b.convert("RGBA")
            if rgba_a.size != rgba_b.size:
                return False
            return rgba_a.tobytes() == rgba_b.tobytes()
    except Exception:
        return False


def _store_asset_preview_in_cache(asset):
    try:
        paths = _preview_image_cache_paths(asset, create=True)
        raw_path = paths.get("raw") or ""
        display_path = paths.get("display") or ""
        if not raw_path and not display_path:
            return

        src_raw = _ensure_asset_preview_file(asset)
        if src_raw and os.path.exists(src_raw) and raw_path and not os.path.exists(raw_path):
            shutil.copy2(src_raw, raw_path)

        src_display = _ensure_display_preview_file(asset)
        if src_display and os.path.exists(src_display) and display_path:
            same_as_raw_source = bool(src_raw and _images_look_identical(src_raw, src_display))
            same_as_cached_raw = bool(raw_path and os.path.exists(raw_path) and _images_look_identical(raw_path, src_display))
            if same_as_raw_source or same_as_cached_raw:
                try:
                    if os.path.exists(display_path):
                        os.remove(display_path)
                except Exception:
                    pass
            elif not os.path.exists(display_path):
                shutil.copy2(src_display, display_path)
    except Exception:
        pass


# ---------------------------------------------------------
# small utils
# ---------------------------------------------------------


def _apply_inline_search(context):
    settings = getattr(context.scene, "fourdesinno_browser", None)
    if settings is None:
        return
    # Text search always resets category filter to ALL CATEGORIES (but keeps current tab/type).
    settings.category_term_id = ""
    settings.category_term_slug = ""
    settings.category_term_name = "ALL CATEGORIES"
    settings.subcategory_term_id = ""
    settings.subcategory_term_slug = ""
    settings.subcategory_term_name = "ALL SUBCATEGORIES"
    _clear_browse_snapshot()
    with STATE_LOCK:
        settings.search_text = str(STATE.get("search_buffer", "")).strip()
        STATE["search_editing"] = False
        STATE["search_buffer"] = settings.search_text
        STATE["assets"] = []
        STATE["pending_assets"] = []
        STATE["next_page"] = 1
        STATE["has_more"] = True
    settings.strip_offset = 0
    _set_status(f"Searching {settings.asset_type}: {settings.search_text}")
    bpy.ops.fourdesinno.load_assets()


def _redraw_view3d():
    wm = bpy.context.window_manager
    for window in wm.windows:
        screen = window.screen
        if not screen:
            continue
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()



def _validate_or_reset_owner(current_window=None, current_area=None):
    """Ensure STATE owner window/area pointers reference an existing VIEW_3D.
    If invalid (area closed / window gone), reset to current_window/current_area when possible.
    Returns (owner_win_ptr, owner_area_ptr).
    """
    try:
        with STATE_LOCK:
            owner_area_ptr = STATE.get("strip_area_pointer")
            owner_win_ptr = STATE.get("strip_window_pointer")
    except Exception:
        owner_area_ptr = None
        owner_win_ptr = None

    try:
        wm = bpy.context.window_manager
    except Exception:
        wm = None

    # Validate window exists
    win_obj = None
    if owner_win_ptr and wm is not None:
        for w in wm.windows:
            try:
                if w.as_pointer() == owner_win_ptr:
                    win_obj = w
                    break
            except Exception:
                continue

    if win_obj is None:
        owner_win_ptr = None
        owner_area_ptr = None
    else:
        # Validate area exists in that window's screen
        ok_area = False
        try:
            screen = win_obj.screen
            if screen:
                for a in screen.areas:
                    if a.type != 'VIEW_3D':
                        continue
                    try:
                        if a.as_pointer() == owner_area_ptr:
                            ok_area = True
                            break
                    except Exception:
                        continue
        except Exception:
            ok_area = False

        if not ok_area:
            owner_area_ptr = None

    # Reset if missing
    if owner_win_ptr is None or owner_area_ptr is None:
        try:
            if current_window and current_area and current_area.type == 'VIEW_3D':
                owner_win_ptr = current_window.as_pointer()
                owner_area_ptr = current_area.as_pointer()
            else:
                # fallback to any view3d
                if wm is not None:
                    for w in wm.windows:
                        screen = w.screen
                        if not screen:
                            continue
                        for a in screen.areas:
                            if a.type == 'VIEW_3D':
                                owner_win_ptr = w.as_pointer()
                                owner_area_ptr = a.as_pointer()
                                raise StopIteration
        except StopIteration:
            pass
        except Exception:
            pass

        try:
            with STATE_LOCK:
                STATE["strip_window_pointer"] = owner_win_ptr
                STATE["strip_area_pointer"] = owner_area_ptr
        except Exception:
            pass

    return owner_win_ptr, owner_area_ptr
def _find_view3d_area_at_window_xy(window, win_x, win_y):
    """Return a VIEW_3D area under the given window coordinates (event.mouse_x/y)."""
    try:
        screen = window.screen if window else None
        if not screen:
            return None
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            ax = int(area.x)
            ay = int(area.y)
            aw = int(area.width)
            ah = int(area.height)
            if ax <= win_x < (ax + aw) and ay <= win_y < (ay + ah):
                return area
    except Exception:
        return None
    return None




def _set_status(text):
    with STATE_LOCK:
        STATE["status"] = str(text)
    _redraw_view3d()


def _schedule_deferred_asset_reload(status_text="Loading assets...", only_if_expanded=True):
    scene = getattr(bpy.context, "scene", None)
    settings = getattr(scene, "fourdesinno_browser", None) if scene is not None else None
    if settings is None:
        return

    _set_status(status_text)

    with STATE_LOCK:
        seq = int(STATE.get("pending_reload_seq", 0) or 0) + 1
        STATE["pending_reload_seq"] = seq

    def _deferred():
        try:
            with STATE_LOCK:
                if int(STATE.get("pending_reload_seq", 0) or 0) != seq:
                    return None
            scene2 = getattr(bpy.context, "scene", None)
            settings2 = getattr(scene2, "fourdesinno_browser", None) if scene2 is not None else None
            if settings2 is None:
                return None
            if only_if_expanded and not bool(getattr(settings2, "strip_expanded", False)):
                return None
            bpy.ops.fourdesinno.load_assets()
        except Exception:
            pass
        return None

    try:
        bpy.app.timers.register(_deferred, first_interval=0.01)
    except Exception:
        try:
            bpy.ops.fourdesinno.load_assets()
        except Exception:
            pass


def _populate_special_mode_from_catalog(settings):
    asset_type_key = _asset_type_key(getattr(settings, "asset_type", "model"))
    with STATE_LOCK:
        favorites_only = bool(STATE.get("favorites_only", False))
        downloaded_only = bool(STATE.get("downloaded_only", False))
        catalog_map = dict((STATE.get("asset_catalog_by_type", {}) or {}).get(asset_type_key, {}) or {})
        catalog_complete = bool((STATE.get("asset_catalog_complete_by_type", {}) or {}).get(asset_type_key, False))
        current_assets = [dict(a) for a in STATE.get("assets", [])]
        pending_assets = [dict(a) for a in STATE.get("pending_assets", [])]

    if not (favorites_only or downloaded_only):
        return 0, catalog_complete

    merged = {}
    for asset in current_assets + pending_assets:
        asset_id = str(asset.get("id") or "")
        if asset_id:
            merged[asset_id] = dict(asset)
    for asset_id, asset in catalog_map.items():
        if asset_id:
            merged[str(asset_id)] = dict(asset)

    filtered = []
    for asset in merged.values():
        keep_asset = _is_favorite(asset) if favorites_only else _asset_is_downloaded(asset)
        if keep_asset:
            filtered.append(dict(asset))
    filtered.sort(key=_special_mode_sort_key)

    with STATE_LOCK:
        STATE["assets"] = filtered
        STATE["pending_assets"] = []
        STATE["next_page"] = 1
        STATE["has_more"] = False
        queue = list(STATE.get("thumb_queue", []))
        for asset in filtered:
            asset_id = str(asset.get("id") or "")
            if asset_id and asset_id not in queue:
                queue.append(asset_id)
        STATE["thumb_queue"] = queue

    _redraw_view3d()
    return len(filtered), catalog_complete



def _set_download(title="", phase="", bytes_done=0, bytes_total=0):
    percent = 0
    if bytes_total > 0:
        percent = int(max(0, min(100, round((bytes_done / bytes_total) * 100))))
    with STATE_LOCK:
        STATE["download"] = {
            "title": str(title or ""),
            "phase": str(phase or ""),
            "bytes_done": int(bytes_done or 0),
            "bytes_total": int(bytes_total or 0),
            "percent": percent,
        }
    _redraw_view3d()



def _clear_download():
    _set_download()



def _format_bytes(value):
    value = float(value or 0)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if value < 1024.0 or unit == "TB":
            if unit == "B":
                return f"{int(value)} {unit}"
            return f"{value:.1f} {unit}"
        value /= 1024.0
    return "0 B"



def _normalize_site_url(site_url):
    site_url = (site_url or "").strip()
    if not site_url:
        return ""
    if not re.match(r"^https?://", site_url, re.I):
        site_url = "https://" + site_url
    return site_url.rstrip(r"\/")


def _archive_base_for_type(site_url, asset_type):
    site_url = _normalize_site_url(site_url)
    if asset_type == "texture":
        return site_url + "/textures/"
    if asset_type == "hdri":
        return site_url + "/hdri/"
    return site_url + "/3d-models/"



def _sanitize_filename(value, fallback="asset"):
    value = re.sub(r"[^a-zA-Z0-9._-]+", "_", str(value or "")).strip("._-")
    return value or fallback



def _request_bytes(url):
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "application/json, text/html, */*",
        },
    )
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response:
        return response.read(), response.headers.get_content_type() or "", response.geturl(), response.headers



def _request_json(url):
    data, _ctype, _final, _headers = _request_bytes(url)
    return json.loads(data.decode("utf-8", errors="replace"))



def _fetch_category_terms_from_site():
    if not _online_mode_enabled():
        return []
    endpoint = FOURDESINNO_SITE + "/wp-json/wp/v2/f3d_category"
    page = 1
    terms = []
    seen = set()
    while page <= 20:
        url = endpoint + "?" + urllib.parse.urlencode({
            "per_page": "100",
            "page": str(page),
            "orderby": "name",
            "order": "asc",
            "_fields": "id,name,slug,parent",
        })
        try:
            payload = _request_json(url)
        except urllib.error.HTTPError as exc:
            if getattr(exc, "code", None) == 400:
                break
            raise
        except Exception:
            break

        if not isinstance(payload, list) or not payload:
            break

        for row in payload:
            if not isinstance(row, dict):
                continue
            norm = _normalize_category_term_row(row)
            if not norm:
                continue
            term_id = int(norm.get("id") or 0)
            if term_id in seen:
                continue
            seen.add(term_id)
            terms.append(norm)

        if len(payload) < 100:
            break
        page += 1

    terms.sort(key=lambda t: ((int(t.get("parent") or 0) != 0), str(t.get("name") or "").lower()))
    return terms


def _ensure_category_cache(force=False):
    if not _online_mode_enabled():
        disk_terms = _load_category_cache_from_disk()
        with STATE_LOCK:
            STATE["category_terms"] = list(disk_terms)
        return disk_terms
    with STATE_LOCK:
        cached = list(STATE.get("category_terms", []))
    if cached and not force:
        return cached

    disk_terms = _load_category_cache_from_disk()
    if disk_terms and not force:
        with STATE_LOCK:
            STATE["category_terms"] = list(disk_terms)
        return disk_terms

    terms = _fetch_category_terms_from_site()
    if terms:
        _save_category_cache_to_disk(terms)
        with STATE_LOCK:
            STATE["category_terms"] = list(terms)
        return terms

    return disk_terms


def _refresh_category_cache_from_site():
    if not _online_mode_enabled():
        return None
    try:
        terms = _fetch_category_terms_from_site()
        if terms:
            _save_category_cache_to_disk(terms)
            with STATE_LOCK:
                STATE["category_terms"] = list(terms)
            scene = getattr(bpy.context, "scene", None)
            settings = getattr(scene, "fourdesinno_browser", None) if scene is not None else None
            usage_map = _ensure_category_usage_cache()
            _sync_selected_category_filters(settings, terms, usage_map=usage_map)
            _redraw_view3d()
    except Exception:
        pass
    return None


def _refresh_category_usage_cache_from_site():
    if not _online_mode_enabled():
        return None
    try:
        usage_map = _fetch_category_usage_map_from_site()
        if usage_map:
            _save_category_usage_cache_to_disk(usage_map)
            with STATE_LOCK:
                STATE["category_usage_by_type"] = dict(usage_map)
            scene = getattr(bpy.context, "scene", None)
            settings = getattr(scene, "fourdesinno_browser", None) if scene is not None else None
            try:
                terms = _ensure_category_cache()
            except Exception:
                terms = []
            _sync_selected_category_filters(settings, terms, usage_map=usage_map)
            _redraw_view3d()
    except Exception:
        pass
    return None


def _refresh_category_count_cache_from_site():
    if not _online_mode_enabled():
        return None
    try:
        count_map = _fetch_category_count_map_from_site()
        if count_map:
            _save_category_count_cache_to_disk(count_map)
            with STATE_LOCK:
                STATE["category_count_by_type"] = dict(count_map)
            _redraw_view3d()
    except Exception:
        pass
    return None


def _find_term_in_list(terms, term_id):
    wanted = str(term_id or "")
    if not wanted:
        return None
    for term in terms or []:
        if str(term.get("id") or "") == wanted:
            return dict(term)
    return None


def _category_parent_terms(terms):
    rows = [dict(t) for t in (terms or []) if int(t.get("parent") or 0) == 0]
    rows.sort(key=lambda t: str(t.get("name") or "").lower())
    return rows


def _subcategory_terms(terms, parent_id=""):
    wanted = str(parent_id or "")
    rows = []
    for term in terms or []:
        parent = str(int(term.get("parent") or 0))
        if wanted:
            if parent == wanted:
                rows.append(dict(term))
        else:
            if int(term.get("parent") or 0) != 0:
                rows.append(dict(term))
    rows.sort(key=lambda t: str(t.get("name") or "").lower())
    return rows


def _term_count_maps_for_settings(settings, terms, count_map=None):
    asset_type = _asset_type_key(getattr(settings, "asset_type", "model") if settings is not None else "model")
    count_map = dict(count_map or {})
    direct_source = count_map.get(asset_type, {}) or {}
    direct_counts = {}
    for key, value in direct_source.items():
        try:
            term_id = int(key)
            count = int(value or 0)
        except Exception:
            continue
        if term_id > 0 and count > 0:
            direct_counts[term_id] = count

    parent_by_id = {}
    for term in terms or []:
        try:
            term_id = int(term.get("id") or 0)
            parent_id = int(term.get("parent") or 0)
        except Exception:
            continue
        if term_id > 0:
            parent_by_id[term_id] = parent_id

    total_counts = dict(direct_counts)
    for term_id, count in list(direct_counts.items()):
        parent_id = int(parent_by_id.get(term_id) or 0)
        seen = set()
        while parent_id > 0 and parent_id not in seen:
            seen.add(parent_id)
            total_counts[parent_id] = int(total_counts.get(parent_id, 0)) + count
            parent_id = int(parent_by_id.get(parent_id) or 0)

    return direct_counts, total_counts


def _with_term_count(row, count_value):
    out = dict(row or {})
    try:
        out["count"] = max(0, int(count_value or 0))
    except Exception:
        out["count"] = 0
    return out


def _set_category_term(settings, term):
    # Selecting a category/subcategory cancels inline search.
    try:
        settings.search_text = ""
    except Exception:
        pass
    with STATE_LOCK:
        STATE["search_editing"] = False
        STATE["search_buffer"] = ""

    if not term:
        settings.category_term_id = ""
        settings.category_term_slug = ""
        settings.category_term_name = "ALL CATEGORIES"
        settings.subcategory_term_id = ""
        settings.subcategory_term_slug = ""
        settings.subcategory_term_name = "ALL SUBCATEGORIES"
        return
    settings.category_term_id = str(term.get("id") or "")
    settings.category_term_slug = str(term.get("slug") or "")
    settings.category_term_name = str(term.get("name") or "ALL CATEGORIES").upper()
    settings.subcategory_term_id = ""
    settings.subcategory_term_slug = ""
    settings.subcategory_term_name = "ALL SUBCATEGORIES"


def _set_subcategory_term(settings, term, terms=None):
    # Selecting a category/subcategory cancels inline search.
    try:
        settings.search_text = ""
    except Exception:
        pass
    with STATE_LOCK:
        STATE["search_editing"] = False
        STATE["search_buffer"] = ""

    if not term:
        settings.subcategory_term_id = ""
        settings.subcategory_term_slug = ""
        settings.subcategory_term_name = "ALL SUBCATEGORIES"
        return
    settings.subcategory_term_id = str(term.get("id") or "")
    settings.subcategory_term_slug = str(term.get("slug") or "")
    settings.subcategory_term_name = str(term.get("name") or "ALL SUBCATEGORIES").upper()
    parent_id = str(int(term.get("parent") or 0))
    if parent_id and terms is not None:
        parent_term = _find_term_in_list(terms, parent_id)
        if parent_term:
            settings.category_term_id = str(parent_term.get("id") or "")
            settings.category_term_slug = str(parent_term.get("slug") or "")
            settings.category_term_name = str(parent_term.get("name") or "ALL CATEGORIES").upper()



def _filter_fingerprint(settings):
    try:
        return (
            _asset_type_key(getattr(settings, "asset_type", "model")),
            str(getattr(settings, "search_text", "") or "").strip(),
            str(getattr(settings, "category_term_id", "") or "").strip(),
            str(getattr(settings, "subcategory_term_id", "") or "").strip(),
            bool(getattr(settings, "online_enabled", True)),
        )
    except Exception:
        return ("model", "", "", "", True)


def _clear_browse_snapshot():
    with STATE_LOCK:
        STATE["browse_snapshot"] = None


def _capture_browse_snapshot(settings):
    if settings is None:
        return
    with STATE_LOCK:
        if STATE.get("browse_snapshot") is not None:
            return
        STATE["browse_snapshot"] = {
            "fingerprint": _filter_fingerprint(settings),
            "assets": [dict(a) for a in STATE.get("assets", [])],
            "pending_assets": [dict(a) for a in STATE.get("pending_assets", [])],
            "thumb_queue": list(STATE.get("thumb_queue", [])),
            "next_page": int(STATE.get("next_page", 1) or 1),
            "has_more": bool(STATE.get("has_more", True)),
            "strip_offset": int(getattr(settings, "strip_offset", 0) or 0),
        }


def _restore_browse_snapshot(settings):
    if settings is None:
        return False
    with STATE_LOCK:
        snap = STATE.get("browse_snapshot")
    if not isinstance(snap, dict):
        return False
    if snap.get("fingerprint") != _filter_fingerprint(settings):
        _clear_browse_snapshot()
        return False
    with STATE_LOCK:
        STATE["assets"] = [dict(a) for a in snap.get("assets", [])]
        STATE["pending_assets"] = [dict(a) for a in snap.get("pending_assets", [])]
        STATE["thumb_queue"] = list(snap.get("thumb_queue", []))
        STATE["next_page"] = int(snap.get("next_page", 1) or 1)
        STATE["has_more"] = bool(snap.get("has_more", True))
        STATE["loading_more"] = False
        STATE["browse_snapshot"] = None
    try:
        settings.strip_offset = int(snap.get("strip_offset", 0) or 0)
    except Exception:
        settings.strip_offset = 0
    _redraw_view3d()
    return True


def _reset_assets_for_current_filters(settings):
    with STATE_LOCK:
        STATE["assets"] = []
        STATE["pending_assets"] = []
        STATE["thumb_queue"] = []
        STATE["next_page"] = 1
        STATE["has_more"] = True
    settings.strip_offset = 0


def _selected_filter_term(settings):
    if not _online_mode_enabled(settings):
        return "", ""
    with STATE_LOCK:
        favorites_only = bool(STATE.get("favorites_only", False))
        downloaded_only = bool(STATE.get("downloaded_only", False))
    if favorites_only or downloaded_only:
        return "", ""
    term_id = str(getattr(settings, "subcategory_term_id", "") or getattr(settings, "category_term_id", "") or "").strip()
    term_slug = str(getattr(settings, "subcategory_term_slug", "") or getattr(settings, "category_term_slug", "") or "").strip()
    return term_id, term_slug


def _category_options(settings):
    try:
        terms = _ensure_category_cache()
    except Exception:
        terms = []
    try:
        usage_map = _ensure_category_usage_cache()
    except Exception:
        usage_map = {}
    try:
        count_map = _ensure_category_count_cache()
    except Exception:
        count_map = {}
    _direct_counts, total_counts = _term_count_maps_for_settings(settings, terms, count_map=count_map)
    visible_ids = _visible_term_ids_for_asset_type(settings, terms, usage_map=usage_map)
    rows = [{"id": "", "slug": "", "name": "ALL CATEGORIES", "parent": 0, "count": 0}]
    rows.extend([_with_term_count(row, total_counts.get(int(row.get("id") or 0), 0)) for row in _category_parent_terms(terms) if int(row.get("id") or 0) in visible_ids])
    return rows


def _subcategory_options(settings):
    try:
        terms = _ensure_category_cache()
    except Exception:
        terms = []
    try:
        usage_map = _ensure_category_usage_cache()
    except Exception:
        usage_map = {}
    try:
        count_map = _ensure_category_count_cache()
    except Exception:
        count_map = {}
    direct_counts, total_counts = _term_count_maps_for_settings(settings, terms, count_map=count_map)
    visible_ids = _visible_term_ids_for_asset_type(settings, terms, usage_map=usage_map)
    parent_id = str(getattr(settings, "category_term_id", "") or "")
    rows = [{"id": "", "slug": "", "name": "ALL SUBCATEGORIES", "parent": 0, "count": 0}]
    rows.extend([_with_term_count(row, total_counts.get(int(row.get("id") or 0), direct_counts.get(int(row.get("id") or 0), 0))) for row in _subcategory_terms(terms, parent_id=parent_id) if int(row.get("id") or 0) in visible_ids])
    return rows


def _dropdown_layout_for_box(box, options, width=None, row_h=24):
    if not box or not options:
        return None
    menu_w = int(max(width or (box["x2"] - box["x1"]), box["x2"] - box["x1"]))
    x1 = int(box["x1"])
    x2 = x1 + menu_w
    gap = 2
    rows = []
    y2 = int(box["y2"]) + gap
    for idx, row in enumerate(options):
        item_y1 = y2 + idx * row_h
        item_y2 = item_y1 + row_h
        rows.append({
            "row": row,
            "x1": x1,
            "y1": item_y1,
            "x2": x2,
            "y2": item_y2,
            "index": idx,
        })
    return {
        "x1": x1,
        "y1": y2,
        "x2": x2,
        "y2": y2 + len(rows) * row_h,
        "items": rows,
    }


def _submenu_parent_id_for_open_category_menu(settings, main_rows):
    with STATE_LOCK:
        hover_kind = str(STATE.get("dropdown_hover_kind", "") or "")
        hover_id = str(STATE.get("dropdown_hover_id", "") or "")
        hover_parent_id = str(STATE.get("dropdown_hover_parent_id", "") or "")

    valid_main_ids = {str(row.get("id") or "") for row in (main_rows or []) if str(row.get("id") or "")}

    if hover_kind == "category" and hover_id in valid_main_ids:
        return hover_id
    if hover_parent_id in valid_main_ids:
        return hover_parent_id

    selected_parent = str(getattr(settings, "category_term_id", "") or "")
    if selected_parent in valid_main_ids:
        return selected_parent

    return ""


def _open_dropdown_layout(settings, layout):
    with STATE_LOCK:
        which = str(STATE.get("dropdown_open", "") or "")
    if which != "category":
        return ("", None)

    try:
        if _online_mode_enabled(settings):
            count_map_now = dict(STATE.get("category_count_by_type", {}) or {})
            has_counts_now = any(bool((count_map_now.get(k) or {})) for k in ("model", "texture", "hdri"))
            if not has_counts_now:
                _ensure_category_count_cache(force=True)
    except Exception:
        pass

    main_rows = _category_options(settings)
    main_menu = _dropdown_layout_for_box(
        layout.get("category_box"),
        main_rows,
        width=max(230, (layout.get("category_box") or {}).get("x2", 0) - (layout.get("category_box") or {}).get("x1", 0) + 36),
    )
    if not main_menu:
        return ("", None)

    submenu_parent_id = _submenu_parent_id_for_open_category_menu(settings, main_rows)

    sub_menu = None
    if submenu_parent_id:
        try:
            terms = _ensure_category_cache()
        except Exception:
            terms = []
        try:
            usage_map = _ensure_category_usage_cache()
        except Exception:
            usage_map = {}
        visible_ids = _visible_term_ids_for_asset_type(settings, terms, usage_map=usage_map)
        try:
            count_map = _ensure_category_count_cache()
        except Exception:
            count_map = {}
        direct_counts, total_counts = _term_count_maps_for_settings(settings, terms, count_map=count_map)
        sub_rows = [_with_term_count(row, total_counts.get(int(row.get("id") or 0), direct_counts.get(int(row.get("id") or 0), 0))) for row in _subcategory_terms(terms, parent_id=submenu_parent_id) if int(row.get("id") or 0) in visible_ids]
        if sub_rows:
            owner_item = None
            for item in main_menu["items"]:
                if str(item["row"].get("id") or "") == str(submenu_parent_id):
                    owner_item = item
                    break

            # Start the subcategory panel from the hovered/selected category row
            # so the submenu stays reachable and does not appear too low.
            if owner_item is not None:
                submenu_box_top = int(owner_item["y1"]) - 2
            else:
                submenu_box_top = int((layout.get("category_box") or {}).get("y2", 0))

            pseudo_box = {
                "x1": main_menu["x2"] + 1,
                "x2": main_menu["x2"] + 1 + 230,
                "y2": submenu_box_top,
            }
            sub_menu = _dropdown_layout_for_box(pseudo_box, sub_rows, width=250)

    x1 = main_menu["x1"]
    y1 = main_menu["y1"]
    x2 = main_menu["x2"]
    y2 = main_menu["y2"]
    if sub_menu:
        x2 = max(x2, sub_menu["x2"])
        y2 = max(y2, sub_menu["y2"])

    return ("category", {
        "x1": x1,
        "y1": y1,
        "x2": x2,
        "y2": y2,
        "main": main_menu,
        "sub": sub_menu,
        "submenu_parent_id": submenu_parent_id,
    })


def _settings_panel_layout(settings, layout):
    """Build the in-strip settings panel layout (popover) anchored to the gear button."""
    if settings is None or not layout:
        return None
    gear = layout.get("settings_box")
    if not gear:
        return None

    panel_w = 360
    row_h = 28
    pad = 10
    gap = 2

    x2 = int(gear["x2"])
    try:
        with STATE_LOCK:
            anchor_x2 = int(STATE.get("settings_anchor_x2", 0) or 0)
            is_open = bool(STATE.get("settings_open", False))
        if is_open and anchor_x2 > 0:
            x2 = anchor_x2
    except Exception:
        pass
    x1 = x2 - panel_w
    # Clamp within strip bounds
    x1 = max(int(layout.get("left", 0)) - 10, x1)
    x2 = x1 + panel_w

    y1 = int(gear["y2"]) + 2
    rows = 7
    y2 = y1 + rows * row_h + pad * 2

    # Controls
    btn_w = 26
    value_w = 52
    label_w = panel_w - pad * 2 - (btn_w * 2) - value_w - 8

    def row_rect(i):
        ry1 = y1 + pad + i * row_h
        ry2 = ry1 + row_h
        return ry1, ry2

    # Header row (0)
    r0y1, r0y2 = row_rect(0)

    # Preview size row (1)
    r1y1, r1y2 = row_rect(1)
    # Hover scale row (2)
    r2y1, r2y2 = row_rect(2)
    # Assets folder button row (3)
    r3y1, r3y2 = row_rect(3)
    # Links row (4)
    r4y1, r4y2 = row_rect(4)
    # Links row (5)
    r5y1, r5y2 = row_rect(5)
    # Patreon row (6)
    r6y1, r6y2 = row_rect(6)

    # Buttons for row 1 & 2
    def buttons_for_row(ry1, ry2):
        bx2 = x2 - pad
        plus = {"x1": bx2 - btn_w, "y1": ry1 + 2, "x2": bx2, "y2": ry2 - 2}
        bx2 = plus["x1"] - gap
        value = {"x1": bx2 - value_w, "y1": ry1 + 2, "x2": bx2, "y2": ry2 - 2}
        bx2 = value["x1"] - gap
        minus = {"x1": bx2 - btn_w, "y1": ry1 + 2, "x2": bx2, "y2": ry2 - 2}
        label = {"x1": x1 + pad, "y1": ry1 + 2, "x2": minus["x1"] - gap, "y2": ry2 - 2}
        return label, minus, value, plus

    label1, minus1, value1, plus1 = buttons_for_row(r1y1, r1y2)
    label2, minus2, value2, plus2 = buttons_for_row(r2y1, r2y2)


    return {
        "x1": x1,
        "y1": y1,
        "x2": x2,
        "y2": y2,
        "header": {"x1": x1 + pad, "y1": r0y1, "x2": x2 - pad, "y2": r0y2},
        "row_preview": {"label": label1, "minus": minus1, "value": value1, "plus": plus1},
        "row_hover": {"label": label2, "minus": minus2, "value": value2, "plus": plus2},
        "assets_btn": {"x1": x1 + pad, "y1": r3y1 + 2, "x2": x2 - pad, "y2": r3y2 - 2},

        "website_btn": {"x1": x1 + pad, "y1": r4y1 + 2, "x2": int(x1 + pad + ((panel_w - pad * 2 - 6) * 0.5)), "y2": r4y2 - 2},
        "support_btn": {"x1": int(x1 + pad + ((panel_w - pad * 2 - 6) * 0.5) + 6), "y1": r4y1 + 2, "x2": x2 - pad, "y2": r4y2 - 2},

        "discord_btn": {"x1": x1 + pad, "y1": r5y1 + 2, "x2": int(x1 + pad + ((panel_w - pad * 2 - 6) * 0.5)), "y2": r5y2 - 2},
        "youtube_btn": {"x1": int(x1 + pad + ((panel_w - pad * 2 - 6) * 0.5) + 6), "y1": r5y1 + 2, "x2": x2 - pad, "y2": r5y2 - 2},

        "patreon_btn": {"x1": x1 + pad, "y1": r6y1 + 2, "x2": x2 - pad, "y2": r6y2 - 2},
    }



def _update_panel_layout(settings, layout):
    """In-strip update panel anchored to UPDATE AVAILABLE button."""
    if settings is None or not layout:
        return None
    box = layout.get("update_box")
    if not box or box["x2"] <= box["x1"]:
        return None

    panel_w = 380
    row_h = 28
    pad = 10
    gap = 6

    x1 = int(box["x1"])
    x2 = x1 + panel_w
    x2 = min(x2, int(layout.get("right", x2)) + 10)
    x1 = x2 - panel_w

    y1 = int(box["y2"]) + 2
    rows = 6
    y2 = y1 + rows * row_h + pad * 2

    def row_rect(i):
        ry1 = y1 + pad + i * row_h
        ry2 = ry1 + row_h
        return ry1, ry2

    r0y1, r0y2 = row_rect(0)
    r1y1, r1y2 = row_rect(1)
    r2y1, r2y2 = row_rect(2)
    r3y1, r3y2 = row_rect(3)
    r4y1, r4y2 = row_rect(4)
    r5y1, r5y2 = row_rect(5)

    btn_pad = 2
    update_now = {"x1": x1 + pad, "y1": r3y1 + btn_pad, "x2": x2 - pad, "y2": r3y2 - btn_pad}

    half = (x2 - x1 - pad * 2 - gap) * 0.5
    ignore_btn = {"x1": x1 + pad, "y1": r4y1 + btn_pad, "x2": int(x1 + pad + half), "y2": r4y2 - btn_pad}
    later_btn = {"x1": int(ignore_btn["x2"] + gap), "y1": r4y1 + btn_pad, "x2": x2 - pad, "y2": r4y2 - btn_pad}

    changelog_btn = {"x1": x1 + pad, "y1": r5y1 + btn_pad, "x2": x2 - pad, "y2": r5y2 - btn_pad}

    return {
        "x1": x1,
        "y1": y1,
        "x2": x2,
        "y2": y2,
        "header": {"x1": x1 + pad, "y1": r0y1, "x2": x2 - pad, "y2": r0y2},
        "row_versions": {"x1": x1 + pad, "y1": r1y1, "x2": x2 - pad, "y2": r1y2},
        "row_message": {"x1": x1 + pad, "y1": r2y1, "x2": x2 - pad, "y2": r2y2},
        "btn_update_now": update_now,
        "btn_ignore": ignore_btn,
        "btn_later": later_btn,
        "btn_changelog": changelog_btn,
    }

def _human_title_from_rendered(text):
    return re.sub(r"<[^>]+>", "", (text or "")).strip() or "Untitled"



def _guess_kind_from_link(link):
    path = urllib.parse.urlparse(link or "").path.lower()
    if "/textures/" in path:
        return "TEXTURE"
    if "/hdri/" in path:
        return "HDRI"
    if "/game-assets/" in path:
        return "GAME"
    return "MODEL"



def _asset_matches_selected_tab(asset, selected_type):
    selected_type = (selected_type or "model").strip().lower()
    kind = str(asset.get("kind") or "").upper()

    if selected_type == "texture":
        return kind == "TEXTURE"
    if selected_type == "hdri":
        return kind == "HDRI"
    return kind == "MODEL"


def _asset_type_key(value):
    key = str(value or "model").strip().lower()
    return key if key in {"model", "texture", "hdri"} else "model"



def _find_asset(asset_id):
    with STATE_LOCK:
        for asset in STATE["assets"]:
            if str(asset.get("id")) == str(asset_id):
                return dict(asset)
    return None



def _ensure_preview_dir():
    with STATE_LOCK:
        directory = STATE.get("preview_dir") or ""
        if directory and os.path.isdir(directory):
            return directory
        directory = tempfile.mkdtemp(prefix="fourdesinno_previews_")
        STATE["preview_dir"] = directory
        return directory



def _cleanup_preview_dir():
    with STATE_LOCK:
        directory = STATE.get("preview_dir") or ""
        STATE["preview_dir"] = ""
    if directory and os.path.isdir(directory):
        shutil.rmtree(directory, ignore_errors=True)


# ---------------------------------------------------------
# website parsing
# ---------------------------------------------------------


class F3DDownloadHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.downloads = []
        self._capture = False
        self._href = ""
        self._classes = set()
        self._text = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() != "a":
            return
        attrs_dict = {k.lower(): v for k, v in attrs}
        classes = set((attrs_dict.get("class") or "").split())
        href = attrs_dict.get("href") or ""
        if "f3d-download-btn" in classes and href:
            self._capture = True
            self._href = href
            self._classes = classes
            self._text = []

    def handle_data(self, data):
        if self._capture:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag.lower() != "a" or not self._capture:
            return
        label = " ".join("".join(self._text).split()).strip() or "Download"
        ext = os.path.splitext(urllib.parse.urlparse(self._href).path)[1].lower().strip(".")
        self.downloads.append({
            "label": label,
            "url": self._href,
            "extension": ext,
            "is_blend": ".blend" in label.lower() or ext == "blend" or "blend" in self._href.lower(),
            "classes": sorted(self._classes),
        })
        self._capture = False
        self._href = ""
        self._classes = set()
        self._text = []




class F3DArchiveHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.items = []
        self._in_link = False
        self._href = ""
        self._title = ""
        self._thumb = ""
        self._text = []
        self._saw_img = False

    def _looks_like_asset_href(self, href):
        path = urllib.parse.urlparse(href or "").path.lower().rstrip(r"\/")
        if not path:
            return False
        blocked = {"/3d-models", "/textures", "/hdri"}
        if path in blocked:
            return False
        return (
            path.startswith("/3d-models/")
            or path.startswith("/textures/")
            or path.startswith("/hdri/")
        )

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        attrs_dict = {k.lower(): v for k, v in attrs}
        classes = set((attrs_dict.get("class") or "").split())
        href = attrs_dict.get("href") or ""

        if tag == "a":
            if "f3d-item" in classes or self._looks_like_asset_href(href):
                self._in_link = True
                self._href = href
                self._title = ""
                self._thumb = ""
                self._text = []
                self._saw_img = False
                return

        if self._in_link and tag == "img":
            src = attrs_dict.get("src") or attrs_dict.get("data-src") or attrs_dict.get("data-lazy-src") or ""
            alt = attrs_dict.get("alt") or ""
            if src and not self._thumb:
                self._thumb = src
            if alt and not self._title:
                self._title = alt
            self._saw_img = True

    def handle_data(self, data):
        if self._in_link:
            self._text.append(data)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag == "a" and self._in_link:
            title = self._title.strip() or " ".join(" ".join(self._text).split()).strip() or "Untitled"
            href = self._href.strip()
            thumb = self._thumb.strip()
            if href and thumb and self._saw_img and self._looks_like_asset_href(href):
                self.items.append({"href": href, "title": title, "thumb": thumb})
            self._in_link = False
            self._href = ""
            self._title = ""
            self._thumb = ""
            self._text = []
            self._saw_img = False


def _build_archive_url(settings, page=1):
    asset_type = (settings.asset_type or "model").strip().lower()
    base = _archive_base_for_type(FOURDESINNO_SITE, asset_type).rstrip(r"\/")
    url = base + "/"
    params = []
    if int(page or 1) > 1:
        params.append(("f3d_page", str(int(page))))
    if asset_type == "texture":
        params.append(("f3d_format", "TEXTURE"))
    elif asset_type == "hdri":
        params.append(("f3d_format", "HDRI"))
    if settings.search_text.strip():
        params.append(("f3d_q", settings.search_text.strip()))
    _term_id, term_slug = _selected_filter_term(settings)
    if term_slug:
        params.append(("f3d_cat", term_slug))
    if params:
        url = url + "?" + urllib.parse.urlencode(params)
    return url


def _fetch_assets_page_from_archive(settings, page=1, per_page=20):
    if not _online_mode_enabled(settings):
        return []
    url = _build_archive_url(settings, page=page)
    data, _ctype, final_url, _headers = _request_bytes(url)
    html = data.decode("utf-8", errors="replace")

    parser = F3DArchiveHTMLParser()
    parser.feed(html)

    kind_map = {"model": "MODEL", "texture": "TEXTURE", "hdri": "HDRI"}
    kind = kind_map.get((settings.asset_type or "model").strip().lower(), "MODEL")

    assets = []
    seen = set()
    for item in parser.items:
        href = urllib.parse.urljoin(final_url, item.get("href") or "")
        if not href or href in seen:
            continue
        seen.add(href)
        slug = urllib.parse.urlparse(href).path.strip("/").split("/")[-1] or "asset"
        thumb = urllib.parse.urljoin(final_url, item.get("thumb") or "") if item.get("thumb") else ""
        title = (item.get("title") or slug or "Untitled").strip()
        assets.append({
            "id": slug,
            "slug": slug,
            "title": title,
            "excerpt": "",
            "link": href,
            "thumb": thumb,
            "kind": kind,
            "site_url": FOURDESINNO_SITE,
            "preview_path": "",
            "strip_preview_path": "",
        })

    return assets


def _build_rest_url(settings, page=1, per_page=20):
    site_url = FOURDESINNO_SITE
    endpoint = site_url + "/wp-json/wp/v2/f3d_model"
    params = {
        "_embed": "1",
        "per_page": str(max(1, min(100, per_page or 20))),
        "page": str(max(1, page or 1)),
        "orderby": "date",
        "order": "desc",
    }
    asset_type = (settings.asset_type or "model").strip().lower()
    if asset_type in {"texture", "hdri", "game"}:
        params["f3d_type"] = asset_type
    if settings.search_text.strip():
        params["search"] = settings.search_text.strip()
    term_id, _term_slug = _selected_filter_term(settings)
    if term_id:
        params["f3d_category"] = term_id
    return endpoint + "?" + urllib.parse.urlencode(params)



def _extract_featured_media(item):
    embedded = item.get("_embedded") or {}
    media = embedded.get("wp:featuredmedia") or []
    if not media:
        return ""
    media0 = media[0] or {}
    sizes = (((media0.get("media_details") or {}).get("sizes") or {}))
    for key in ("medium_large", "large", "medium", "thumbnail", "full"):
        row = sizes.get(key)
        if isinstance(row, dict) and row.get("source_url"):
            return row["source_url"]
    return media0.get("source_url") or ""



def _fetch_assets_page(settings, page=1, per_page=20):
    if not _online_mode_enabled(settings):
        return []
    try:
        payload = _request_json(_build_rest_url(settings, page=page, per_page=per_page))
    except urllib.error.HTTPError as exc:
        if getattr(exc, "code", None) == 400:
            return []
        raise
    except Exception:
        return []

    if not isinstance(payload, list):
        raise RuntimeError("Unexpected response from website.")
    assets = []
    site_url = FOURDESINNO_SITE
    for item in payload:
        if not isinstance(item, dict):
            continue
        asset_id = str(item.get("id") or "")
        link = (item.get("link") or "").strip()
        if not asset_id or not link:
            continue
        slug = item.get("slug") or asset_id
        thumb = _extract_featured_media(item)
        asset = {
            "id": asset_id,
            "slug": slug,
            "title": _human_title_from_rendered(((item.get("title") or {}).get("rendered") or "")),
            "excerpt": _human_title_from_rendered(((item.get("excerpt") or {}).get("rendered") or "")),
            "link": link,
            "thumb": thumb,
            "kind": _guess_kind_from_link(link),
            "site_url": site_url,
            "preview_path": "",
            "strip_preview_path": "",
        }
        if _asset_matches_selected_tab(asset, settings.asset_type):
            assets.append(asset)
    return assets


def _load_more_assets(settings, reset=False):
    asset_type_key = _asset_type_key(getattr(settings, "asset_type", "model"))

    with STATE_LOCK:
        if STATE.get("loading_more"):
            return 0
        STATE["loading_more"] = True
        favorites_only = bool(STATE.get("favorites_only", False))
        downloaded_only = bool(STATE.get("downloaded_only", False))
        existing_special_assets = [dict(a) for a in STATE.get("assets", [])] if (favorites_only or downloaded_only) else []
        if reset:
            STATE["assets"] = []
            STATE["next_page"] = 1
            STATE["has_more"] = True
            STATE["pending_assets"] = []

    try:
        with STATE_LOCK:
            page = int(STATE.get("next_page", 1))
            has_more = bool(STATE.get("has_more", True))
            pending_assets = list(STATE.get("pending_assets", []))
            existing_ids = {str(a.get("id")) for a in STATE["assets"]}
            existing_ids.update(str(a.get("id")) for a in pending_assets)
            display_slots = int(STATE.get("display_slots", max(1, settings.strip_count)))
            catalog_by_type = dict(STATE.get("asset_catalog_by_type", {}) or {})
            catalog_map = dict(catalog_by_type.get(asset_type_key, {}) or {})
            catalog_complete = bool((STATE.get("asset_catalog_complete_by_type", {}) or {}).get(asset_type_key, False))

        target_chunk = max(AUTO_LOAD_BATCH, display_slots)
        special_mode = favorites_only or downloaded_only

        if not _online_mode_enabled(settings):
            local_assets = _load_local_downloaded_assets(settings)
            if favorites_only:
                local_assets = [asset for asset in local_assets if _is_favorite(asset)]

            if not reset and pending_assets:
                source_assets = list(pending_assets)
            else:
                source_assets = [asset for asset in local_assets if str(asset.get("id") or "") not in existing_ids]

            collected = source_assets[:target_chunk]
            remaining_pending = source_assets[target_chunk:]
            with STATE_LOCK:
                if reset:
                    STATE["assets"] = []
                STATE["assets"].extend(collected)
                STATE["pending_assets"] = remaining_pending
                STATE["next_page"] = 1
                STATE["has_more"] = bool(remaining_pending)
                queue = list(STATE.get("thumb_queue", []))
                for asset in collected:
                    asset_id = str(asset.get("id") or "")
                    if asset_id and asset_id not in queue:
                        queue.append(asset_id)
                STATE["thumb_queue"] = queue

            label = "favorite local assets" if favorites_only else "local downloaded assets"
            _set_status(f"Loaded {len(collected)} {label}." + (" Scroll to load more." if remaining_pending else ""))
            _pump_preview_queue(max_items=1)
            return len(collected)

        # Fast path: build favorites/downloaded immediately from the in-session catalog if it is already complete.
        if special_mode and catalog_complete:
            filtered = []
            for asset in catalog_map.values():
                keep_asset = _is_favorite(asset) if favorites_only else _asset_is_downloaded(asset)
                if keep_asset:
                    filtered.append(dict(asset))
            filtered.sort(key=_special_mode_sort_key)
            filtered = _merge_special_mode_assets_preserve_existing(existing_special_assets, filtered)
            with STATE_LOCK:
                STATE["assets"] = filtered
                STATE["pending_assets"] = []
                STATE["next_page"] = page
                STATE["has_more"] = False
                queue = list(STATE.get("thumb_queue", []))
                for asset in filtered:
                    asset_id = str(asset.get("id") or "")
                    if asset_id and asset_id not in queue:
                        queue.append(asset_id)
                STATE["thumb_queue"] = queue
            mode_label = "favorites" if favorites_only else "downloaded assets"
            _set_status(f"Loaded {len(filtered)} {mode_label}. More thumbnails loading...")
            _pump_preview_queue(max_items=1)
            return len(filtered)

        fetch_page_size = 100 if special_mode else (AUTO_LOAD_PAGE_SCAN if asset_type_key == "model" else max(24, target_chunk))
        scanned_pages = 0
        max_pages_per_pass = 999 if special_mode else 4

        while has_more and scanned_pages < max_pages_per_pass:
            if not special_mode and len(pending_assets) >= target_chunk:
                break

            if asset_type_key == "model":
                page_assets = _fetch_assets_page(settings, page=page, per_page=fetch_page_size)
            else:
                page_assets = _fetch_assets_page_from_archive(settings, page=page, per_page=fetch_page_size)
            scanned_pages += 1

            if not page_assets:
                has_more = False
                break

            # update session catalog from every fetched page
            for asset in page_assets:
                asset_id = str(asset.get("id") or "")
                if not asset_id:
                    continue
                catalog_map[asset_id] = dict(asset)

            for asset in page_assets:
                asset_id = str(asset.get("id"))
                if asset_id in existing_ids:
                    continue

                keep_asset = True
                if favorites_only:
                    keep_asset = _is_favorite(asset)
                elif downloaded_only:
                    keep_asset = _asset_is_downloaded(asset)

                if not keep_asset:
                    continue

                existing_ids.add(asset_id)
                pending_assets.append(asset)

            if len(page_assets) < fetch_page_size:
                has_more = False

            page += 1

        # if we reached the end for this asset type, the in-session catalog is now complete
        catalog_complete = not has_more

        if special_mode:
            collected = list(pending_assets)
            collected.sort(key=_special_mode_sort_key)
            collected = _merge_special_mode_assets_preserve_existing(existing_special_assets, collected)
            remaining_pending = []
            has_more = False
        else:
            collected = pending_assets[:target_chunk]
            remaining_pending = pending_assets[target_chunk:]

        with STATE_LOCK:
            catalog_by_type = dict(STATE.get("asset_catalog_by_type", {}) or {})
            catalog_by_type[asset_type_key] = dict(catalog_map)
            STATE["asset_catalog_by_type"] = catalog_by_type

            complete_by_type = dict(STATE.get("asset_catalog_complete_by_type", {}) or {})
            complete_by_type[asset_type_key] = bool(catalog_complete)
            STATE["asset_catalog_complete_by_type"] = complete_by_type

            STATE["assets"].extend(collected)
            STATE["pending_assets"] = remaining_pending
            STATE["next_page"] = page
            STATE["has_more"] = has_more or bool(remaining_pending)
            queue = list(STATE.get("thumb_queue", []))
            for asset in collected:
                asset_id = str(asset.get("id") or "")
                if asset_id and asset_id not in queue:
                    queue.append(asset_id)
            STATE["thumb_queue"] = queue

        if special_mode:
            mode_label = "favorites" if favorites_only else "downloaded assets"
            _set_status(f"Loaded {len(collected)} {mode_label}. More thumbnails loading...")
        else:
            _set_status(f"Loaded {len(collected)} new previews. More thumbnails loading...")
        _pump_preview_queue(max_items=1)

        return len(collected)
    finally:
        with STATE_LOCK:
            STATE["loading_more"] = False


def _fetch_blend_download_url(asset):
    page_url = asset.get("link") or ""
    if not page_url:
        raise RuntimeError("Asset page URL missing.")
    data, _ctype, final_url, _headers = _request_bytes(page_url)
    html = data.decode("utf-8", errors="replace")
    parser = F3DDownloadHTMLParser()
    parser.feed(html)
    blend_urls = []
    seen = set()
    for row in parser.downloads:
        if not row.get("is_blend"):
            continue
        url = urllib.parse.urljoin(final_url, row.get("url") or "")
        if not url or url in seen:
            continue
        seen.add(url)
        blend_urls.append(url)
    if not blend_urls:
        raise RuntimeError("No .blend download found on this asset page.")
    return blend_urls[0]


# ---------------------------------------------------------
# preview images
# ---------------------------------------------------------


def _download_to_file(url, filepath):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response, open(filepath, "wb") as handle:
        shutil.copyfileobj(response, handle)
    return filepath



def _ensure_asset_preview_file(asset):
    preview_path = asset.get("preview_path") or ""
    if preview_path and os.path.exists(preview_path):
        return preview_path

    try:
        cached_raw = _preview_image_cache_paths(asset).get("raw") or ""
    except Exception:
        cached_raw = ""
    if cached_raw and os.path.exists(cached_raw):
        asset["preview_path"] = cached_raw
        return cached_raw

    thumb_url = asset.get("thumb") or ""
    if not thumb_url:
        return ""
    preview_dir = _ensure_preview_dir()
    ext = os.path.splitext(urllib.parse.urlparse(thumb_url).path)[1] or ".jpg"
    path = os.path.join(preview_dir, _sanitize_filename(f"{asset['id']}_{asset['slug']}{ext}", fallback=f"{asset['id']}.jpg"))
    if not os.path.exists(path):
        _download_to_file(thumb_url, path)
    asset["preview_path"] = path
    return path


def _pixel_is_near_white(pixel, threshold=240):
    try:
        r, g, b, a = pixel
    except Exception:
        return False
    return a > 0 and r >= threshold and g >= threshold and b >= threshold


def _remove_white_border_to_alpha(rgba, threshold=240):
    """
    Remove white matte/background only when it is connected to the image border.
    This avoids deleting light details inside the product itself.
    """
    try:
        rgba = rgba.convert("RGBA")
        w, h = rgba.size
        if w <= 0 or h <= 0:
            return rgba

        px = rgba.load()
        q = deque()
        seen = set()

        def push(x, y):
            if x < 0 or y < 0 or x >= w or y >= h:
                return
            if (x, y) in seen:
                return
            if not _pixel_is_near_white(px[x, y], threshold=threshold):
                return
            seen.add((x, y))
            q.append((x, y))

        for x in range(w):
            push(x, 0)
            push(x, h - 1)
        for y in range(h):
            push(0, y)
            push(w - 1, y)

        while q:
            x, y = q.popleft()
            r, g, b, a = px[x, y]
            px[x, y] = (r, g, b, 0)
            push(x - 1, y)
            push(x + 1, y)
            push(x, y - 1)
            push(x, y + 1)

        return rgba
    except Exception:
        return rgba


def _ensure_display_preview_file(asset):
    """
    Runtime-only display preview used by the strip/hover drawing.
    It stays inside the temporary preview cache, not the permanent asset cache.
    Removes white matte connected to the border, then crops remaining transparent
    margins so the object appears larger in the card without changing the source file.
    """
    display_path = asset.get("display_preview_path") or ""
    if display_path and os.path.exists(display_path):
        return display_path

    try:
        cached_display = _preview_image_cache_paths(asset).get("display") or ""
    except Exception:
        cached_display = ""
    if cached_display and os.path.exists(cached_display):
        asset["display_preview_path"] = cached_display
        return cached_display

    src_path = _ensure_asset_preview_file(asset)
    if not src_path or not os.path.exists(src_path):
        return ""

    # No PIL => just use the original runtime preview file.
    if Image is None:
        asset["display_preview_path"] = src_path
        return src_path

    preview_dir = _ensure_preview_dir()
    cropped_dir = os.path.join(preview_dir, "_display")
    os.makedirs(cropped_dir, exist_ok=True)

    out_path = os.path.join(
        cropped_dir,
        _sanitize_filename(f"{asset.get('id','asset')}_{asset.get('slug','preview')}_display_v2.png", "display_v2.png")
    )

    if os.path.exists(out_path):
        asset["display_preview_path"] = out_path
        return out_path

    try:
        with Image.open(src_path) as im:
            im.load()
            original_rgba = im.convert("RGBA")
            rgba = original_rgba.copy()

            # Remove white matte/background that touches the image border.
            rgba = _remove_white_border_to_alpha(rgba, threshold=240)

            # Crop remaining transparent margins so the object fills the preview better.
            alpha = rgba.getchannel("A")
            bbox = alpha.getbbox()
            if bbox:
                pad = 6
                x1 = max(0, bbox[0] - pad)
                y1 = max(0, bbox[1] - pad)
                x2 = min(rgba.width, bbox[2] + pad)
                y2 = min(rgba.height, bbox[3] + pad)
                rgba = rgba.crop((x1, y1, x2, y2))

            # If nothing visually changed, reuse the raw preview instead of creating a duplicate display file.
            if rgba.size == original_rgba.size and rgba.tobytes() == original_rgba.tobytes():
                asset["display_preview_path"] = src_path
                try:
                    if os.path.exists(out_path):
                        os.remove(out_path)
                except Exception:
                    pass
                return src_path

            rgba.save(out_path, optimize=True)

        asset["display_preview_path"] = out_path
        return out_path
    except Exception:
        asset["display_preview_path"] = src_path
        return src_path



def _get_bpy_image(filepath):
    key = os.path.abspath(filepath)
    img = IMAGE_CACHE.get(key)
    if img and img.name in bpy.data.images:
        return img
    try:
        img = bpy.data.images.load(key, check_existing=True)
        try:
            ext = os.path.splitext(key)[1].lower()
            if ext in {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}:
                try:
                    img.colorspace_settings.name = "sRGB"
                except Exception:
                    pass
            try:
                img.alpha_mode = 'STRAIGHT'
            except Exception:
                pass
        except Exception:
            pass
        IMAGE_CACHE[key] = img
        return img
    except Exception:
        return None



def _get_gpu_texture(filepath):
    key = os.path.abspath(filepath)
    tex = GPU_TEXTURE_CACHE.get(key)
    if tex is not None:
        return tex
    img = _get_bpy_image(key)
    if not img:
        return None
    try:
        tex = gpu.texture.from_image(img)
        GPU_TEXTURE_CACHE[key] = tex
        return tex
    except Exception:
        return None




def _draw_fitted_texture_in_rect(filepath, x1, y1, x2, y2, target_ratio=None):
    tex = _get_gpu_texture(filepath)
    img = _get_bpy_image(filepath)
    if tex is None or img is None:
        return False

    try:
        img_w = max(1, int(img.size[0]))
        img_h = max(1, int(img.size[1]))
    except Exception:
        img_w = img_h = 1

    box_w = max(1, x2 - x1)
    box_h = max(1, y2 - y1)
    image_ratio = float(target_ratio) if target_ratio else (img_w / img_h)
    box_ratio = box_w / box_h

    if image_ratio > box_ratio:
        draw_w = box_w
        draw_h = max(1, int(draw_w / image_ratio))
        off_x = x1
        off_y = y1 + int((box_h - draw_h) * 0.5)
    else:
        draw_h = box_h
        draw_w = max(1, int(draw_h * image_ratio))
        off_x = x1 + int((box_w - draw_w) * 0.5)
        off_y = y1

    try:
        gpu.state.blend_set('ALPHA')
        draw_texture_2d(tex, (off_x, off_y), draw_w, draw_h)
        gpu.state.blend_set('NONE')
        return True
    except Exception:
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass
        return False


def _clear_preview_runtime_cache():
    GPU_TEXTURE_CACHE.clear()
    for key, img in list(IMAGE_CACHE.items()):
        try:
            if img and img.users == 0 and img.name in bpy.data.images:
                bpy.data.images.remove(img)
        except Exception:
            pass
    IMAGE_CACHE.clear()



def _ensure_asset_blend_external_resources(filepath, asset):
    """
    Best-effort preprocessing on the cached asset library file itself:
    - open the downloaded asset.blend in a separate background Blender
    - unpack packed images into <asset folder>/textures
    - repoint image filepaths to those local files using relative paths
    - save the library file again

    Keep the asset folder clean afterward:
    - asset.blend
    - textures/
    """
    try:
        if not filepath or not os.path.exists(filepath):
            return filepath

        asset_dir = _asset_dir(asset)
        textures_dir = _asset_texture_dir(asset)
        blender_bin = getattr(bpy.app, "binary_path", "") or ""
        if not blender_bin or not os.path.exists(blender_bin):
            return filepath

        backup_path = filepath + "1"
        script_path = os.path.join(asset_dir, "_externalize_resources.py")

        try:
            existing_textures = os.listdir(textures_dir)
        except Exception:
            existing_textures = []
        if existing_textures and not os.path.exists(backup_path):
            return filepath

        script = r"""
import bpy
import os
import sys
import time
import shutil

blend_path = sys.argv[-2]
textures_dir = sys.argv[-1]

try:
    bpy.ops.wm.open_mainfile(filepath=blend_path)
    os.makedirs(textures_dir, exist_ok=True)

    try:
        bpy.ops.file.unpack_all(method='USE_LOCAL')
    except Exception:
        pass

    for img in bpy.data.images:
        try:
            if getattr(img, "source", "") != 'FILE':
                continue

            src = bpy.path.abspath(img.filepath or "")
            src = os.path.normpath(src) if src else ""
            if not src or not os.path.exists(src):
                continue

            base = os.path.basename(src)
            dst = os.path.join(textures_dir, base)

            if os.path.abspath(src) != os.path.abspath(dst):
                if not os.path.exists(dst):
                    shutil.copy2(src, dst)

            img.filepath = bpy.path.relpath(dst)
        except Exception:
            pass

    bpy.ops.wm.save_mainfile(filepath=blend_path, compress=False)
except Exception:
    pass
"""
        with open(script_path, "w", encoding="utf-8") as handle:
            handle.write(script)

        cmd = [
            blender_bin,
            "--background",
            "--factory-startup",
            "--python",
            script_path,
            "--",
            filepath,
            textures_dir,
        ]
        try:
            subprocess.run(
                cmd,
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=max(30, REQUEST_TIMEOUT),
            )
        except Exception:
            pass
        finally:
            try:
                if os.path.exists(script_path):
                    os.remove(script_path)
            except Exception:
                pass
            try:
                if os.path.exists(backup_path):
                    os.remove(backup_path)
            except Exception:
                pass
            for leftover in (
                os.path.join(asset_dir, ".resources_externalized"),
                os.path.join(asset_dir, ".resources_externalized-fail"),
                os.path.join(asset_dir, "._resources_externalized-fail"),
                os.path.join(asset_dir, ".recources_externalized-fail"),
                os.path.join(asset_dir, "._recources_externalized-fail"),
            ):
                try:
                    if os.path.exists(leftover):
                        os.remove(leftover)
                except Exception:
                    pass

    except Exception:
        pass

    return filepath


# ---------------------------------------------------------
# import helpers
# ---------------------------------------------------------


def _match_best_library_name(candidates, asset):
    if not candidates:
        return None
    slug = str(asset.get("slug") or "").strip().lower()
    title = str(asset.get("title") or "").strip().lower()
    wanted = [v for v in (slug, title) if v]
    exact = None
    partial = None
    for name in candidates:
        n = str(name or "").strip()
        nl = n.lower()
        if any(nl == w for w in wanted):
            exact = n
            break
        if partial is None and any(w in nl or nl in w for w in wanted):
            partial = n
    return exact or partial or candidates[0]


def _capture_existing_names():
    return {
        "objects": {obj.name for obj in bpy.data.objects},
        "collections": {col.name for col in bpy.data.collections},
    }



def _newly_imported_payload(before_names):
    new_collections = [col for col in bpy.data.collections if col.name not in before_names["collections"]]
    new_objects = [obj for obj in bpy.data.objects if obj.name not in before_names["objects"]]
    return {"collections": new_collections, "objects": new_objects}


def _append_primary_from_blend(filepath, asset, link=False):
    before_names = _capture_existing_names()

    with bpy.data.libraries.load(filepath, link=link) as (data_from, data_to):
        collections = list(getattr(data_from, "collections", []) or [])
        objects = list(getattr(data_from, "objects", []) or [])

        if collections:
            data_to.collections = list(collections)
        elif objects:
            data_to.objects = list(objects)
        else:
            raise RuntimeError("No collections or objects found in the .blend file.")

    imported = _newly_imported_payload(before_names)
    target_collection = bpy.context.collection

    imported_collection_objects = set()
    for col in imported["collections"]:
        try:
            already = any(child == col for child in target_collection.children)
            if not already:
                target_collection.children.link(col)
            for obj in col.all_objects:
                imported_collection_objects.add(obj)
        except Exception:
            pass

    for obj in imported["objects"]:
        if obj in imported_collection_objects:
            continue
        try:
            if not any(c == target_collection for c in obj.users_collection):
                target_collection.objects.link(obj)
        except Exception:
            pass

    return imported



def _append_from_blend(filepath, link=False):
    asset = {"slug": os.path.splitext(os.path.basename(filepath))[0], "title": os.path.splitext(os.path.basename(filepath))[0]}
    return _append_primary_from_blend(filepath, asset, link=link)



def _set_selected_objects(objects):
    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        pass
    active = None
    for obj in objects:
        try:
            obj.select_set(True)
            if active is None:
                active = obj
        except Exception:
            pass
    if active is not None:
        try:
            bpy.context.view_layer.objects.active = active
        except Exception:
            pass



def _move_imported_payload(imported, location):
    if location is None:
        return
    location = Vector(location)

    if imported.get("collections"):
        roots = []
        child_objects = set()
        for col in imported["collections"]:
            for obj in col.all_objects:
                child_objects.add(obj)
        for obj in child_objects:
            if obj.parent not in child_objects:
                roots.append(obj)
        if roots:
            pivot = roots[0].location.copy()
            delta = location - pivot
            for obj in roots:
                obj.location = obj.location + delta
            _set_selected_objects(roots)
            return

    objects = imported.get("objects") or []
    if objects:
        pivot = objects[0].location.copy()
        delta = location - pivot
        for obj in objects:
            if obj.parent is None:
                obj.location = obj.location + delta
        _set_selected_objects(objects)



def _get_drop_location(context, event):
    region = context.region
    region_data = context.region_data
    if region is None or region_data is None:
        return context.scene.cursor.location.copy()
    coord = (event.mouse_region_x, event.mouse_region_y)
    origin = view3d_utils.region_2d_to_origin_3d(region, region_data, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, region_data, coord)
    depsgraph = context.evaluated_depsgraph_get()
    hit, location, _normal, _face, _obj, _mat = context.scene.ray_cast(depsgraph, origin, direction)
    if hit:
        return location
    plane_point = context.scene.cursor.location.copy()
    plane_normal = Vector((0.0, 0.0, 1.0))
    point = intersect_line_plane(origin, origin + direction * 100000.0, plane_point, plane_normal, False)
    return point if point is not None else plane_point


# ---------------------------------------------------------
# download job
# ---------------------------------------------------------


class DownloadJob:
    def __init__(self, asset):
        self.asset = dict(asset)
        self.filepath = ""
        self.error = ""
        self.success = False
        self.done = False
        self.cancel_requested = False
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def cancel(self):
        self.cancel_requested = True

    def _run(self):
        try:
            cached = _asset_cache_path(self.asset)
            if os.path.exists(cached) and os.path.getsize(cached) > 0:
                self.filepath = _ensure_asset_blend_external_resources(cached, self.asset)
                self.success = True
                self.done = True
                _store_asset_preview_in_cache(self.asset)
                _set_download(self.asset.get("title") or "Asset", "Using cached asset folder", 1, 1)
                return

            blend_url = _fetch_blend_download_url(self.asset)
            req = urllib.request.Request(blend_url, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response:
                final_url = response.geturl()
                total = int(response.headers.get("Content-Length") or 0)
                tmp_dir = tempfile.mkdtemp(prefix="fourdesinno_asset_tmp_")
                suffix = os.path.splitext(urllib.parse.urlparse(final_url).path)[1].lower()
                if suffix != ".blend":
                    suffix = ".blend"
                tmp_path = os.path.join(tmp_dir, _sanitize_filename(f"{self.asset.get('id')}_{self.asset.get('slug')}{suffix}", "asset.blend"))
                done = 0
                _set_download(self.asset.get("title") or "Asset", "Downloading .blend", 0, total)
                with open(tmp_path, "wb") as handle:
                    while True:
                        if self.cancel_requested:
                            raise RuntimeError("Download cancelled.")
                        chunk = response.read(1024 * 256)
                        if not chunk:
                            break
                        handle.write(chunk)
                        done += len(chunk)
                        _set_download(self.asset.get("title") or "Asset", "Downloading .blend", done, total)
                final_path = _asset_cache_path(self.asset)
                os.makedirs(os.path.dirname(final_path), exist_ok=True)
                shutil.move(tmp_path, final_path)
                self.filepath = _ensure_asset_blend_external_resources(final_path, self.asset)
                self.success = True
                _store_asset_preview_in_cache(self.asset)
            self.done = True
        except Exception as exc:
            self.error = str(exc)
            self.done = True
            self.success = False


# ---------------------------------------------------------
# viewport strip drawing / layout
# ---------------------------------------------------------


def _draw_rect(x1, y1, x2, y2, color):
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRIS', {
        "pos": [(x1, y1), (x2, y1), (x1, y2), (x2, y1), (x2, y2), (x1, y2)]
    })
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


def _draw_vertical_gradient_rect(x1, y1, x2, y2, color_bottom, color_top):
    try:
        shader = gpu.shader.from_builtin('SMOOTH_COLOR')
        batch = batch_for_shader(shader, 'TRIS', {
            "pos": [(x1, y1), (x2, y1), (x1, y2), (x2, y1), (x2, y2), (x1, y2)],
            "color": [color_bottom, color_bottom, color_top, color_bottom, color_top, color_top],
        })
        gpu.state.blend_set('ALPHA')
        batch.draw(shader)
        gpu.state.blend_set('NONE')
    except Exception:
        try:
            gpu.state.blend_set('NONE')
        except Exception:
            pass
        _draw_rect(x1, y1, x2, y2, color_bottom)



def _draw_outline(x1, y1, x2, y2, color):
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    verts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2), (x1, y1)]
    batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": verts})
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


def _draw_box(x1, y1, x2, y2, fill, border=None, border_px=1):
    _draw_rect(x1, y1, x2, y2, fill)
    if border is None or border_px <= 0:
        return
    border_px = max(1, int(border_px))
    _draw_rect(x1, y2 - border_px, x2, y2, border)
    _draw_rect(x1, y1, x2, y1 + border_px, border)
    _draw_rect(x1, y1, x1 + border_px, y2, border)
    _draw_rect(x2 - border_px, y1, x2, y2, border)


def _draw_box_without_bottom_border(x1, y1, x2, y2, fill, border=None, border_px=1):
    _draw_rect(x1, y1, x2, y2, fill)
    if border is None or border_px <= 0:
        return
    border_px = max(1, int(border_px))
    # y1 is the lower edge, y2 is the upper edge in this UI coordinate space
    # so omit the bottom border and keep the top + left + right borders
    _draw_rect(x1, y2 - border_px, x2, y2, border)
    _draw_rect(x1, y1, x1 + border_px, y2, border)
    _draw_rect(x2 - border_px, y1, x2, y2, border)



def _draw_text(x, y, text, size=12, color=(1, 1, 1, 1)):
    font_id = 0
    blf.position(font_id, x, y, 0)
    blf.size(font_id, size)
    blf.color(font_id, *color)
    blf.draw(font_id, text)


def _draw_text_centered_in_rect(x1, y1, x2, y2, text, size=12, color=(1, 1, 1, 1)):
    font_id = 0
    blf.size(font_id, size)
    try:
        tw, th = blf.dimensions(font_id, text)
    except Exception:
        tw, th = (0, 0)
    tx = x1 + ((x2 - x1) - tw) * 0.5
    ty = y1 + ((y2 - y1) - th) * 0.5 + 1
    blf.position(font_id, tx, ty, 0)
    blf.color(font_id, *color)
    blf.draw(font_id, text)



def _draw_text_right_aligned_in_rect(x1, y1, x2, y2, text, size=12, color=(1, 1, 1, 1), right_pad=8):
    font_id = 0
    text = str(text or "")
    try:
        blf.size(font_id, size)
    except TypeError:
        # Blender < 4.0 required the DPI arg; Blender 4.0+ removed it.
        try:
            blf.size(font_id, size, 72)
        except Exception:
            pass
    try:
        tw, th = blf.dimensions(font_id, text)
    except Exception:
        tw, th = (0, 0)
    tx = x2 - int(right_pad) - tw
    ty = y1 + ((y2 - y1) - th) * 0.5 + 1
    blf.position(font_id, tx, ty, 0)
    blf.color(font_id, *color)
    blf.draw(font_id, text)


def _clip_text(text, limit):
    text = text or ""
    return text if len(text) <= limit else text[: max(0, limit - 1)] + "…"



def _visible_assets(settings):
    with STATE_LOCK:
        assets = [dict(a) for a in STATE["assets"]]
        has_more = bool(STATE.get("has_more", False))
        favorites_only = bool(STATE.get("favorites_only", False))
        downloaded_only = bool(STATE.get("downloaded_only", False))
        favorites = set(STATE.get("favorites", set()))
        display_slots = int(STATE.get("display_slots", max(1, settings.strip_count)))
    if favorites_only:
        assets = [a for a in assets if _favorite_key(a) in favorites]
        has_more = False
    elif downloaded_only:
        assets = [a for a in assets if _asset_is_downloaded(a)]
        has_more = False
    count = max(1, display_slots)
    offset = max(0, settings.strip_offset)
    visible_count = max(0, count - 1) if has_more and count > 1 else count
    return assets[offset: offset + visible_count], len(assets)



def _compute_strip_layout_for_area(area, settings):
    region = None
    for r in area.regions:
        if r.type == 'WINDOW':
            region = r
            break
    if region is None:
        return None

    with STATE_LOCK:
        assets_all = [dict(a) for a in STATE["assets"]]
        has_more = bool(STATE.get("has_more", False))
        favorites_only = bool(STATE.get("favorites_only", False))
        downloaded_only = bool(STATE.get("downloaded_only", False))
        favorites = set(STATE.get("favorites", set()))
    if favorites_only:
        assets_all = [a for a in assets_all if _favorite_key(a) in favorites]
        has_more = False
    elif downloaded_only:
        assets_all = [a for a in assets_all if _asset_is_downloaded(a)]
        has_more = False
    total = len(assets_all)

    width = region.width
    height = region.height

    outer_margin = 8
    inner_pad = 14
    gap = 0
    arrow_w = 30
    header_h = 26
    header_gap = 0
    expanded = bool(getattr(settings, "strip_expanded", False))

    prefs = _addon_prefs()
    preview_pref = 108
    try:
        if prefs is not None:
            preview_pref = max(72, int(getattr(prefs, "preview_card_size", 108) or 108))
    except Exception:
        preview_pref = 108

    bottom = 10
    if expanded:
        preview_h = max(72, min(preview_pref, max(72, height - 80)))
        preview_bottom = bottom
        preview_top = preview_bottom + preview_h
        separator_y = preview_top + 4
        row_bottom = separator_y + 1
    else:
        preview_h = 0
        preview_bottom = bottom
        preview_top = preview_bottom
        separator_y = bottom - 1
        row_bottom = bottom

    row_top = row_bottom + header_h
    top = row_top + header_gap

    left = outer_margin
    right = width - outer_margin
    content_left = left + inner_pad
    content_right = right - inner_pad

    image_size = max(54, preview_pref - 12)
    card_w = image_size + 12

    preview_left = content_left
    preview_right = content_right

    if expanded:
        left_arrow = {
            "x1": preview_left,
            "y1": preview_bottom,
            "x2": preview_left + arrow_w,
            "y2": preview_top,
            "dir": -1,
        }
        right_arrow = {
            "x1": preview_right - arrow_w,
            "y1": preview_bottom,
            "x2": preview_right,
            "y2": preview_top,
            "dir": 1,
        }
        cards_start_x = left_arrow["x2"]
        cards_end_x = right_arrow["x1"]
        available_cards_w = max(card_w, cards_end_x - cards_start_x)
        display_slots = max(4, min(100, int(available_cards_w // card_w)))
        if display_slots < 1:
            display_slots = 1
        total_cards_w = display_slots * card_w + max(0, display_slots - 1) * gap
        cards_end_x = cards_start_x + total_cards_w
        right_arrow["x1"] = cards_end_x
        right_arrow["x2"] = cards_end_x + arrow_w
        content_right = right_arrow["x2"]
        right = max(right, content_right + inner_pad)
    else:
        left_arrow = None
        right_arrow = None
        cards_start_x = content_left
        cards_end_x = content_right
        available_cards_w = max(card_w, cards_end_x - cards_start_x)
        display_slots = max(4, min(100, int(available_cards_w // card_w)))

    tab_gap = 0
    tab_y1 = row_bottom
    tab_y2 = row_top

    tab1_w = 88
    tab2_w = 82
    tab3_w = 64
    fav_w = 72
    downloaded_w = 92

    tab1 = {"x1": cards_start_x, "y1": tab_y1, "x2": cards_start_x + tab1_w, "y2": tab_y2, "type": "model"}
    tab2 = {"x1": tab1["x2"] + tab_gap, "y1": tab_y1, "x2": tab1["x2"] + tab_gap + tab2_w, "y2": tab_y2, "type": "texture"}
    tab3 = {"x1": tab2["x2"] + tab_gap, "y1": tab_y1, "x2": tab2["x2"] + tab_gap + tab3_w, "y2": tab_y2, "type": "hdri"}

    fav_filter_box = {
        "x1": tab3["x2"] + tab_gap,
        "y1": row_bottom,
        "x2": tab3["x2"] + tab_gap + fav_w,
        "y2": row_top,
    }
    downloaded_filter_box = {
        "x1": fav_filter_box["x2"] + tab_gap,
        "y1": row_bottom,
        "x2": fav_filter_box["x2"] + tab_gap + downloaded_w,
        "y2": row_top,
    }

    load_w = 30
    toggle_w = 92
    toggle_box = {
        "x1": downloaded_filter_box["x2"] + 12,
        "y1": row_bottom,
        "x2": downloaded_filter_box["x2"] + 12 + toggle_w,
        "y2": row_top,
    }
    power_w = 30

    search_w = 230
    action_w = 26
    action_gap = 0
    search_cx = int((cards_start_x + cards_end_x) * 0.5)
    group_w = search_w + action_gap + action_w + action_gap + action_w
    group_x1 = search_cx - group_w // 2

    search_box = {
        "x1": group_x1,
        "y1": row_bottom - 1,
        "x2": group_x1 + search_w,
        "y2": row_top,
    }
    search_clear_box = {
        "x1": search_box["x2"] + action_gap,
        "y1": row_bottom - 1,
        "x2": search_box["x2"] + action_gap + action_w,
        "y2": row_top,
    }
    search_go_box = {
        "x1": search_clear_box["x2"] + action_gap,
        "y1": row_bottom - 1,
        "x2": search_clear_box["x2"] + action_gap + action_w,
        "y2": row_top,
    }

    cat_w = 180
    category_box = {
        "x1": search_go_box["x2"] + 6,
        "y1": row_bottom,
        "x2": search_go_box["x2"] + 6 + cat_w,
        "y2": row_top,
    }
    load_box = {
        "x1": category_box["x2"] + 6,
        "y1": row_bottom,
        "x2": category_box["x2"] + 6 + load_w,
        "y2": row_top,
    }

    # Update available button (only shown when update is available)
    with STATE_LOCK:
        _info = dict(STATE.get("update_info", {}) or {})
    _latest = str(_info.get("latest_version") or "").strip()
    has_update = bool(_latest) and _parse_version_value(_latest) > _local_addon_version()

    update_w = 138 if has_update else 0
    update_box = {
        "x1": load_box["x2"] + (6 if has_update else 0),
        "y1": row_bottom,
        "x2": load_box["x2"] + (6 if has_update else 0) + update_w,
        "y2": row_top,
    }
    subcategory_box = None

    min_search_x1 = toggle_box["x2"] + 18
    if search_box["x1"] < min_search_x1:
        shift = min_search_x1 - search_box["x1"]
        search_box["x1"] += shift
        search_box["x2"] += shift
        search_clear_box["x1"] += shift
        search_clear_box["x2"] += shift
        search_go_box["x1"] += shift
        search_go_box["x2"] += shift
        category_box["x1"] += shift
        category_box["x2"] += shift
        load_box["x1"] += shift
        load_box["x2"] += shift
        update_box["x1"] += shift
        update_box["x2"] += shift

    power_box = {
        "x1": cards_end_x - power_w,
        "y1": row_bottom,
        "x2": cards_end_x,
        "y2": row_top,
    }

    settings_w = 30
    settings_box = {
        "x1": power_box["x1"] - settings_w,
        "y1": row_bottom,
        "x2": power_box["x1"],
        "y2": row_top,
    }

    move_w = settings_w
    move_box = {
        "x1": settings_box["x1"] - move_w,
        "y1": row_bottom,
        "x2": settings_box["x1"],
        "y2": row_top,
    }

    label_w = 270
    label_box = {
        "x1": max(update_box["x2"] + 18, move_box["x1"] - 8 - label_w),
        "y1": row_bottom,
        "x2": move_box["x1"] - 8,
        "y2": row_top,
    }

    if update_box["x2"] > label_box["x1"] - 18:
        shift = update_box["x2"] - (label_box["x1"] - 18)
        search_box["x1"] -= shift
        search_box["x2"] -= shift
        search_clear_box["x1"] -= shift
        search_clear_box["x2"] -= shift
        search_go_box["x1"] -= shift
        search_go_box["x2"] -= shift
        category_box["x1"] -= shift
        category_box["x2"] -= shift
        load_box["x1"] -= shift
        load_box["x2"] -= shift
        update_box["x1"] -= shift
        update_box["x2"] -= shift
        if search_box["x1"] < min_search_x1:
            shift_fix = min_search_x1 - search_box["x1"]
            search_box["x1"] += shift_fix
            search_box["x2"] += shift_fix
            search_clear_box["x1"] += shift_fix
            search_clear_box["x2"] += shift_fix
            search_go_box["x1"] += shift_fix
            search_go_box["x2"] += shift_fix
            category_box["x1"] += shift_fix
            category_box["x2"] += shift_fix
            load_box["x1"] += shift_fix
            load_box["x2"] += shift_fix

    if expanded:
        offset = max(0, settings.strip_offset)
        visible_count = max(0, display_slots - 1) if has_more and display_slots > 1 else display_slots
        visible = assets_all[offset: offset + visible_count]
    else:
        visible = []

    cards = []
    x = cards_start_x
    for idx, asset in enumerate(visible):
        cards.append({
            "asset": asset,
            "index": idx,
            "x1": x,
            "y1": preview_bottom,
            "x2": x + card_w,
            "y2": preview_top,
            "ix1": x + 1,
            "iy1": preview_bottom + 1,
            "ix2": x + 1 + image_size,
            "iy2": preview_bottom + 1 + image_size,
            "fav_x1": x + card_w - 20,
            "fav_y1": preview_bottom + 1,
            "fav_x2": x + card_w - 1,
            "fav_y2": preview_bottom + 20,
        })
        x += card_w + gap

    with STATE_LOCK:
        STATE["display_slots"] = display_slots

    return {
        "area": area,
        "region": region,
        "cards": cards,
        "bottom": bottom,
        "top": top,
        "left": left,
        "right": right,
        "content_left": content_left,
        "content_right": content_right,
        "strip_height": top - bottom,
        "visible": visible,
        "total": total,
        "expanded": expanded,
        "preview_bottom": preview_bottom,
        "preview_top": preview_top,
        "separator_y": separator_y,
        "row_bottom": row_bottom,
        "row_top": row_top,
        "tabs": [tab1, tab2, tab3],
        "search_box": search_box,
        "search_clear_box": search_clear_box,
        "search_go_box": search_go_box,
        "label_box": label_box,
        "load_box": load_box,
        "update_box": update_box,
        "toggle_box": toggle_box,
        "move_box": move_box,
        "power_box": power_box,
        "settings_box": settings_box,
        "downloaded_filter_box": downloaded_filter_box,
        "category_box": category_box,
        "subcategory_box": subcategory_box,
        "fav_filter_box": fav_filter_box,
        "left_arrow": left_arrow,
        "right_arrow": right_arrow,
        "cards_start_x": cards_start_x,
        "cards_end_x": cards_end_x,
        "card_w": card_w,
        "gap": gap,
        "display_slots": display_slots,
    }


def _point_in_rect(x, y, rect):
    return rect["x1"] <= x <= rect["x2"] and rect["y1"] <= y <= rect["y2"]



def _layout_from_context(context):
    """Compute strip layout for the current context, only if this VIEW_3D is the owner."""
    area = getattr(context, "area", None)
    if area is None or area.type != 'VIEW_3D':
        return None

    settings = getattr(getattr(context, "scene", None), "fourdesinno_browser", None)
    if settings is None:
        return None

    # Only compute layout for the owner VIEW_3D area (prevents duplicate strips & bad interactions)
    owner_win_ptr, owner_area_ptr = _validate_or_reset_owner(getattr(context, "window", None), area)

    try:
        cur_win_ptr = context.window.as_pointer() if getattr(context, "window", None) else None
        cur_area_ptr = area.as_pointer()
    except Exception:
        cur_win_ptr = None
        cur_area_ptr = None

    if owner_area_ptr is not None and owner_win_ptr is not None:
        if cur_area_ptr != owner_area_ptr or cur_win_ptr != owner_win_ptr:
            return None

    return _compute_strip_layout_for_area(area, settings)


def _pump_preview_queue(max_items=1):
    changed = 0
    with STATE_LOCK:
        queue = list(STATE.get("thumb_queue", []))
    if not queue:
        return 0

    remaining = []
    for i, asset_id in enumerate(queue):
        asset = None
        with STATE_LOCK:
            for a in STATE["assets"]:
                if str(a.get("id")) == str(asset_id):
                    asset = a
                    break
        if asset is None:
            continue
        try:
            if not asset.get("preview_path"):
                _ensure_asset_preview_file(asset)
            asset["strip_preview_path"] = asset.get("preview_path", "")
            changed += 1
        except Exception:
            asset["strip_preview_path"] = asset.get("preview_path", "")
        if changed >= max_items:
            remaining.extend(queue[i+1:])
            break
    else:
        remaining = []

    with STATE_LOCK:
        processed_ids = set(queue[:len(queue)-len(remaining)])
        current = [str(aid) for aid in STATE.get("thumb_queue", []) if str(aid) not in processed_ids]
        STATE["thumb_queue"] = remaining + [aid for aid in current if aid not in remaining]
    if changed:
        _redraw_view3d()
    return changed


def _draw_hover_preview(card, asset, layout):
    preview_path = _ensure_display_preview_file(asset)
    if not preview_path or not os.path.exists(preview_path):
        return

    prefs = _addon_prefs()
    scale = 3
    try:
        if prefs is not None:
            scale = max(1, int(getattr(prefs, "hover_preview_scale", 3) or 3))
    except Exception:
        scale = 3

    img = _get_bpy_image(preview_path)
    img_w = img_h = 1
    try:
        if img is not None:
            img_w = max(1, int(img.size[0]))
            img_h = max(1, int(img.size[1]))
    except Exception:
        pass
    aspect = img_w / img_h if img_h else 1.0

    base_w = max(1, card["ix2"] - card["ix1"])
    box_w = min(900, max(220, int(base_w * scale)))
    box_h = int(box_w / aspect) if aspect > 0 else box_w
    if box_h > 700:
        box_h = 700
        box_w = int(box_h * aspect)

    x1 = int((card["ix1"] + card["ix2"]) * 0.5 - box_w * 0.5)
    x2 = x1 + box_w
    y1 = layout["top"] + 12
    y2 = y1 + box_h

    content_left = layout.get("content_left", layout["left"])
    content_right = layout.get("content_right", layout["right"])
    if x1 < content_left - 10:
        shift = (content_left - 10) - x1
        x1 += shift
        x2 += shift
    if x2 > content_right + 10:
        shift = x2 - (content_right + 10)
        x1 -= shift
        x2 -= shift

    _draw_vertical_gradient_rect(x1, y1, x2, y2, PREVIEW_BG_BOTTOM, PREVIEW_BG_TOP)
    _draw_outline(x1, y1, x2, y2, (0.3, 0.3, 0.3, 1.0))

    kind = str(asset.get("kind") or "")
    pad = 8
    ix1, iy1, ix2, iy2 = x1 + pad, y1 + pad, x2 - pad, y2 - pad
    if kind == "TEXTURE":
        side = min(ix2 - ix1, iy2 - iy1)
        cx = int((ix1 + ix2) * 0.5)
        cy = int((iy1 + iy2) * 0.5)
        sx1 = cx - side // 2
        sy1 = cy - side // 2
        sx2 = sx1 + side
        sy2 = sy1 + side
        _draw_fitted_texture_in_rect(preview_path, sx1, sy1, sx2, sy2, target_ratio=1.0)
    elif kind == "HDRI":
        _draw_fitted_texture_in_rect(preview_path, ix1, iy1, ix2, iy2, target_ratio=16.0/9.0)
    else:
        _draw_fitted_texture_in_rect(preview_path, ix1, iy1, ix2, iy2, target_ratio=None)


def _mouse_over_strip(context, event):
    layout = _layout_from_context(context)
    if not layout:
        return False
    x = getattr(event, "mouse_region_x", -999999)
    y = getattr(event, "mouse_region_y", -999999)
    y_top = layout["top"] + 10
    x_right = layout["right"] + 10
    settings = getattr(context.scene, "fourdesinno_browser", None)
    if settings is not None:
        _which, menu = _open_dropdown_layout(settings, layout)
        if menu:
            y_top = max(y_top, menu["y2"] + 4)
            x_right = max(x_right, menu["x2"] + 4)
    return (
        (layout["left"] - 10) <= x <= x_right
        and (layout["bottom"] + 2) <= y <= y_top
    )


def _draw_viewport_strip():
    ctx = bpy.context
    area = ctx.area
    scene = ctx.scene
    settings = getattr(scene, "fourdesinno_browser", None)
    if area is None or area.type != 'VIEW_3D' or settings is None:
        return
            # Ensure the strip is shown in only one VIEW_3D area at a time (the owner area).
    try:
        win = ctx.window
        cur_win_ptr = win.as_pointer() if win else None
        cur_area_ptr = area.as_pointer() if area else None
    except Exception:
        win = None
        cur_win_ptr = None
        cur_area_ptr = None

    owner_win_ptr, owner_area_ptr = _validate_or_reset_owner(win, area)

    if owner_area_ptr is not None and owner_win_ptr is not None:
        if cur_area_ptr != owner_area_ptr or cur_win_ptr != owner_win_ptr:
            return



    obj = getattr(ctx, 'object', None)
    if obj is not None and getattr(obj, 'mode', 'OBJECT') != 'OBJECT':
        return
    layout = _compute_strip_layout_for_area(area, settings)
    if not layout:
        return

    cards = layout["cards"]
    _pump_preview_queue(max_items=1)

    with STATE_LOCK:
        dl = dict(STATE.get("download") or {})
        hover_index = int(STATE.get("drag_hover_index", -1))
        dragging = bool(STATE.get("dragging", False))
        active_asset_id = str(STATE.get("active_asset_id") or "")
        has_more = bool(STATE.get("has_more", False))
        loading_more = bool(STATE.get("loading_more", False))

    _draw_rect(layout["left"] - 10, layout["bottom"] - 10, layout["right"] + 10, layout["top"] + 10, UI_STRIP_BG)

    # outer frame without a top edge, so only the custom double top border remains visible
    frame_x1 = layout["left"] - 10
    frame_y1 = layout["bottom"] - 10
    frame_x2 = layout["right"] + 10
    frame_y2 = layout["top"] + 10
    _draw_rect(frame_x1, frame_y1, frame_x2, frame_y1 + 1, UI_STRIP_OUTLINE)  # bottom
    _draw_rect(frame_x1, frame_y1, frame_x1 + 1, frame_y2, UI_STRIP_OUTLINE)  # left
    _draw_rect(frame_x2 - 1, frame_y1, frame_x2, frame_y2, UI_STRIP_OUTLINE)  # right

    # top part double 1px borders
    top_x1 = frame_x1
    top_x2 = frame_x2
    top_y = frame_y2
    _draw_rect(top_x1, top_y - 1, top_x2, top_y, UI_TOP_BORDER_1)  # lower line #555555
    _draw_rect(top_x1, top_y - 2, top_x2, top_y - 1, UI_TOP_BORDER_2)  # upper line #414141

    sep_y = layout.get("separator_y", layout["row_bottom"] - 1)

    # Keep the main separator line visible under the tab/reload row.
    # Only skip it directly underneath the search group so the search control keeps one clean border.
    search_group_boxes = []
    if layout.get("search_box"):
        search_group_boxes.append(layout["search_box"])
    if layout.get("search_clear_box"):
        search_group_boxes.append(layout["search_clear_box"])
    if layout.get("search_go_box"):
        search_group_boxes.append(layout["search_go_box"])

    if search_group_boxes:
        sg_x1 = min(int(b["x1"]) for b in search_group_boxes)
        sg_x2 = max(int(b["x2"]) for b in search_group_boxes)
        _draw_rect(int(layout["left"]), sep_y, sg_x1, sep_y + 1, UI_BUTTON_OUTLINE)
        _draw_rect(sg_x2, sep_y, int(layout["right"]), sep_y + 1, UI_BUTTON_OUTLINE)
    else:
        _draw_rect(int(layout["left"]), sep_y, int(layout["right"]), sep_y + 1, UI_BUTTON_OUTLINE)

    if layout.get("expanded"):
        for arrow in (layout.get("left_arrow"), layout.get("right_arrow")):
            if not arrow:
                continue
            _draw_box(arrow["x1"], arrow["y1"], arrow["x2"], arrow["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
            glyph = "‹" if arrow["dir"] < 0 else "›"
            span_h = arrow["y2"] - arrow["y1"]
            for frac in (0.25, 0.50, 0.75):
                cy = arrow["y1"] + int(span_h * frac)
                box_h = 18
                _draw_text_centered_in_rect(arrow["x1"], cy - box_h // 2, arrow["x2"], cy + box_h // 2, glyph, 16, UI_TEXT_DARK)

    tab_labels = {
        "model": "3D MODELS",
        "texture": "TEXTURES",
        "hdri": "HDRI",
    }
    active_type = settings.asset_type
    for tab in layout.get("tabs", []):
        is_active = (tab["type"] == active_type)
        bg = UI_BUTTON_ACTIVE if is_active else UI_BUTTON_BG
        fg = (1, 1, 1, 1) if is_active else UI_TEXT_DARK
        _draw_box_without_bottom_border(tab["x1"], tab["y1"], tab["x2"], tab["y2"], bg, UI_BUTTON_OUTLINE)
        _draw_text_centered_in_rect(tab["x1"], tab["y1"], tab["x2"], tab["y2"], tab_labels.get(tab["type"], "TAB"), 11, fg)

    fav_filter_box = layout.get("fav_filter_box")
    downloaded_filter_box = layout.get("downloaded_filter_box")
    if fav_filter_box:
        with STATE_LOCK:
            favorites_only = bool(STATE.get("favorites_only", False))
        fav_bg = UI_BUTTON_ACTIVE_ALT if favorites_only else UI_BUTTON_BG
        fav_fg = (1, 1, 1, 1) if favorites_only else UI_TEXT_DARK
        _draw_box_without_bottom_border(fav_filter_box["x1"], fav_filter_box["y1"], fav_filter_box["x2"], fav_filter_box["y2"], fav_bg, UI_BUTTON_OUTLINE)
        _draw_text_centered_in_rect(fav_filter_box["x1"], fav_filter_box["y1"], fav_filter_box["x2"], fav_filter_box["y2"], "FAVORITES", 11, fav_fg)

    if downloaded_filter_box:
        with STATE_LOCK:
            downloaded_only = bool(STATE.get("downloaded_only", False))
        dl_bg = UI_BUTTON_ACTIVE_ALT if downloaded_only else UI_BUTTON_BG
        dl_fg = (1, 1, 1, 1) if downloaded_only else UI_TEXT_DARK
        _draw_box_without_bottom_border(downloaded_filter_box["x1"], downloaded_filter_box["y1"], downloaded_filter_box["x2"], downloaded_filter_box["y2"], dl_bg, UI_BUTTON_OUTLINE)
        _draw_text_centered_in_rect(downloaded_filter_box["x1"], downloaded_filter_box["y1"], downloaded_filter_box["x2"], downloaded_filter_box["y2"], "DOWNLOADED", 10, dl_fg)

    # touching tabs/buttons should share a single divider line, not a doubled border
    # The pixel column immediately left of each divider belongs to the left button interior.
    # Paint it with that left button's own fill color so selected tabs do not show a gray artifact.
    header_boxes = list(layout.get("tabs", []))
    if fav_filter_box:
        header_boxes.append(fav_filter_box)
    if downloaded_filter_box:
        header_boxes.append(downloaded_filter_box)
    for i in range(1, len(header_boxes)):
        left_box = header_boxes[i - 1]
        right_box = header_boxes[i]
        x = int(right_box["x1"])
        y1 = int(right_box["y1"]) + 1
        y2 = int(right_box["y2"]) - 1

        left_fill = UI_BUTTON_BG
        if "type" in left_box and left_box["type"] == active_type:
            left_fill = UI_BUTTON_ACTIVE
        elif left_box is fav_filter_box and favorites_only:
            left_fill = UI_BUTTON_ACTIVE_ALT
        elif left_box is downloaded_filter_box and downloaded_only:
            left_fill = UI_BUTTON_ACTIVE_ALT

        _draw_rect(x - 1, y1, x, y2, left_fill)
        _draw_rect(x, y1, x + 1, y2, UI_BUTTON_OUTLINE)

    load_box = layout.get("load_box")
    if load_box:
        _draw_box_without_bottom_border(load_box["x1"], load_box["y1"], load_box["x2"], load_box["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
        _draw_text_centered_in_rect(load_box["x1"], load_box["y1"], load_box["x2"], load_box["y2"], "↻", 14, UI_TEXT_DARK)

    move_box = layout.get("move_box")
    if move_box:
        _draw_box_without_bottom_border(move_box["x1"], move_box["y1"], move_box["x2"], move_box["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
        _draw_text_centered_in_rect(move_box["x1"], move_box["y1"], move_box["x2"], move_box["y2"], "⇄", 14, UI_TEXT_DARK)

    settings_box = layout.get("settings_box")
    if settings_box:
        _draw_box_without_bottom_border(settings_box["x1"], settings_box["y1"], settings_box["x2"], settings_box["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
        _draw_text_centered_in_rect(settings_box["x1"], settings_box["y1"], settings_box["x2"], settings_box["y2"], "⚙", 14, UI_TEXT_DARK)

    power_box = layout.get("power_box")
    if power_box:
        _draw_box_without_bottom_border(power_box["x1"], power_box["y1"], power_box["x2"], power_box["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
        power_color = (0.16, 0.72, 0.23, 1.0) if _online_mode_enabled(settings) else (0.86, 0.22, 0.22, 1.0)
        _draw_text_centered_in_rect(power_box["x1"], power_box["y1"], power_box["x2"], power_box["y2"], "⏻", 14, power_color)
    update_box = layout.get("update_box")
    if update_box and update_box["x2"] > update_box["x1"]:
        with STATE_LOCK:
            info = dict(STATE.get("update_info", {}) or {})
        latest_text = str(info.get("latest_version") or "").strip()
        has_update = bool(latest_text) and _parse_version_value(latest_text) > _local_addon_version()
        if has_update:
            t = time.time()
            pulse = (math.sin(t * 5.0) + 1.0) * 0.5
            bg = (0.12, 0.82, 0.24, 0.95) if pulse > 0.5 else (0.10, 0.70, 0.20, 0.90)
            _draw_box_without_bottom_border(update_box["x1"], update_box["y1"], update_box["x2"], update_box["y2"], bg, UI_BUTTON_OUTLINE)
            _draw_text_centered_in_rect(update_box["x1"], update_box["y1"], update_box["x2"], update_box["y2"], "UPDATE AVAILABLE", 10, (1, 1, 1, 1))


    toggle_box = layout.get("toggle_box")
    if toggle_box:
        toggle_on = bool(layout.get("expanded"))
        toggle_bg = UI_BUTTON_ACTIVE if toggle_on else UI_BUTTON_BG
        toggle_fg = (1, 1, 1, 1) if toggle_on else UI_TEXT_DARK
        toggle_label = "HIDE" if toggle_on else "SHOW"
        _draw_box_without_bottom_border(toggle_box["x1"], toggle_box["y1"], toggle_box["x2"], toggle_box["y2"], toggle_bg, UI_BUTTON_OUTLINE)
        _draw_text_centered_in_rect(toggle_box["x1"], toggle_box["y1"], toggle_box["x2"], toggle_box["y2"], toggle_label, 10, toggle_fg)

    category_box = layout.get("category_box")
    if category_box:
        _draw_box_without_bottom_border(category_box["x1"], category_box["y1"], category_box["x2"], category_box["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
        current_cat = str(getattr(settings, "category_term_name", "ALL CATEGORIES") or "ALL CATEGORIES").upper()
        current_sub = str(getattr(settings, "subcategory_term_name", "") or "").upper()
        cat_label = current_sub if current_sub and current_sub != "ALL SUBCATEGORIES" else current_cat
        _draw_text(category_box["x1"] + 8, category_box["y1"] + 7, _clip_text(cat_label, 24), 10, UI_TEXT_DARK)

    dropdown_kind, dropdown_menu = _open_dropdown_layout(settings, layout)
    if dropdown_menu:
        with STATE_LOCK:
            hover_kind = str(STATE.get("dropdown_hover_kind", "") or "")
            hover_id = str(STATE.get("dropdown_hover_id", "") or "")
            hover_parent_id = str(STATE.get("dropdown_hover_parent_id", "") or "")

        main_menu = dropdown_menu.get("main")
        sub_menu = dropdown_menu.get("sub")
        submenu_parent_id = str(dropdown_menu.get("submenu_parent_id", "") or "")

        if main_menu:
            _draw_box(main_menu["x1"], main_menu["y1"], main_menu["x2"], main_menu["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
            selected_cat_id = str(getattr(settings, "category_term_id", "") or "")
            for item in main_menu["items"]:
                row = item["row"]
                row_id = str(row.get("id") or "")
                is_selected = (row_id == selected_cat_id) or (not row_id and not selected_cat_id)
                is_hover = (hover_kind == "category" and hover_id == row_id)
                is_submenu_owner = row_id and row_id == submenu_parent_id
                row_fg = (1, 1, 1, 1) if (is_selected or is_hover or is_submenu_owner) else UI_TEXT_DARK
                if is_selected or is_hover or is_submenu_owner:
                    _draw_rect(item["x1"] + 1, item["y1"], item["x2"] - 1, item["y2"], UI_BUTTON_ACTIVE)
                count_text = str(int(row.get("count") or 0)) if str(row.get("id") or "") and int(row.get("count") or 0) > 0 else ""
                if count_text:
                    _draw_text_right_aligned_in_rect(item["x1"], item["y1"], item["x2"], item["y2"], count_text, 10, row_fg, right_pad=10)
                _draw_text(item["x1"] + 8, item["y1"] + 7, _clip_text(str(row.get("name") or "").upper(), 18), 10, row_fg)

        if sub_menu:
            _draw_box(sub_menu["x1"], sub_menu["y1"], sub_menu["x2"], sub_menu["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
            selected_sub_id = str(getattr(settings, "subcategory_term_id", "") or "")
            for item in sub_menu["items"]:
                row = item["row"]
                row_id = str(row.get("id") or "")
                is_selected = row_id == selected_sub_id
                is_hover = (hover_kind == "subcategory" and hover_id == row_id)
                row_fg = (1, 1, 1, 1) if (is_selected or is_hover) else UI_TEXT_DARK
                if is_selected or is_hover:
                    _draw_rect(item["x1"] + 1, item["y1"], item["x2"] - 1, item["y2"], UI_BUTTON_ACTIVE)
                count_text = str(int(row.get("count") or 0)) if str(row.get("id") or "") and int(row.get("count") or 0) > 0 else ""
                if count_text:
                    _draw_text_right_aligned_in_rect(item["x1"], item["y1"], item["x2"], item["y2"], count_text, 10, row_fg, right_pad=10)
                _draw_text(item["x1"] + 8, item["y1"] + 7, _clip_text(str(row.get("name") or "").upper(), 22), 10, row_fg)

    # Settings popover (gear)
    with STATE_LOCK:
        settings_open = bool(STATE.get("settings_open", False))
    if settings_open:
        panel = _settings_panel_layout(settings, layout)
        if panel:
            _draw_box(panel["x1"], panel["y1"], panel["x2"], panel["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
            # Version label (subtle)
            header = panel["header"]
            _draw_text(header["x1"], header["y1"] + 7, f"Installed: {_version_to_text(_local_addon_version())}", 10, UI_TEXT_MUTED)

            prefs = _addon_prefs()
            # Rows
            row = panel["row_preview"]
            _draw_text(row["label"]["x1"], row["label"]["y1"] + 7, "Preview Card Size", 10, UI_TEXT_DARK)
            with STATE_LOCK:
                ek = str(STATE.get("settings_edit_kind", "") or "")
                eb = str(STATE.get("settings_edit_buffer", "") or "")
            if ek == "row_preview":
                val = (eb + "|") if eb else "0|"
            elif prefs:
                val = str(int(getattr(prefs, "preview_card_size", 108) or 108))
            else:
                val = "-"
            _draw_box(row["minus"]["x1"], row["minus"]["y1"], row["minus"]["x2"], row["minus"]["y2"], UI_MORE_BG, UI_MORE_OUTLINE)
            _draw_text_centered_in_rect(row["minus"]["x1"], row["minus"]["y1"], row["minus"]["x2"], row["minus"]["y2"], "-", 13, UI_TEXT_DARK)
            _draw_box(row["value"]["x1"], row["value"]["y1"], row["value"]["x2"], row["value"]["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
            _draw_text_centered_in_rect(row["value"]["x1"], row["value"]["y1"], row["value"]["x2"], row["value"]["y2"], val, 10, UI_TEXT_DARK)
            _draw_box(row["plus"]["x1"], row["plus"]["y1"], row["plus"]["x2"], row["plus"]["y2"], UI_MORE_BG, UI_MORE_OUTLINE)
            _draw_text_centered_in_rect(row["plus"]["x1"], row["plus"]["y1"], row["plus"]["x2"], row["plus"]["y2"], "+", 12, UI_TEXT_DARK)

            row = panel["row_hover"]
            _draw_text(row["label"]["x1"], row["label"]["y1"] + 7, "Hover Preview Size", 10, UI_TEXT_DARK)
            with STATE_LOCK:
                ek2 = str(STATE.get("settings_edit_kind", "") or "")
                eb2 = str(STATE.get("settings_edit_buffer", "") or "")
            if ek2 == "row_hover":
                val2 = (eb2 + "|") if eb2 else "0|"
            elif prefs:
                val2 = str(int(getattr(prefs, "hover_preview_scale", 6) or 6))
            else:
                val2 = "-"
            _draw_box(row["minus"]["x1"], row["minus"]["y1"], row["minus"]["x2"], row["minus"]["y2"], UI_MORE_BG, UI_MORE_OUTLINE)
            _draw_text_centered_in_rect(row["minus"]["x1"], row["minus"]["y1"], row["minus"]["x2"], row["minus"]["y2"], "-", 13, UI_TEXT_DARK)
            _draw_box(row["value"]["x1"], row["value"]["y1"], row["value"]["x2"], row["value"]["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
            _draw_text_centered_in_rect(row["value"]["x1"], row["value"]["y1"], row["value"]["x2"], row["value"]["y2"], val2, 10, UI_TEXT_DARK)
            _draw_box(row["plus"]["x1"], row["plus"]["y1"], row["plus"]["x2"], row["plus"]["y2"], UI_MORE_BG, UI_MORE_OUTLINE)
            _draw_text_centered_in_rect(row["plus"]["x1"], row["plus"]["y1"], row["plus"]["x2"], row["plus"]["y2"], "+", 12, UI_TEXT_DARK)


            # Open assets folder button
            btn = panel.get("assets_btn")
            if btn:
                _draw_box(btn["x1"], btn["y1"], btn["x2"], btn["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
                _draw_text_centered_in_rect(btn["x1"], btn["y1"], btn["x2"], btn["y2"], "Open Assets Folder", 10, UI_TEXT_DARK)


            # Website / Support / Discord / YouTube buttons
            btn = panel.get("website_btn")
            if btn:
                _draw_box(btn["x1"], btn["y1"], btn["x2"], btn["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
                _draw_text_centered_in_rect(btn["x1"], btn["y1"], btn["x2"], btn["y2"], "Website", 10, UI_TEXT_DARK)

            btn = panel.get("support_btn")
            if btn:
                _draw_box(btn["x1"], btn["y1"], btn["x2"], btn["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
                _draw_text_centered_in_rect(btn["x1"], btn["y1"], btn["x2"], btn["y2"], "Support / Bug", 10, UI_TEXT_DARK)

            btn = panel.get("discord_btn")
            if btn:
                _draw_box(btn["x1"], btn["y1"], btn["x2"], btn["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
                _draw_text_centered_in_rect(btn["x1"], btn["y1"], btn["x2"], btn["y2"], "Discord", 10, UI_TEXT_DARK)

            btn = panel.get("youtube_btn")
            if btn:
                _draw_box(btn["x1"], btn["y1"], btn["x2"], btn["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
                _draw_text_centered_in_rect(btn["x1"], btn["y1"], btn["x2"], btn["y2"], "YouTube", 10, UI_TEXT_DARK)

            # Patreon support button
            btn = panel.get("patreon_btn")
            if btn:
                # Make Patreon button more vibrant
                patreon_bg = (0.96, 0.26, 0.33, 0.98)
                patreon_outline = (0.60, 0.12, 0.16, 1.0)
                _draw_box(btn["x1"], btn["y1"], btn["x2"], btn["y2"], patreon_bg, patreon_outline)
                _draw_text_centered_in_rect(btn["x1"], btn["y1"] + 1, btn["x2"], btn["y2"] + 1, "❤ Support on Patreon", 10, (1, 1, 1, 1))

    # Update popover (UPDATE AVAILABLE)
    with STATE_LOCK:
        info = dict(STATE.get("update_info", {}) or {})
        latest_text = str(info.get("latest_version") or "").strip()
        has_update = bool(latest_text) and _parse_version_value(latest_text) > _local_addon_version()
        update_open = bool(STATE.get("update_panel_open", False))
    if has_update and update_open:
        panel = _update_panel_layout(settings, layout)
        if panel:
            _draw_box(panel["x1"], panel["y1"], panel["x2"], panel["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
            header = panel["header"]
            _draw_text(header["x1"], header["y1"] + 7, "UPDATE AVAILABLE", 10, UI_TEXT_DARK)

            rv = panel["row_versions"]
            installed = _version_to_text(_local_addon_version())
            latest = latest_text
            _draw_text(rv["x1"], rv["y1"] + 7, f"Installed: {installed}   Latest: {latest}", 10, UI_TEXT_MUTED)

            rm = panel["row_message"]
            msg = str(info.get("message") or "New version available.").strip()
            _draw_text(rm["x1"], rm["y1"] + 7, _clip_text(msg, 64), 9, UI_TEXT_DARK)

            b = panel["btn_update_now"]
            _draw_box(b["x1"], b["y1"], b["x2"], b["y2"], UI_BUTTON_ACTIVE, UI_BUTTON_OUTLINE)
            _draw_text_centered_in_rect(b["x1"], b["y1"], b["x2"], b["y2"], "UPDATE NOW", 10, (1, 1, 1, 1))

            b = panel["btn_ignore"]
            _draw_box(b["x1"], b["y1"], b["x2"], b["y2"], UI_MORE_BG, UI_MORE_OUTLINE)
            _draw_text_centered_in_rect(b["x1"], b["y1"], b["x2"], b["y2"], "IGNORE", 10, UI_TEXT_DARK)

            b = panel["btn_later"]
            _draw_box(b["x1"], b["y1"], b["x2"], b["y2"], UI_MORE_BG, UI_MORE_OUTLINE)
            _draw_text_centered_in_rect(b["x1"], b["y1"], b["x2"], b["y2"], "LATER", 10, UI_TEXT_DARK)

            changelog_url = str(info.get("changelog_url") or "").strip()
            b = panel["btn_changelog"]
            if changelog_url:
                _draw_box(b["x1"], b["y1"], b["x2"], b["y2"], UI_BUTTON_BG, UI_BUTTON_OUTLINE)
                _draw_text_centered_in_rect(b["x1"], b["y1"], b["x2"], b["y2"], "OPEN CHANGELOG", 9, UI_TEXT_DARK)


    sb = layout.get("search_box")
    search_clear_box = layout.get("search_clear_box")
    search_go_box = layout.get("search_go_box")

    # Draw search input + clear + search as one connected control with a single outer border.
    search_group = []
    if sb:
        search_group.append(sb)
    if search_clear_box:
        search_group.append(search_clear_box)
    if search_go_box:
        search_group.append(search_go_box)

    if search_group:
        gx1 = min(int(b["x1"]) for b in search_group)
        gy1 = min(int(b["y1"]) for b in search_group)
        gx2 = max(int(b["x2"]) for b in search_group)
        gy2 = max(int(b["y2"]) for b in search_group)

        _draw_box(gx1, gy1, gx2, gy2, UI_BUTTON_BG, UI_BUTTON_OUTLINE)

        for i in range(1, len(search_group)):
            x = int(search_group[i]["x1"])
            y1 = gy1 + 1
            y2 = gy2 - 1
            _draw_rect(x - 1, y1, x + 1, y2, UI_BUTTON_BG)
            _draw_rect(x, y1, x + 1, y2, UI_BUTTON_OUTLINE)

    if sb:
        with STATE_LOCK:
            editing = bool(STATE.get("search_editing", False))
            search_buffer = str(STATE.get("search_buffer", settings.search_text or ""))
        shown_text = search_buffer if editing else (settings.search_text.strip() or "Search...")
        if editing:
            shown_text = shown_text + "|"
        search_color = UI_TEXT_DARK if shown_text.strip() and shown_text != "Search..." else UI_TEXT_MUTED
        _draw_text(sb["x1"] + 10, sb["y1"] + 7, _clip_text(shown_text, 28), 11, search_color)

    if search_clear_box:
        _draw_text_centered_in_rect(search_clear_box["x1"], search_clear_box["y1"], search_clear_box["x2"], search_clear_box["y2"], "×", 13, UI_TEXT_DARK)

    if search_go_box:
        _draw_text_centered_in_rect(search_go_box["x1"], search_go_box["y1"], search_go_box["x2"], search_go_box["y2"], "⌕", 12, UI_TEXT_DARK)

    lb = layout.get("label_box")
    if lb:
        shown_start = settings.strip_offset + 1 if layout["total"] > 0 and layout.get("expanded") and cards else 0
        shown_end = settings.strip_offset + min(len(cards), max(0, layout.get("display_slots", settings.strip_count) - (1 if has_more and layout.get("display_slots", settings.strip_count) > 1 else 0)))
        if _online_mode_enabled(settings):
            label = f"Presented by FOURDESINNO.COM  {shown_start}-{shown_end} / {layout['total']}"
        else:
            label = f"LOCAL MODE  {shown_start}-{shown_end} / {layout['total']}"
        _draw_text(lb["x1"] + 4, lb["y1"] + 7, _clip_text(label, 44), 11, UI_TEXT_DARK)

    if not layout.get("expanded"):
        if dl.get("title"):
            bar_left = layout["left"]
            bar_right = layout["right"]
            bar_y = layout["top"] + 6
            _draw_rect(bar_left, bar_y, bar_right, bar_y + 22, UI_BUTTON_BG)
            _draw_outline(bar_left, bar_y, bar_right, bar_y + 22, UI_BUTTON_OUTLINE)
            total_w = bar_right - bar_left
            pct = max(0, min(100, int(dl.get("percent", 0))))
            if pct > 0:
                fill_right = bar_left + (total_w * (pct / 100.0))
                _draw_rect(bar_left, bar_y, fill_right, bar_y + 22, (0.2117647059, 0.4470588235, 0.7764705882, 0.95))
            label = f"{dl.get('phase') or 'Working'}  {pct}%  {_format_bytes(dl.get('bytes_done', 0))} / {_format_bytes(dl.get('bytes_total', 0))}" if dl.get("bytes_total", 0) > 0 else (dl.get("phase") or "Working")
            _draw_text(bar_left + 8, bar_y + 5, _clip_text(f"{dl.get('title')}: {label}", 120), 12, (1, 1, 1, 1))
        return

    slot_count = max(1, layout.get("display_slots", settings.strip_count))
    if cards:
        card_w = cards[0]["x2"] - cards[0]["x1"]
        gap = cards[1]["x1"] - cards[0]["x2"] if len(cards) > 1 else layout.get("gap", 8)
        y2 = cards[0]["y2"]
        cards_start_x = cards[0]["x1"]
    else:
        card_w = layout.get("card_w", 140)
        gap = layout.get("gap", 8)
        y2 = layout.get("preview_top", layout["bottom"] + 106)
        cards_start_x = layout.get("cards_start_x", layout["left"])

    if not cards and (loading_more or layout.get("total", 0) == 0):
        msg_x1 = layout.get("cards_start_x", layout["left"])
        msg_x2 = layout.get("cards_end_x", layout["right"])
        msg_y1 = layout.get("preview_bottom", layout["bottom"])
        msg_y2 = layout.get("preview_top", y2)
        _draw_box(msg_x1, msg_y1, msg_x2, msg_y2, PREVIEW_BG_TOP, UI_BUTTON_OUTLINE)
        _draw_text_centered_in_rect(msg_x1, msg_y1 + 8, msg_x2, msg_y2 + 8, "Loading assets..." if _online_mode_enabled(settings) else "Loading local assets...", 13, UI_TEXT_DARK)

    x = cards_start_x
    for slot_idx in range(slot_count):
        _draw_rect(x, layout["bottom"], x + card_w, y2, PREVIEW_BG_TOP)
        x += card_w + gap

    if has_more:
        more_x1 = cards_start_x + (slot_count - 1) * (card_w + gap)
        more_x2 = more_x1 + card_w
        _draw_box(more_x1, layout["bottom"], more_x2, y2, PREVIEW_BG_TOP, UI_BUTTON_OUTLINE)
        label = "Loading more..." if loading_more else "Scroll for more..."
        _draw_text(more_x1 + 8, layout["bottom"] + 24, label, 11, UI_TEXT_DARK)
        _draw_text(more_x1 + 8, layout["bottom"] + 11, "More results available", 9, UI_TEXT_MUTED)

    draw_cards = cards[:max(0, slot_count - 1)] if has_more else cards[:slot_count]

    for card in draw_cards:
        asset = card["asset"]
        is_hover = card["index"] == hover_index
        is_active = str(asset.get("id")) == active_asset_id

        border_color = UI_SLOT_OUTLINE
        if is_hover:
            border_color = (0.52, 0.66, 0.98, 1.0)
        if is_active and dragging:
            border_color = (0.18, 0.62, 0.28, 1.0)

        _draw_box(card["x1"], card["y1"], card["x2"], card["y2"], PREVIEW_BG_TOP, border_color)

        inner_x1 = card["x1"] + 1
        inner_y1 = card["y1"] + 1
        inner_x2 = card["x2"] - 1
        inner_y2 = card["y2"] - 1

        preview_path = _ensure_display_preview_file(asset)
        if preview_path and os.path.exists(preview_path):
            kind = str(asset.get("kind") or "")
            if kind == "TEXTURE":
                side = min(inner_x2 - inner_x1, inner_y2 - inner_y1)
                cx = int((inner_x1 + inner_x2) * 0.5)
                cy = int((inner_y1 + inner_y2) * 0.5)
                sx1 = cx - side // 2
                sy1 = cy - side // 2
                sx2 = sx1 + side
                sy2 = sy1 + side
                _draw_fitted_texture_in_rect(preview_path, sx1, sy1, sx2, sy2, target_ratio=1.0)
            elif kind == "HDRI":
                _draw_fitted_texture_in_rect(preview_path, inner_x1, inner_y1, inner_x2, inner_y2, target_ratio=16.0/9.0)
            else:
                _draw_fitted_texture_in_rect(preview_path, inner_x1, inner_y1, inner_x2, inner_y2, target_ratio=1.35)

        if _asset_is_downloaded(asset):
            _draw_rect(card["x1"] + 1, card["y2"] - 4, card["x2"] - 1, card["y2"] - 1, (0.10, 0.70, 0.20, 1.0))

        fav_rect = {"x1": card["fav_x1"], "y1": card["fav_y1"], "x2": card["fav_x2"], "y2": card["fav_y2"]}
        fav_on = _is_favorite(asset)
        heart_color = (0.88, 0.20, 0.26, 1.0) if fav_on else (0.62, 0.62, 0.66, 1.0)
        _draw_text_centered_in_rect(
            fav_rect["x1"], fav_rect["y1"], fav_rect["x2"], fav_rect["y2"],
            "♥" if fav_on else "♡",
            13,
            heart_color,
        )

    # touching preview cards should share a single crisp divider line
    for i in range(1, len(draw_cards)):
        x = int(draw_cards[i]["x1"])
        y1 = int(draw_cards[i]["y1"]) + 1
        y2_div = int(draw_cards[i]["y2"]) - 1
        _draw_rect(x - 1, y1, x + 1, y2_div, PREVIEW_BG_TOP)
        _draw_rect(x, y1, x + 1, y2_div, UI_BUTTON_OUTLINE)

    if has_more and draw_cards:
        x = int(more_x1)
        y1 = int(layout["bottom"]) + 1
        y2_div = int(y2) - 1
        _draw_rect(x - 1, y1, x + 1, y2_div, PREVIEW_BG_TOP)
        _draw_rect(x, y1, x + 1, y2_div, UI_BUTTON_OUTLINE)

    hover_card = None
    if 0 <= hover_index < len(draw_cards):
        hover_card = draw_cards[hover_index]
    elif 0 <= hover_index < len(cards):
        hover_card = cards[hover_index]
    if hover_card:
        _draw_hover_preview(hover_card, hover_card["asset"], layout)

    if dl.get("title"):
        bar_left = layout["left"]
        bar_right = layout["right"]
        bar_y = layout["top"] + 6
        _draw_rect(bar_left, bar_y, bar_right, bar_y + 22, UI_BUTTON_BG)
        _draw_outline(bar_left, bar_y, bar_right, bar_y + 22, UI_BUTTON_OUTLINE)
        total_w = bar_right - bar_left
        pct = max(0, min(100, int(dl.get("percent", 0))))
        if pct > 0:
            fill_right = bar_left + (total_w * (pct / 100.0))
            _draw_rect(bar_left, bar_y, fill_right, bar_y + 22, (0.2117647059, 0.4470588235, 0.7764705882, 0.95))
        label = f"{dl.get('phase') or 'Working'}  {pct}%  {_format_bytes(dl.get('bytes_done', 0))} / {_format_bytes(dl.get('bytes_total', 0))}" if dl.get("bytes_total", 0) > 0 else (dl.get("phase") or "Working")
        _draw_text(bar_left + 8, bar_y + 5, _clip_text(f"{dl.get('title')}: {label}", 120), 12, (1, 1, 1, 1))


# ---------------------------------------------------------
# props
# ---------------------------------------------------------


class F3D_BrowserSettings(PropertyGroup):
    search_text: StringProperty(name="Search", default="")
    category_term_id: StringProperty(name="Category Term ID", default="")
    category_term_slug: StringProperty(name="Category Term Slug", default="")
    category_term_name: StringProperty(name="Category Term Name", default="ALL CATEGORIES")
    subcategory_term_id: StringProperty(name="Subcategory Term ID", default="")
    subcategory_term_slug: StringProperty(name="Subcategory Term Slug", default="")
    subcategory_term_name: StringProperty(name="Subcategory Term Name", default="ALL SUBCATEGORIES")
    asset_type: EnumProperty(
        name="Type",
        items=[
            ('model', 'ALL 3D MODELS', 'Show 3D models'),
            ('texture', 'ALL TEXTURES', 'Show textures'),
            ('hdri', 'ALL HDRI', 'Show HDRI'),
        ],
        default='model',
    )
    import_mode: EnumProperty(
        name="Mode",
        items=[('APPEND', 'Append', 'Editable import from asset folder'), ('LINK', 'Link', 'Link from asset folder')],
        default='APPEND',
    )
    strip_offset: IntProperty(name="Strip Offset", default=0, min=0)
    strip_count: IntProperty(name="Visible Previews", default=10, min=3, max=12)
    strip_enabled: BoolProperty(name="Viewport Strip", default=True)
    strip_expanded: BoolProperty(name="Preview Strip Expanded", default=False)
    online_enabled: BoolProperty(name="Online Mode", default=True)


# ---------------------------------------------------------
# operators
# ---------------------------------------------------------


class F3D_OT_OpenUpdateLink(Operator):
    bl_idname = "fourdesinno.open_update_link"
    bl_label = "Open Update Link"

    url: StringProperty(default="")

    def execute(self, context):
        url = str(self.url or "").strip()
        if not url:
            self.report({'WARNING'}, "No update link is available.")
            return {'CANCELLED'}
        try:
            bpy.ops.wm.url_open(url=url)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, f"Could not open URL: {exc}")
            return {'CANCELLED'}


class F3D_OT_InstallAddonUpdate(Operator):
    bl_idname = "fourdesinno.install_addon_update"
    bl_label = "Install Addon Update"

    download_url: StringProperty(default="")
    latest_version: StringProperty(default="")

    def execute(self, context):
        download_url = str(self.download_url or "").strip()
        latest_version = str(self.latest_version or "").strip()
        if not download_url:
            self.report({'ERROR'}, "No update ZIP URL was provided.")
            return {'CANCELLED'}

        tmp_zip = ""
        try:
            _set_status(f"Downloading addon update {latest_version or ''}...")
            tmp_zip = _download_update_zip(download_url, latest_version_text=latest_version)
            _set_status("Preparing safe addon update...")
            _launch_external_update_helper(tmp_zip, latest_version_text=latest_version)
            tmp_zip = ""
            _set_ignored_update_version("")
            with STATE_LOCK:
                STATE["update_deferred_version"] = ""
                STATE["update_checked"] = True
                info = dict(STATE.get("update_info", {}) or {})
                if latest_version:
                    info["latest_version"] = latest_version
                    STATE["update_info"] = info
            _show_update_result_popup("Installation Report", [
                "Addon update downloaded and staged",
                "Restart Blender for the new version to take effect",
            ], icon='CHECKMARK')
            _set_status(f"Update {latest_version or 'new'} downloaded and staged. Restart Blender for the new version to take effect.")
            self.report({'INFO'}, "Restart Blender for the new version to take effect")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            _set_status(f"Addon update failed: {exc}")
            _show_update_result_popup("FOURDESINNO Update Failed", [str(exc)], icon='ERROR')
            return {'CANCELLED'}
        finally:
            if tmp_zip:
                try:
                    os.remove(tmp_zip)
                except Exception:
                    pass


class F3D_OT_IgnoreAddonUpdate(Operator):
    bl_idname = "fourdesinno.ignore_addon_update"
    bl_label = "Ignore Addon Update"

    latest_version: StringProperty(default="")

    def execute(self, context):
        latest_version = str(self.latest_version or "").strip()
        _set_ignored_update_version(latest_version)
        with STATE_LOCK:
            STATE["update_deferred_version"] = ""
        _set_status(f"Ignored addon update {latest_version}.")
        return {'FINISHED'}


class F3D_OT_DeferAddonUpdate(Operator):
    bl_idname = "fourdesinno.defer_addon_update"
    bl_label = "Defer Addon Update"

    latest_version: StringProperty(default="")

    def execute(self, context):
        latest_version = str(self.latest_version or "").strip()
        with STATE_LOCK:
            STATE["update_deferred_version"] = latest_version
        _set_status(f"Deferred addon update {latest_version} for this session.")
        return {'FINISHED'}


class F3D_OT_UpdatePrompt(Operator):
    bl_idname = "fourdesinno.update_prompt"
    bl_label = "FOURDESINNO Update Available"

    action: EnumProperty(
        name="Action",
        items=[
            ('UPDATE_NOW', 'Update Now', 'Download the new addon ZIP and apply it after Blender is restarted'),
            ('IGNORE', 'Ignore', 'Ignore this exact version until a newer one exists'),
            ('DEFER', 'Defer', 'Hide this update for the current Blender session'),
        ],
        default='UPDATE_NOW',
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        with STATE_LOCK:
            info = dict(STATE.get("update_info", {}) or {})
        latest_version = str(info.get("latest_version") or "").strip()
        message = str(info.get("message") or "Update ready!").strip()
        download_url = str(info.get("download_url") or "").strip()
        changelog_url = str(info.get("changelog_url") or "").strip()

        layout.label(text=message)
        layout.separator()
        col = layout.column(align=True)
        col.label(text=f"Installed: {_version_to_text(_local_addon_version())}")
        col.label(text=f"Latest: {latest_version or 'Unknown'}")
        if not download_url:
            warn = layout.column(align=True)
            warn.alert = True
            warn.label(text="No download URL is available yet.")
        if changelog_url:
            op = layout.operator("fourdesinno.open_update_link", text="Open Changelog", icon='URL')
            op.url = changelog_url
        layout.separator()
        layout.prop(self, "action", expand=True)

    def execute(self, context):
        with STATE_LOCK:
            info = dict(STATE.get("update_info", {}) or {})
        latest_version = str(info.get("latest_version") or "").strip()
        download_url = str(info.get("download_url") or "").strip()

        if self.action == 'UPDATE_NOW':
            return bpy.ops.fourdesinno.install_addon_update('INVOKE_DEFAULT', download_url=download_url, latest_version=latest_version)
        if self.action == 'IGNORE':
            return bpy.ops.fourdesinno.ignore_addon_update('INVOKE_DEFAULT', latest_version=latest_version)
        return bpy.ops.fourdesinno.defer_addon_update('INVOKE_DEFAULT', latest_version=latest_version)

class F3D_OT_OpenSettingsPopup(Operator):
    bl_idname = "fourdesinno.open_settings_popup"
    bl_label = "FOURDESINNO Settings"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        layout.label(text=f"Installed: {_version_to_text(_local_addon_version())}")
        layout.separator()
        prefs = _addon_prefs()
        if prefs is None:
            col = layout.column()
            col.alert = True
            col.label(text="Addon preferences not found.", icon='ERROR')
            return

        box = layout.box()
        box.label(text="Preview Sizes")
        box.prop(prefs, "preview_card_size")
        box.prop(prefs, "hover_preview_scale")
        layout.label(text="These values match the Addon Preferences panel.")

    def execute(self, context):
        _redraw_view3d()
        return {'FINISHED'}




class F3D_OT_SetAssetType(Operator):
    bl_idname = "fourdesinno.set_asset_type"
    bl_label = "Set Asset Type"

    asset_type: StringProperty(default="model")

    def execute(self, context):
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if settings is None:
            return {'CANCELLED'}

        settings.asset_type = self.asset_type
        settings.strip_offset = 0

        try:
            terms = list(STATE.get("category_terms", [])) or _load_category_cache_from_disk()
        except Exception:
            terms = []
        try:
            usage_map = dict(STATE.get("category_usage_by_type", {}) or {}) or _load_category_usage_cache_from_disk()
        except Exception:
            usage_map = {}
        _sync_selected_category_filters(settings, terms, usage_map=usage_map)

        _clear_browse_snapshot()

        _reset_assets_for_current_filters(settings)

        with STATE_LOCK:
            STATE["dropdown_open"] = ""
            STATE["dropdown_hover_kind"] = ""
            STATE["dropdown_hover_id"] = ""
            STATE["pending_reload_seq"] = int(STATE.get("pending_reload_seq", 0) or 0) + 1

        _redraw_view3d()

        if getattr(settings, "strip_expanded", False):
            _schedule_deferred_asset_reload("Loading assets...", only_if_expanded=True)
        else:
            label = {"model": "3D MODELS", "texture": "TEXTURES", "hdri": "HDRI"}.get(settings.asset_type, "ASSETS")
            _set_status(f"{label} selected. Expand strip to load assets.")
        return {'FINISHED'}



class F3D_OT_ToggleFavoritesOnly(Operator):
    bl_idname = "fourdesinno.toggle_favorites_only"
    bl_label = "Toggle Favorites Only"

    def execute(self, context):
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if settings is None:
            return {'CANCELLED'}

        with STATE_LOCK:
            was_fav = bool(STATE.get("favorites_only", False))
            was_dl = bool(STATE.get("downloaded_only", False))
            new_value = not was_fav
            STATE["favorites_only"] = new_value
            if new_value:
                STATE["downloaded_only"] = False
            STATE["pending_reload_seq"] = int(STATE.get("pending_reload_seq", 0) or 0) + 1

        # Snapshot the current normal browse list so turning favorites OFF is instant.
        if new_value and (not was_fav) and (not was_dl):
            _capture_browse_snapshot(settings)

        # Turning favorites OFF: restore previous browse state instantly when possible.
        if not new_value:
            if _restore_browse_snapshot(settings):
                _set_status("Favorites disabled.")
                return {'FINISHED'}

        _reset_assets_for_current_filters(settings)
        settings.strip_offset = 0

        if new_value:
            count_now, catalog_complete = _populate_special_mode_from_catalog(settings)
        else:
            count_now, catalog_complete = (0, True)

        if getattr(settings, "strip_expanded", False):
            if new_value:
                if count_now:
                    _set_status(f"Loaded {count_now} favorites.")
                else:
                    _set_status("Loading favorites...")
                if not catalog_complete:
                    _schedule_deferred_asset_reload("Loading favorites...", only_if_expanded=True)
            else:
                _schedule_deferred_asset_reload("Loading assets...", only_if_expanded=True)
        else:
            _set_status("Favorites enabled. Expand strip to load assets." if new_value else "Favorites disabled.")
        return {'FINISHED'}


class F3D_OT_ToggleDownloadedOnly(Operator):
    bl_idname = "fourdesinno.toggle_downloaded_only"
    bl_label = "Toggle Downloaded Only"

    def execute(self, context):
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if settings is None:
            return {'CANCELLED'}

        with STATE_LOCK:
            was_fav = bool(STATE.get("favorites_only", False))
            was_dl = bool(STATE.get("downloaded_only", False))
            new_value = not was_dl
            STATE["downloaded_only"] = new_value
            if new_value:
                STATE["favorites_only"] = False
            STATE["pending_reload_seq"] = int(STATE.get("pending_reload_seq", 0) or 0) + 1

        # Snapshot the current normal browse list so turning downloaded OFF is instant.
        if new_value and (not was_fav) and (not was_dl):
            _capture_browse_snapshot(settings)

        # Turning downloaded OFF: restore previous browse state instantly when possible.
        if not new_value:
            if _restore_browse_snapshot(settings):
                _set_status("Downloaded disabled.")
                return {'FINISHED'}

        _reset_assets_for_current_filters(settings)
        settings.strip_offset = 0

        if new_value:
            count_now, catalog_complete = _populate_special_mode_from_catalog(settings)
        else:
            count_now, catalog_complete = (0, True)

        if getattr(settings, "strip_expanded", False):
            if new_value:
                if count_now:
                    _set_status(f"Loaded {count_now} downloaded assets.")
                else:
                    _set_status("Loading downloaded assets...")
                if not catalog_complete:
                    _schedule_deferred_asset_reload("Loading downloaded assets...", only_if_expanded=True)
            else:
                _schedule_deferred_asset_reload("Loading assets...", only_if_expanded=True)
        else:
            _set_status("Downloaded enabled. Expand strip to load assets." if new_value else "Downloaded disabled.")
        return {'FINISHED'}


class F3D_OT_ToggleOnlineMode(Operator):
    bl_idname = "fourdesinno.toggle_online_mode"
    bl_label = "Toggle Online Mode"

    def execute(self, context):
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if settings is None:
            return {'CANCELLED'}

        _clear_browse_snapshot()

        settings.online_enabled = not bool(getattr(settings, "online_enabled", True))
        with STATE_LOCK:
            STATE["online_mode"] = bool(settings.online_enabled)
            STATE["dropdown_open"] = ""
            STATE["dropdown_hover_kind"] = ""
            STATE["dropdown_hover_id"] = ""
            STATE["dropdown_hover_parent_id"] = ""
            STATE["update_checked"] = False
            STATE["update_popup_version"] = ""
        _reset_assets_for_current_filters(settings)
        settings.strip_offset = 0
        if settings.online_enabled:
            if settings.strip_expanded:
                _schedule_deferred_asset_reload("Loading assets...", only_if_expanded=True)
            else:
                _set_status("Online mode enabled.")
        else:
            if settings.strip_expanded:
                try:
                    bpy.ops.fourdesinno.load_assets()
                except Exception:
                    _set_status("Local mode enabled.")
            else:
                _set_status("Local mode enabled. Expand strip to show downloaded assets.")
            _redraw_view3d()
        return {'FINISHED'}


class F3D_OT_LoadAssets(Operator):
    bl_idname = "fourdesinno.load_assets"
    bl_label = "Load / Refresh"

    def execute(self, context):
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if settings is None:
            self.report({'ERROR'}, "Addon properties are not registered.")
            return {'CANCELLED'}
        _clear_browse_snapshot()
        try:
            _set_status("Loading previews..." if _online_mode_enabled(settings) else "Loading local downloaded assets...")
            settings.strip_offset = 0
            try:
                _ensure_category_cache()
                _ensure_category_usage_cache()
            except Exception:
                pass
            loaded = _load_more_assets(settings, reset=True)
            _clear_download()
            with STATE_LOCK:
                total_now = len(STATE["assets"])
                has_more = STATE.get("has_more", False)
                favorites_only = bool(STATE.get("favorites_only", False))
                downloaded_only = bool(STATE.get("downloaded_only", False))
            more_text = " Scroll to load more." if has_more else ""
            label = {"model":"3D models","texture":"textures","hdri":"HDRI"}.get(settings.asset_type, "assets")
            if not _online_mode_enabled(settings):
                _set_status(f"Loaded {total_now} local downloaded {label}. Drag from the viewport strip. .blend downloads start only after placement.")
            elif favorites_only:
                _set_status(f"Loaded {total_now} favorite {label}. Drag from the viewport strip. .blend downloads start only after placement.")
            elif downloaded_only:
                _set_status(f"Loaded {total_now} downloaded {label}. Drag from the viewport strip. .blend downloads start only after placement.")
            else:
                _set_status(f"Loaded {total_now} {label} from FourDesinno.{more_text} Drag from the viewport strip. .blend downloads start only after placement.")
            try:
                _ensure_viewport_modal_running()
            except Exception:
                try:
                    bpy.app.timers.register(_ensure_viewport_modal_running, first_interval=0.1)
                except Exception:
                    pass
            return {'FINISHED'}
        except Exception as exc:
            with STATE_LOCK:
                STATE["assets"] = []
            _set_status(f"Load failed: {exc}")
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class F3D_OT_StripScroll(Operator):
    bl_idname = "fourdesinno.strip_scroll"
    bl_label = "Scroll Strip"
    delta: IntProperty(default=0)

    def execute(self, context):
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if settings is None:
            return {'CANCELLED'}
        with STATE_LOCK:
            total = len(STATE["assets"])
            has_more = bool(STATE.get("has_more", False))
        layout = _layout_from_context(context)
        visible = max(1, layout.get("display_slots", settings.strip_count) if layout else settings.strip_count)
        max_offset = max(0, total - visible)
        settings.strip_offset = max(0, min(max_offset, settings.strip_offset + self.delta))

        if self.delta > 0:
            threshold = max(0, total - visible - 3)
            if settings.strip_offset >= threshold and has_more:
                _set_status("Loading more...")
                try:
                    added = _load_more_assets(settings, reset=False)
                except Exception:
                    added = 0
                    with STATE_LOCK:
                        STATE["has_more"] = False
                    _set_status("Stopped loading more results.")
                with STATE_LOCK:
                    total = len(STATE["assets"])
                    has_more = bool(STATE.get("has_more", False))
                max_offset = max(0, total - visible)
                settings.strip_offset = max(0, min(max_offset, settings.strip_offset + max(1, self.delta)))
                if added > 0:
                    msg = f"Loaded {total} assets."
                    if has_more:
                        msg += " Scroll to load more."
                    _set_status(msg)
                elif not has_more:
                    _set_status(f"Loaded {total} assets. End of results reached.")

        _redraw_view3d()
        return {'FINISHED'}


class F3D_OT_ViewportBrowserModal(Operator):
    bl_idname = "fourdesinno.viewport_browser_modal"
    bl_label = "FOURDESINNO Viewport Browser"
    bl_options = {'INTERNAL'}

    _timer = None
    _placeholder = None
    _asset = None
    _job = None
    _placed_location = None
    _mouse_down = False
    _drag_started = False
    _released = False
    _started_in_strip = False
    _press_x = 0
    _press_y = 0
    _press_card = False
    _drag_threshold_px = 8

    def _remove_placeholder(self):
        if self._placeholder:
            try:
                mesh = self._placeholder.data if getattr(self._placeholder, "type", "") == 'MESH' else None
                if self._placeholder.name in bpy.data.objects:
                    bpy.data.objects.remove(self._placeholder, do_unlink=True)
                if mesh and mesh.name in bpy.data.meshes and mesh.users == 0:
                    bpy.data.meshes.remove(mesh, do_unlink=True)
            except Exception:
                pass
        self._placeholder = None

    def _make_placeholder(self, title):
        mesh = bpy.data.meshes.new(f"FOURDESINNO_GHOST_{_sanitize_filename(title, 'asset')}")
        obj = bpy.data.objects.new(mesh.name, mesh)
        bpy.context.collection.objects.link(obj)
        obj["FOURDESINNO_GHOST_PLACEHOLDER"] = True
        obj.display_type = 'WIRE'
        obj.color = (0.2, 0.6, 1.0, 1.0)
        verts = [
            (-0.4, -0.4, 0.0), (0.4, -0.4, 0.0), (0.4, 0.4, 0.0), (-0.4, 0.4, 0.0),
            (-0.4, -0.4, 0.8), (0.4, -0.4, 0.8), (0.4, 0.4, 0.8), (-0.4, 0.4, 0.8),
        ]
        edges = [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)]
        mesh.from_pydata(verts, edges, [])
        mesh.update()
        self._placeholder = obj
        return obj

    def _start_job(self):
        if self._job or not self._asset:
            return
        self._job = DownloadJob(self._asset)
        self._job.start()
        _set_status(f"Placed {self._asset.get('title')}. Downloading .blend...")

    def _finish_job(self, context):
        if not self._job or not self._job.done:
            return False
        if not self._job.success:
            msg = self._job.error or "Download failed."
            self._remove_placeholder()
            _clear_download()
            _set_status(msg)
            self.report({'ERROR'}, msg)
            self._job = None
            return True
        settings = context.scene.fourdesinno_browser
        _set_download(self._asset.get("title") or "Asset", "Appending .blend", 1, 1)
        imported = _append_primary_from_blend(self._job.filepath, self._asset, link=(settings.import_mode == 'LINK'))
        _move_imported_payload(imported, self._placed_location or context.scene.cursor.location.copy())
        self._remove_placeholder()
        _clear_download()
        _set_status(f"Placed {self._asset.get('title')}.")
        self._job = None
        return True

    def _hit_card(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return None
        with STATE_LOCK:
            STATE["drag_hover_index"] = -1
        STATE["browse_snapshot"] = None
        for card in layout["cards"]:
            if _point_in_rect(event.mouse_region_x, event.mouse_region_y, card):
                with STATE_LOCK:
                    STATE["drag_hover_index"] = card["index"]
                return card
        return None

    def _hit_tab(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return None
        for tab in layout.get("tabs", []):
            if _point_in_rect(event.mouse_region_x, event.mouse_region_y, tab):
                return tab["type"]
        return None

    def _hit_search(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        search_box = layout.get("search_box")
        if not search_box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, search_box)

    def _hit_search_clear(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        box = layout.get("search_clear_box")
        if not box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, box)

    def _hit_category_box(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        box = layout.get("category_box")
        if not box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, box)

    def _hit_subcategory_box(self, context, event):
        return False

    def _hit_dropdown_item(self, context, event):
        layout = _layout_from_context(context)
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if not layout or settings is None:
            return ("", None)
        _kind, menu = _open_dropdown_layout(settings, layout)
        if not menu:
            return ("", None)
        main_menu = menu.get("main")
        sub_menu = menu.get("sub")
        if main_menu:
            for item in main_menu["items"]:
                if _point_in_rect(event.mouse_region_x, event.mouse_region_y, item):
                    return ("category", item["row"])
        if sub_menu:
            for item in sub_menu["items"]:
                if _point_in_rect(event.mouse_region_x, event.mouse_region_y, item):
                    return ("subcategory", item["row"])
        return ("", None)

    def _hover_dropdown_item(self, context, event):
        layout = _layout_from_context(context)
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if not layout or settings is None:
            return ("", "", "")
        _kind, menu = _open_dropdown_layout(settings, layout)
        if not menu:
            return ("", "", "")
        main_menu = menu.get("main")
        sub_menu = menu.get("sub")
        if main_menu:
            for item in main_menu["items"]:
                if _point_in_rect(event.mouse_region_x, event.mouse_region_y, item):
                    row = item["row"]
                    row_id = str(row.get("id") or "")
                    return ("category", row_id, row_id)
        if sub_menu:
            submenu_parent_id = str(menu.get("submenu_parent_id", "") or "")
            for item in sub_menu["items"]:
                if _point_in_rect(event.mouse_region_x, event.mouse_region_y, item):
                    row = item["row"]
                    return ("subcategory", str(row.get("id") or ""), submenu_parent_id)
        return ("", "", "")

    def _mouse_on_category_controls(self, context, event):
        layout = _layout_from_context(context)
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if not layout or settings is None:
            return False

        x = event.mouse_region_x
        y = event.mouse_region_y
        pad = 12

        category_box = layout.get("category_box")
        if category_box:
            if (category_box["x1"] - pad) <= x <= (category_box["x2"] + pad) and (category_box["y1"] - pad) <= y <= (category_box["y2"] + pad):
                return True

        _kind, menu = _open_dropdown_layout(settings, layout)
        if not menu:
            return False

        main_menu = menu.get("main")
        sub_menu = menu.get("sub")

        if main_menu:
            if (main_menu["x1"] - pad) <= x <= (main_menu["x2"] + pad) and (main_menu["y1"] - pad) <= y <= (main_menu["y2"] + pad):
                return True

        if sub_menu:
            if (sub_menu["x1"] - pad) <= x <= (sub_menu["x2"] + pad) and (sub_menu["y1"] - pad) <= y <= (sub_menu["y2"] + pad):
                return True

        if main_menu and sub_menu:
            bridge_x1 = min(main_menu["x2"], sub_menu["x1"]) - pad
            bridge_x2 = max(main_menu["x2"], sub_menu["x1"]) + pad
            bridge_y1 = min(main_menu["y1"], sub_menu["y1"]) - pad
            bridge_y2 = max(main_menu["y2"], sub_menu["y2"]) + pad
            if bridge_x1 <= x <= bridge_x2 and bridge_y1 <= y <= bridge_y2:
                return True

        return False

    def _hit_search_go(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        box = layout.get("search_go_box")
        if not box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, box)

    def _hit_load(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        load_box = layout.get("load_box")
        if not load_box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, load_box)
    def _hit_move_handle(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        box = layout.get("move_box")
        if not box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, box)


    def _hit_update_button(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        box = layout.get("update_box")
        if not box or box["x2"] <= box["x1"]:
            return False
        with STATE_LOCK:
            info = dict(STATE.get("update_info", {}) or {})
        latest_text = str(info.get("latest_version") or "").strip()
        has_update = bool(latest_text) and _parse_version_value(latest_text) > _local_addon_version()
        if not has_update:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, box)

    def _update_panel_hit(self, context, event):
        layout = _layout_from_context(context)
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if not layout or settings is None:
            return None
        with STATE_LOCK:
            upd_open = bool(STATE.get("update_panel_open", False))
            info = dict(STATE.get("update_info", {}) or {})
        latest_text = str(info.get("latest_version") or "").strip()
        has_update = bool(latest_text) and _parse_version_value(latest_text) > _local_addon_version()
        if not (upd_open and has_update):
            return None
        panel = _update_panel_layout(settings, layout)
        if not panel:
            return None
        x = event.mouse_region_x
        y = event.mouse_region_y
        if not _point_in_rect(x, y, panel):
            return None
        for key in ("btn_update_now", "btn_ignore", "btn_later", "btn_changelog"):
            rect = panel.get(key)
            if rect and _point_in_rect(x, y, rect):
                return ("update", key)
        return ("update", "inside")


    def _hit_power_button(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        box = layout.get("power_box")
        if not box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, box)

    def _hit_settings_button(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        box = layout.get("settings_box")
        if not box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, box)


    def _settings_panel_hit(self, context, event):
        layout = _layout_from_context(context)
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if not layout or settings is None:
            return None
        with STATE_LOCK:
            if not bool(STATE.get("settings_open", False)):
                return None
        panel = _settings_panel_layout(settings, layout)
        if not panel:
            return None
        x = event.mouse_region_x
        y = event.mouse_region_y
        if not _point_in_rect(x, y, panel):
            return None
        # return which control was hit
        btn = panel.get("assets_btn")
        if btn and _point_in_rect(x, y, btn):
            return ("assets", "open")

        btn = panel.get("website_btn")
        if btn and _point_in_rect(x, y, btn):
            return ("website", "open")

        btn = panel.get("support_btn")
        if btn and _point_in_rect(x, y, btn):
            return ("support", "open")

        btn = panel.get("discord_btn")
        if btn and _point_in_rect(x, y, btn):
            return ("discord", "open")

        btn = panel.get("youtube_btn")
        if btn and _point_in_rect(x, y, btn):
            return ("youtube", "open")

        btn = panel.get("patreon_btn")
        if btn and _point_in_rect(x, y, btn):
            return ("patreon", "open")
        for key in ("row_preview", "row_hover"):
            row = panel.get(key, {})
            for part in ("minus", "plus", "value"):
                rect = (row or {}).get(part)
                if rect and _point_in_rect(x, y, rect):
                    return (key, part)
        return ("panel", "inside")


    def _hit_toggle_expand(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        toggle_box = layout.get("toggle_box")
        if not toggle_box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, toggle_box)

    def _hit_favorites_filter(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        box = layout.get("fav_filter_box")
        if not box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, box)

    def _hit_downloaded_filter(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        box = layout.get("downloaded_filter_box")
        if not box:
            return False
        return _point_in_rect(event.mouse_region_x, event.mouse_region_y, box)

    def _hit_card_favorite(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return None
        for card in layout["cards"]:
            fav_rect = {"x1": card["fav_x1"], "y1": card["fav_y1"], "x2": card["fav_x2"], "y2": card["fav_y2"]}
            if _point_in_rect(event.mouse_region_x, event.mouse_region_y, fav_rect):
                return card
        return None

    def _hit_left_arrow(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        arrow = layout.get("left_arrow")
        return bool(arrow and _point_in_rect(event.mouse_region_x, event.mouse_region_y, arrow))

    def _hit_right_arrow(self, context, event):
        layout = _layout_from_context(context)
        if not layout:
            return False
        arrow = layout.get("right_arrow")
        return bool(arrow and _point_in_rect(event.mouse_region_x, event.mouse_region_y, arrow))

    def _update_placeholder_loc(self, context, event):
        if self._placeholder is None:
            return
        if context.area and context.area.type == 'VIEW_3D' and context.region and context.region.type == 'WINDOW':
            self._placed_location = _get_drop_location(context, event)
            self._placeholder.location = self._placed_location

    def _apply_category_selection(self, context, dropdown_kind, dropdown_row):
        settings = getattr(context.scene, "fourdesinno_browser", None)
        if settings is None:
            return False
        try:
            terms = _ensure_category_cache()
        except Exception:
            terms = []
        try:
            usage_map = _ensure_category_usage_cache()
        except Exception:
            usage_map = {}

        if dropdown_kind == "category":
            _set_category_term(settings, dropdown_row if dropdown_row and dropdown_row.get("id") else None)
        elif dropdown_kind == "subcategory":
            _set_subcategory_term(settings, dropdown_row if dropdown_row and dropdown_row.get("id") else None, terms=terms)
        else:
            return False

        _sync_selected_category_filters(settings, terms, usage_map=usage_map)
        with STATE_LOCK:
            STATE["dropdown_open"] = ""
            STATE["dropdown_hover_kind"] = ""
            STATE["dropdown_hover_id"] = ""
            STATE["dropdown_hover_parent_id"] = ""

        _clear_browse_snapshot()

        _reset_assets_for_current_filters(settings)
        _redraw_view3d()
        if settings.strip_expanded:
            _schedule_deferred_asset_reload("Loading assets...", only_if_expanded=True)
        else:
            msg = f"Category: {settings.category_term_name}." if dropdown_kind == "category" else f"Subcategory: {settings.subcategory_term_name}."
            _set_status(msg + " Expand strip to load assets.")
        return True

    def modal(self, context, event):
        if not hasattr(context.scene, "fourdesinno_browser"):
            return {'PASS_THROUGH'}

        # Auto-cancel this modal if it is no longer in the owner viewport (prevents dead UI after moving).
        try:
            owner_win_ptr, owner_area_ptr = _validate_or_reset_owner(None, None)
            cur_win_ptr = context.window.as_pointer() if context.window else None
            cur_area_ptr = context.area.as_pointer() if context.area else None
            if owner_win_ptr and owner_area_ptr and (cur_win_ptr != owner_win_ptr or cur_area_ptr != owner_area_ptr):
                self.cancel(context)
                return {'CANCELLED'}
        except Exception:
            pass
        # Handle moving the strip between VIEW_3D areas using the move button.
        with STATE_LOCK:
            moving = bool(STATE.get("strip_move_dragging", False))
        if moving:
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                target = None
                try:
                    target = _find_view3d_area_at_window_xy(context.window, int(event.mouse_x), int(event.mouse_y))
                except Exception:
                    target = None

                if target is not None:
                    try:
                        with STATE_LOCK:
                            STATE["strip_area_pointer"] = target.as_pointer()
                            STATE["strip_window_pointer"] = context.window.as_pointer() if context.window else None
                    except Exception:
                        pass

                with STATE_LOCK:
                    STATE["strip_move_dragging"] = False
                    STATE["strip_move_hover_area"] = None

                # Cancel this modal cleanly so a new one can start in the new owner viewport.
                try:
                    self.cancel(context)
                except Exception:
                    try:
                        with STATE_LOCK:
                            STATE["modal_running"] = False
                    except Exception:
                        pass

                try:
                    bpy.app.timers.register(_ensure_viewport_modal_running, first_interval=0.05)
                except Exception:
                    pass

                _redraw_view3d()
                return {'CANCELLED'}

            if event.type == 'MOUSEMOVE':
                try:
                    target = _find_view3d_area_at_window_xy(context.window, int(event.mouse_x), int(event.mouse_y))
                    with STATE_LOCK:
                        STATE["strip_move_hover_area"] = target.as_pointer() if target else None
                except Exception:
                    pass
                return {'RUNNING_MODAL'}

            return {'RUNNING_MODAL'}

            return {'RUNNING_MODAL'}

            if event.type == 'MOUSEMOVE':
                try:
                    target = _find_view3d_area_at_window_xy(context.window, int(event.mouse_x), int(event.mouse_y))
                    with STATE_LOCK:
                        STATE["strip_move_hover_area"] = target.as_pointer() if target else None
                except Exception:
                    pass
                return {'RUNNING_MODAL'}

            return {'RUNNING_MODAL'}


        obj = getattr(context, 'object', None)
        if obj is not None and getattr(obj, 'mode', 'OBJECT') != 'OBJECT':
            return {'PASS_THROUGH'}

        over_strip = _mouse_over_strip(context, event)


        if over_strip:
            try:
                if getattr(event, "mouse_region_y", 0) > 6 and getattr(context, "window", None):
                    context.window.cursor_set('DEFAULT')
            except Exception:
                pass

        if event.type == 'TIMER':
            _redraw_view3d()
            if self._released and self._job:
                if self._finish_job(context):
                    self._reset_drag_state()
            return {'PASS_THROUGH'}

        if context.area and context.area.type == 'VIEW_3D' and context.region and context.region.type == 'WINDOW':
            if context.scene.fourdesinno_browser.strip_expanded:
                self._hit_card(context, event)
            else:
                with STATE_LOCK:
                    STATE["drag_hover_index"] = -1

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            with STATE_LOCK:
                dropdown_open = str(STATE.get("dropdown_open", "") or "")

                        # Settings panel interactions (wins before other strip logic)
            # Update panel interactions (wins before other strip logic)
            hit_u = self._update_panel_hit(context, event)
            if hit_u:
                _kind, which_btn = hit_u
                with STATE_LOCK:
                    info = dict(STATE.get("update_info", {}) or {})
                latest_version = str(info.get("latest_version") or "").strip()
                download_url = str(info.get("download_url") or "").strip()
                changelog_url = str(info.get("changelog_url") or "").strip()
            
                if which_btn == "btn_update_now":
                    try:
                        bpy.ops.fourdesinno.install_addon_update('INVOKE_DEFAULT', download_url=download_url, latest_version=latest_version)
                    except Exception:
                        pass
                    return {'RUNNING_MODAL'}
                if which_btn == "btn_ignore":
                    try:
                        bpy.ops.fourdesinno.ignore_addon_update('INVOKE_DEFAULT', latest_version=latest_version)
                    except Exception:
                        pass
                    with STATE_LOCK:
                        STATE["update_panel_open"] = False
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}
                if which_btn == "btn_later":
                    try:
                        bpy.ops.fourdesinno.defer_addon_update('INVOKE_DEFAULT', latest_version=latest_version)
                    except Exception:
                        pass
                    with STATE_LOCK:
                        STATE["update_panel_open"] = False
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}
                if which_btn == "btn_changelog" and changelog_url:
                    try:
                        bpy.ops.wm.url_open(url=changelog_url)
                    except Exception:
                        pass
                    return {'RUNNING_MODAL'}
                return {'RUNNING_MODAL'}

            hit = self._settings_panel_hit(context, event)
            if hit:
                kind, part = hit
                prefs = _addon_prefs()
                if kind == "assets" and part == "open":
                    try:
                        folder = _assets_folder_to_open()
                        if folder:
                            bpy.ops.wm.path_open(filepath=folder)
                    except Exception:
                        pass
                    return {'RUNNING_MODAL'}

                if kind == "website" and part == "open":
                    try:
                        bpy.ops.wm.url_open(url="https://www.fourdesinno.com/")
                    except Exception:
                        pass
                    return {'RUNNING_MODAL'}

                if kind == "support" and part == "open":
                    try:
                        bpy.ops.wm.url_open(url="https://fourdesinno.com/contact/")
                    except Exception:
                        pass
                    return {'RUNNING_MODAL'}

                if kind == "discord" and part == "open":
                    try:
                        bpy.ops.wm.url_open(url="https://discord.gg/PkksxKk8")
                    except Exception:
                        pass
                    return {'RUNNING_MODAL'}

                if kind == "youtube" and part == "open":
                    try:
                        bpy.ops.wm.url_open(url="https://www.youtube.com/@FourDesinno")
                    except Exception:
                        pass
                    return {'RUNNING_MODAL'}

                if kind == "patreon" and part == "open":
                    try:
                        bpy.ops.wm.url_open(url="https://www.patreon.com/c/fourdesinno/membership")
                    except Exception:
                        pass
                    return {'RUNNING_MODAL'}
                if kind in {"row_preview", "row_hover"} and part in {"minus", "plus"}:
                    if prefs is not None:
                        if kind == "row_preview":
                            cur = int(getattr(prefs, "preview_card_size", 108) or 108)
                            step = 1
                            cur = cur - step if part == "minus" else cur + step
                            cur = max(72, min(320, cur))
                            prefs.preview_card_size = cur
                        else:
                            cur = int(getattr(prefs, "hover_preview_scale", 6) or 6)
                            cur = cur - 1 if part == "minus" else cur + 1
                            cur = max(1, min(20, cur))
                            prefs.hover_preview_scale = cur
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

                if kind in {"row_preview", "row_hover"} and part == "value":
                    # Start numeric editing for this field.
                    if prefs is not None:
                        if kind == "row_preview":
                            cur = int(getattr(prefs, "preview_card_size", 108) or 108)
                        else:
                            cur = int(getattr(prefs, "hover_preview_scale", 6) or 6)
                    else:
                        cur = 0
                    with STATE_LOCK:
                        STATE["settings_edit_kind"] = kind
                        STATE["settings_edit_buffer"] = str(cur) if cur else ""
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

                # click inside panel but not on controls
                return {'RUNNING_MODAL'}


            # If update panel is open and the user clicks outside it, close it (unless clicking the update button).
            with STATE_LOCK:
                upd_open = bool(STATE.get("update_panel_open", False))
            if upd_open:
                if not self._hit_update_button(context, event):
                    with STATE_LOCK:
                        STATE["update_panel_open"] = False
                    _redraw_view3d()
            # If settings panel is open and the user clicks outside it, close it.
            # BUT: do not auto-close here when the click is on the gear button (gear toggles it).
            with STATE_LOCK:
                was_open = bool(STATE.get("settings_open", False))
            if was_open:
                if not self._hit_settings_button(context, event):
                    with STATE_LOCK:
                        STATE["settings_open"] = False
                    _redraw_view3d()
                # Continue handling click (so strip buttons still work) if click was on strip.

            # Category menu interactions must win before any generic strip button logic.
            if dropdown_open == "category":
                dropdown_kind, dropdown_row = self._hit_dropdown_item(context, event)
                if dropdown_kind:
                    self._apply_category_selection(context, dropdown_kind, dropdown_row)
                    return {'RUNNING_MODAL'}

                if self._hit_category_box(context, event):
                    with STATE_LOCK:
                        opening = STATE.get("dropdown_open") != "category"
                        STATE["dropdown_open"] = "category" if opening else ""
                        STATE["settings_open"] = False
                        STATE["dropdown_hover_kind"] = ""
                        STATE["dropdown_hover_id"] = ""
                        STATE["dropdown_hover_parent_id"] = str(getattr(context.scene.fourdesinno_browser, "category_term_id", "") or "")
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

                # Click inside the open category controls/menu should keep the menu alive.
                if self._mouse_on_category_controls(context, event):
                    return {'RUNNING_MODAL'}

                # Outside click closes the menu cleanly.
                with STATE_LOCK:
                    STATE["dropdown_open"] = ""
                    STATE["dropdown_hover_kind"] = ""
                    STATE["dropdown_hover_id"] = ""
                    STATE["dropdown_hover_parent_id"] = ""
                _redraw_view3d()
                if over_strip:
                    return {'RUNNING_MODAL'}

            if over_strip:
                with STATE_LOCK:
                    dropdown_open = str(STATE.get("dropdown_open", "") or "")

                # Category menu interactions get priority while the menu is open.
                hit_type = self._hit_tab(context, event)
                if hit_type:
                    with STATE_LOCK:
                        STATE["search_editing"] = False
                    bpy.ops.fourdesinno.set_asset_type(asset_type=hit_type)
                    return {'RUNNING_MODAL'}

                if self._hit_left_arrow(context, event):
                    bpy.ops.fourdesinno.strip_scroll(delta=-1)
                    return {'RUNNING_MODAL'}

                if self._hit_right_arrow(context, event):
                    bpy.ops.fourdesinno.strip_scroll(delta=1)
                    return {'RUNNING_MODAL'}

                fav_card = self._hit_card_favorite(context, event)
                if fav_card:
                    asset = fav_card["asset"]
                    now_fav = _toggle_favorite(asset)
                    _set_status(f'{"Added to" if now_fav else "Removed from"} favorites: {asset.get("title")}')
                    return {'RUNNING_MODAL'}

                if self._hit_favorites_filter(context, event):
                    bpy.ops.fourdesinno.toggle_favorites_only()
                    return {'RUNNING_MODAL'}

                if self._hit_downloaded_filter(context, event):
                    bpy.ops.fourdesinno.toggle_downloaded_only()
                    return {'RUNNING_MODAL'}

                if self._hit_move_handle(context, event):
                    with STATE_LOCK:
                        STATE["strip_move_dragging"] = True
                        STATE["strip_move_hover_area"] = None
                    return {'RUNNING_MODAL'}

                if self._hit_load(context, event):
                    bpy.ops.fourdesinno.load_assets()
                    return {'RUNNING_MODAL'}

                if self._hit_update_button(context, event):
                    with STATE_LOCK:
                        STATE["update_panel_open"] = not bool(STATE.get("update_panel_open", False))
                        if STATE.get("update_panel_open"):
                            STATE["settings_open"] = False
                            STATE["dropdown_open"] = ""
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

                if self._hit_settings_button(context, event):
                    # Toggle settings popover (gear)
                    anchor_x2 = 0
                    try:
                        layout_now = _layout_from_context(context)
                        box_now = (layout_now or {}).get("settings_box")
                        anchor_x2 = int((box_now or {}).get("x2", 0) or 0)
                    except Exception:
                        anchor_x2 = 0

                    with STATE_LOCK:
                        now_open = not bool(STATE.get("settings_open", False))
                        STATE["settings_open"] = now_open
                        STATE["settings_edit_kind"] = ""
                        STATE["settings_edit_buffer"] = ""
                        if now_open:
                            # Freeze the popover anchor so it doesn't move while changing preview size.
                            STATE["settings_anchor_x2"] = anchor_x2
                            # close category dropdown when opening settings
                            STATE["dropdown_open"] = ""
                            STATE["dropdown_hover_kind"] = ""
                            STATE["dropdown_hover_id"] = ""
                            STATE["dropdown_hover_parent_id"] = ""
                        else:
                            STATE["settings_anchor_x2"] = 0
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

                if self._hit_power_button(context, event):
                    bpy.ops.fourdesinno.toggle_online_mode()
                    return {'RUNNING_MODAL'}

                if self._hit_toggle_expand(context, event):
                    settings = context.scene.fourdesinno_browser
                    settings.strip_expanded = not bool(settings.strip_expanded)
                    if settings.strip_expanded:
                        with STATE_LOCK:
                            need_load = (not STATE.get("assets")) and (not STATE.get("loading_more"))
                        if need_load:
                            _set_status("Loading assets...")
                            _redraw_view3d()
                            try:
                                bpy.ops.fourdesinno.load_assets()
                            except Exception:
                                pass
                        else:
                            _set_status("Preview strip expanded.")
                    else:
                        _set_status("Preview strip collapsed.")
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

                if self._hit_category_box(context, event):
                    if not _online_mode_enabled(context.scene.fourdesinno_browser):
                        _set_status("Local mode enabled. Categories are unavailable offline.")
                        return {'RUNNING_MODAL'}
                    try:
                        _ensure_category_cache()
                    except Exception:
                        pass
                    with STATE_LOCK:
                        opening = STATE.get("dropdown_open") != "category"
                        STATE["dropdown_open"] = "category" if opening else ""
                        STATE["dropdown_hover_kind"] = ""
                        STATE["dropdown_hover_id"] = ""
                        STATE["dropdown_hover_parent_id"] = str(getattr(context.scene.fourdesinno_browser, "category_term_id", "") or "")
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

                if self._hit_search_clear(context, event):
                    settings = context.scene.fourdesinno_browser
                    _clear_browse_snapshot()
                    settings.search_text = ""
                    with STATE_LOCK:
                        STATE["search_editing"] = False
                        STATE["search_buffer"] = ""
                        STATE["assets"] = []
                        STATE["pending_assets"] = []
                        STATE["next_page"] = 1
                        STATE["has_more"] = True
                    settings.strip_offset = 0
                    _set_status(f"Cleared search for {settings.asset_type}.")
                    bpy.ops.fourdesinno.load_assets()
                    return {'RUNNING_MODAL'}

                if self._hit_search_go(context, event):
                    _apply_inline_search(context)
                    return {'RUNNING_MODAL'}

                if self._hit_search(context, event):
                    settings = context.scene.fourdesinno_browser
                    # Text search always resets category filter to ALL CATEGORIES (but keeps current tab/type).
                    settings.category_term_id = ""
                    settings.category_term_slug = ""
                    settings.category_term_name = "ALL CATEGORIES"
                    settings.subcategory_term_id = ""
                    settings.subcategory_term_slug = ""
                    settings.subcategory_term_name = "ALL SUBCATEGORIES"
                    with STATE_LOCK:
                        STATE["dropdown_open"] = ""
                        STATE["dropdown_hover_kind"] = ""
                        STATE["dropdown_hover_id"] = ""
                        STATE["dropdown_hover_parent_id"] = ""
                        STATE["search_editing"] = True
                        STATE["search_buffer"] = settings.search_text or ""
                    _set_status(f"Editing search for {settings.asset_type}. Type, Enter to apply, Esc to cancel.")
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

                card = self._hit_card(context, event)
                if card:
                    self._asset = card["asset"]
                    if (context.scene.fourdesinno_browser.asset_type or "model") != "model":
                        label = "textures" if context.scene.fourdesinno_browser.asset_type == "texture" else "HDRI"
                        _set_status(f"{self._asset.get('title')} is listed under {label}. Drag-place is currently only enabled for .blend models.")
                        return {'RUNNING_MODAL'}
                    # Do not start drag on click-down (prevents accidental downloads).
                    # Begin drag only after the mouse moves beyond a small threshold.
                    self._mouse_down = True
                    self._drag_started = False
                    self._released = False
                    self._started_in_strip = True
                    self._press_x = int(event.mouse_region_x)
                    self._press_y = int(event.mouse_region_y)
                    self._press_card = True
                    with STATE_LOCK:
                        STATE["active_asset_id"] = str(self._asset.get("id") or "")
                        STATE["dragging"] = False
                    _set_status(f"Selected {self._asset.get('title')}. Drag to place.")
                    return {'RUNNING_MODAL'}

                return {'RUNNING_MODAL'}

        with STATE_LOCK:
            settings_edit_kind = str(STATE.get("settings_edit_kind", "") or "")
            settings_edit_buffer = str(STATE.get("settings_edit_buffer", "") or "")

        if settings_edit_kind:
            # Numeric editing for settings popover value boxes.
            def _apply_settings_buffer():
                prefs = _addon_prefs()
                if prefs is None:
                    return
                txt = (settings_edit_buffer or "").strip()
                if not txt.isdigit():
                    return
                val = int(txt)
                if settings_edit_kind == "row_preview":
                    val = max(72, min(320, val))
                    prefs.preview_card_size = val
                elif settings_edit_kind == "row_hover":
                    val = max(1, min(20, val))
                    prefs.hover_preview_scale = val

            if event.value == 'PRESS':
                ch = getattr(event, "ascii", "") or ""
                if ch and ch.isdigit():
                    with STATE_LOCK:
                        # keep it reasonable length
                        STATE["settings_edit_buffer"] = (settings_edit_buffer + ch)[:4]
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

            if event.type == 'BACK_SPACE' and event.value == 'PRESS':
                with STATE_LOCK:
                    STATE["settings_edit_buffer"] = settings_edit_buffer[:-1]
                _redraw_view3d()
                return {'RUNNING_MODAL'}

            if event.type in {'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
                _apply_settings_buffer()
                with STATE_LOCK:
                    STATE["settings_edit_kind"] = ""
                    STATE["settings_edit_buffer"] = ""
                _redraw_view3d()
                return {'RUNNING_MODAL'}

            if event.type == 'ESC' and event.value == 'PRESS':
                with STATE_LOCK:
                    STATE["settings_edit_kind"] = ""
                    STATE["settings_edit_buffer"] = ""
                _redraw_view3d()
                return {'RUNNING_MODAL'}

            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                # Clicking anywhere else applies (if valid) and ends editing.
                # Clicking inside the same value box keeps editing (handled earlier).
                _apply_settings_buffer()
                with STATE_LOCK:
                    STATE["settings_edit_kind"] = ""
                    STATE["settings_edit_buffer"] = ""
                _redraw_view3d()
                # continue normal click handling too
                # (do not return)
        with STATE_LOCK:
            search_editing = bool(STATE.get("search_editing", False))
            search_buffer = str(STATE.get("search_buffer", ""))

        if search_editing:
            if event.value == 'PRESS':
                ch = getattr(event, "ascii", "") or ""
                if ch and ord(ch[0]) >= 32:
                    with STATE_LOCK:
                        STATE["search_buffer"] = search_buffer + ch
                        new_text = STATE["search_buffer"]
                    _set_status(f"Editing search: {new_text}")
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}

            if event.type == 'BACK_SPACE' and event.value == 'PRESS':
                with STATE_LOCK:
                    STATE["search_buffer"] = search_buffer[:-1]
                    new_text = STATE["search_buffer"]
                _set_status(f"Editing search: {new_text}")
                _redraw_view3d()
                return {'RUNNING_MODAL'}

            if event.type == 'DEL' and event.value == 'PRESS':
                with STATE_LOCK:
                    STATE["search_buffer"] = ""
                _set_status("Editing search:")
                _redraw_view3d()
                return {'RUNNING_MODAL'}

            if event.type in {'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
                _apply_inline_search(context)
                return {'RUNNING_MODAL'}

            if event.type == 'ESC' and event.value == 'PRESS':
                settings = context.scene.fourdesinno_browser
                with STATE_LOCK:
                    STATE["search_editing"] = False
                    STATE["search_buffer"] = settings.search_text or ""
                _set_status("Search edit cancelled.")
                _redraw_view3d()
                return {'RUNNING_MODAL'}

            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                if self._hit_search(context, event):
                    return {'RUNNING_MODAL'}
                if self._hit_search_clear(context, event):
                    with STATE_LOCK:
                        STATE["search_buffer"] = ""
                    _set_status("Editing search:")
                    _redraw_view3d()
                    return {'RUNNING_MODAL'}
                if self._hit_search_go(context, event):
                    _apply_inline_search(context)
                    return {'RUNNING_MODAL'}
                settings = context.scene.fourdesinno_browser
                with STATE_LOCK:
                    STATE["search_editing"] = False
                    STATE["search_buffer"] = settings.search_text or ""
                _set_status("Search edit cancelled.")
                _redraw_view3d()
                return {'RUNNING_MODAL'}

            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            with STATE_LOCK:
                dropdown_open = str(STATE.get("dropdown_open", "") or "")
                prev_hover_kind = str(STATE.get("dropdown_hover_kind", "") or "")
                prev_hover_id = str(STATE.get("dropdown_hover_id", "") or "")
                prev_hover_parent_id = str(STATE.get("dropdown_hover_parent_id", "") or "")
            if dropdown_open:
                hover_kind, hover_id, hover_parent_id = self._hover_dropdown_item(context, event)
                if hover_kind != prev_hover_kind or hover_id != prev_hover_id or hover_parent_id != prev_hover_parent_id:
                    with STATE_LOCK:
                        STATE["dropdown_hover_kind"] = hover_kind
                        STATE["dropdown_hover_id"] = hover_id
                        STATE["dropdown_hover_parent_id"] = hover_parent_id
                    _redraw_view3d()
                return {'RUNNING_MODAL'}

            # If the user pressed a card in the strip, only start the drag after moving a few pixels.
            if self._mouse_down and self._started_in_strip and (not self._drag_started) and (not self._released) and getattr(self, "_press_card", False):
                dx = int(event.mouse_region_x) - int(getattr(self, "_press_x", 0))
                dy = int(event.mouse_region_y) - int(getattr(self, "_press_y", 0))
                thr = int(getattr(self, "_drag_threshold_px", 8) or 8)
                if (dx * dx + dy * dy) >= (thr * thr):
                    self._drag_started = True
                    self._press_card = False
                    with STATE_LOCK:
                        STATE["active_asset_id"] = str((self._asset or {}).get("id") or "")
                        STATE["dragging"] = True
                    if self._placeholder is None:
                        self._make_placeholder((self._asset or {}).get("title") or "Asset")
                    self._update_placeholder_loc(context, event)
                    _set_status(f"Dragging {(self._asset or {}).get('title')}... Release in the scene to place.")
                    return {'RUNNING_MODAL'}
            if over_strip:
                return {'RUNNING_MODAL'}
            if self._drag_started and self._placeholder is not None and self._mouse_down and not self._released:
                self._update_placeholder_loc(context, event)
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            # If this was only a click (no drag), do not place/download anything.
            if self._started_in_strip and self._mouse_down and (not self._drag_started):
                self._mouse_down = False
                self._press_card = False
                self._started_in_strip = False
                return {'RUNNING_MODAL'}
            if self._drag_started and self._started_in_strip:
                self._mouse_down = False
                if self._placeholder is not None and self._placed_location is not None:
                    self._placeholder.location = self._placed_location
                self._released = True
                self._start_job()
                return {'RUNNING_MODAL'}
            if over_strip:
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            with STATE_LOCK:
                dropdown_open = str(STATE.get("dropdown_open", "") or "")
            if dropdown_open:
                with STATE_LOCK:
                    STATE["dropdown_open"] = ""
                    STATE["dropdown_hover_kind"] = ""
                    STATE["dropdown_hover_id"] = ""
                    STATE["dropdown_hover_parent_id"] = ""
                _redraw_view3d()
                return {'RUNNING_MODAL'}
            if self._drag_started or self._job:
                if self._job:
                    self._job.cancel()
                self._remove_placeholder()
                _clear_download()
                _set_status("Placement cancelled.")
                self._reset_drag_state()
                return {'RUNNING_MODAL'}
            if over_strip:
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        if event.type == 'WHEELUPMOUSE' and event.value == 'PRESS':
            if over_strip:
                bpy.ops.fourdesinno.strip_scroll(delta=-1)
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        if event.type == 'WHEELDOWNMOUSE' and event.value == 'PRESS':
            if over_strip:
                bpy.ops.fourdesinno.strip_scroll(delta=1)
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        if over_strip:
            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def _reset_drag_state(self):
        self._asset = None
        self._mouse_down = False
        self._drag_started = False
        self._released = False
        self._started_in_strip = False
        self._placed_location = None
        with STATE_LOCK:
            STATE["active_asset_id"] = ""
            STATE["dragging"] = False

    def invoke(self, context, event):
        with STATE_LOCK:
            if STATE.get("modal_running"):
                return {'CANCELLED'}
            STATE["active_asset_id"] = ""
            STATE["dragging"] = False
            STATE["drag_hover_index"] = -1
            STATE["dropdown_open"] = ""
            STATE["dropdown_hover_kind"] = ""
            STATE["dropdown_hover_id"] = ""
            STATE["dropdown_hover_parent_id"] = ""
            STATE["search_editing"] = False
            STATE["modal_running"] = True
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        _set_status("Viewport strip ready. Press a preview and drag into the scene.")
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self._remove_placeholder()
        if self._timer is not None:
            try:
                context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        with STATE_LOCK:
            STATE["modal_running"] = False
            STATE["active_asset_id"] = ""
            STATE["dragging"] = False
            STATE["drag_hover_index"] = -1
            STATE["dropdown_open"] = ""
            STATE["dropdown_hover_kind"] = ""
            STATE["dropdown_hover_id"] = ""
            STATE["dropdown_hover_parent_id"] = ""


# ---------------------------------------------------------
# register
# ---------------------------------------------------------


CLASSES = (
    F3D_AddonPreferences,
    F3D_BrowserSettings,
    F3D_OT_OpenUpdateLink,
    F3D_OT_InstallAddonUpdate,
    F3D_OT_IgnoreAddonUpdate,
    F3D_OT_DeferAddonUpdate,
    F3D_OT_UpdatePrompt,
    F3D_OT_SetAssetType,
    F3D_OT_ToggleOnlineMode,
    F3D_OT_ToggleFavoritesOnly,
    F3D_OT_ToggleDownloadedOnly,
    F3D_OT_LoadAssets,
    F3D_OT_StripScroll,
    F3D_OT_ViewportBrowserModal,
)


def _reset_runtime_state_for_file_load():
    _clear_download()
    _clear_preview_runtime_cache()
    try:
        scene = getattr(bpy.context, "scene", None)
        settings = getattr(scene, "fourdesinno_browser", None) if scene is not None else None
        if settings is not None:
            settings.strip_expanded = False
            with STATE_LOCK:
                STATE["online_mode"] = bool(getattr(settings, "online_enabled", True))
    except Exception:
        pass
    with STATE_LOCK:
        STATE["modal_running"] = False
        STATE["active_asset_id"] = ""
        STATE["dragging"] = False
        STATE["drag_from_strip"] = False
        STATE["drag_hover_index"] = -1
        STATE["strip_area_pointer"] = None
        STATE["search_editing"] = False
        STATE["search_buffer"] = ""
        STATE["dropdown_open"] = ""
        STATE["dropdown_hover_kind"] = ""
        STATE["dropdown_hover_id"] = ""
        STATE["dropdown_hover_parent_id"] = ""
        STATE["loading_more"] = False
        STATE["status"] = "Idle."
        STATE["download"] = {
            "title": "",
            "phase": "",
            "bytes_done": 0,
            "bytes_total": 0,
            "percent": 0,
        }
        STATE["assets"] = []
        STATE["pending_assets"] = []
        STATE["thumb_queue"] = []
        STATE["next_page"] = 1
        STATE["has_more"] = True
        STATE["category_terms"] = list(STATE.get("category_terms", []))
        STATE["category_usage_by_type"] = dict(STATE.get("category_usage_by_type", {}) or {})
        STATE["category_count_by_type"] = dict(STATE.get("category_count_by_type", {}) or {})
        STATE["display_slots"] = max(1, int(STATE.get("display_slots", 10) or 10))
        STATE["update_popup_version"] = ""
        STATE["update_info"] = dict(STATE.get("update_info", {}) or {})
        STATE["update_deferred_version"] = ""
    _redraw_view3d()



@persistent
def _load_post_restart(*_args):
    try:
        _reset_runtime_state_for_file_load()
    except Exception:
        pass

    def _deferred_restart():
        try:
            _reset_runtime_state_for_file_load()
        except Exception:
            pass
        try:
            _ensure_viewport_modal_running()
        except Exception:
            pass
        try:
            scene = getattr(bpy.context, "scene", None)
            settings = getattr(scene, "fourdesinno_browser", None) if scene is not None else None
            if settings is not None:
                _set_status("Preview strip ready.")
                try:
                    _process_completed_staged_update_notice()
                except Exception:
                    pass
                try:
                    bpy.app.timers.register(_refresh_category_cache_from_site, first_interval=1.0)
                except Exception:
                    pass
                try:
                    bpy.app.timers.register(_refresh_category_usage_cache_from_site, first_interval=1.3)
                except Exception:
                    pass
                try:
                    bpy.app.timers.register(_refresh_category_count_cache_from_site, first_interval=1.6)
                except Exception:
                    pass
        except Exception:
            pass
        _redraw_view3d()
        return None

    try:
        bpy.app.timers.register(_deferred_restart, first_interval=0.8)
    except Exception:
        pass
    return None




def _ensure_viewport_modal_running():
    try:
        with STATE_LOCK:
            modal_running = bool(STATE.get("modal_running", False))
            owner_area_ptr = STATE.get("strip_area_pointer")
            owner_win_ptr = STATE.get("strip_window_pointer")

        # Validate or recover owner pointers (handles closed viewports).
        try:
            owner_win_ptr, owner_area_ptr = _validate_or_reset_owner(None, None)
        except Exception:
            pass

        # If a modal is already running and owner pointers are valid, nothing to do.
        if modal_running and owner_area_ptr and owner_win_ptr:
            return None

        wm = bpy.context.window_manager
        if wm is None:
            return 0.5

        # Helper to invoke modal in a specific window/area
        def _invoke_in(window, area):
            region = None
            for r in area.regions:
                if r.type == 'WINDOW':
                    region = r
                    break
            if region is None:
                return False
            try:
                with bpy.context.temp_override(window=window, screen=window.screen, area=area, region=region):
                    result = bpy.ops.fourdesinno.viewport_browser_modal('INVOKE_DEFAULT')
                return (result == {'RUNNING_MODAL'} or result == {'FINISHED'})
            except Exception:
                return False

        # 1) Prefer starting in the owner viewport (so UI stays responsive after moving)
        if owner_area_ptr and owner_win_ptr:
            for window in wm.windows:
                if window.as_pointer() != owner_win_ptr:
                    continue
                screen = window.screen
                if not screen:
                    break
                for area in screen.areas:
                    if area.type != 'VIEW_3D':
                        continue
                    if area.as_pointer() == owner_area_ptr:
                        if _invoke_in(window, area):
                            return None
                        break
                break

        # 2) Fallback: first VIEW_3D we can find, and set it as owner
        for window in wm.windows:
            screen = window.screen
            if not screen:
                continue
            for area in screen.areas:
                if area.type != 'VIEW_3D':
                    continue
                if _invoke_in(window, area):
                    try:
                        with STATE_LOCK:
                            STATE["strip_area_pointer"] = area.as_pointer()
                            STATE["strip_window_pointer"] = window.as_pointer()
                    except Exception:
                        pass
                    return None
    except Exception:
        pass
    return 0.5

def _collapse_strip_for_all_scenes():
    try:
        for sc in bpy.data.scenes:
            try:
                sc.fourdesinno_browser.strip_expanded = False
            except Exception:
                pass
    except Exception:
        pass


def _on_load_post_collapse_strip(_dummy=None):
    _collapse_strip_for_all_scenes()

def register():
    _cleanup_legacy_old_addon_folder()
    global DRAW_HANDLE
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fourdesinno_browser = PointerProperty(type=F3D_BrowserSettings)
    _collapse_strip_for_all_scenes()
    try:
        if _on_load_post_collapse_strip not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(_on_load_post_collapse_strip)
    except Exception:
        pass
    try:
        bpy.context.scene.fourdesinno_browser.strip_expanded = False
        with STATE_LOCK:
            STATE["online_mode"] = bool(getattr(bpy.context.scene.fourdesinno_browser, "online_enabled", True))
    except Exception:
        pass
    _load_favorites()
    try:
        terms = _load_category_cache_from_disk()
        usage_map = _load_category_usage_cache_from_disk()
        count_map = _load_category_count_cache_from_disk()
        with STATE_LOCK:
            STATE["category_terms"] = list(terms)
            STATE["category_usage_by_type"] = dict(usage_map)
            STATE["category_count_by_type"] = dict(count_map)
        _sync_selected_category_filters(getattr(bpy.context.scene, "fourdesinno_browser", None), terms, usage_map=usage_map)
    except Exception:
        pass
    try:
        _reset_runtime_state_for_file_load()
    except Exception:
        pass
    if DRAW_HANDLE is None:
        DRAW_HANDLE = bpy.types.SpaceView3D.draw_handler_add(_draw_viewport_strip, (), 'WINDOW', 'POST_PIXEL')
    try:
        if _load_post_restart not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(_load_post_restart)
    except Exception:
        pass
    try:
        _process_completed_staged_update_notice()
    except Exception:
        pass
    try:
        bpy.app.timers.register(_ensure_viewport_modal_running, first_interval=0.5)
    except Exception:
        pass
    try:
        bpy.app.timers.register(_refresh_category_cache_from_site, first_interval=1.0)
    except Exception:
        pass
    try:
        bpy.app.timers.register(_refresh_category_usage_cache_from_site, first_interval=1.3)
    except Exception:
        pass
    try:
        bpy.app.timers.register(_refresh_category_count_cache_from_site, first_interval=1.6)
    except Exception:
        pass
    try:
        _schedule_update_check()
    except Exception:
        pass



def unregister():
    try:
        if _on_load_post_collapse_strip in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_on_load_post_collapse_strip)
    except Exception:
        pass
    global DRAW_HANDLE
    _cleanup_preview_dir()
    _clear_preview_runtime_cache()
    _clear_download()

    # stop recurring timers to avoid callbacks after addon unload
    try:
        for fn in (
            _ensure_viewport_modal_running,
            _refresh_category_cache_from_site,
            _refresh_category_usage_cache_from_site,
            _refresh_category_count_cache_from_site,
        ):
            try:
                if bpy.app.timers.is_registered(fn):
                    bpy.app.timers.unregister(fn)
            except Exception:
                pass
    except Exception:
        pass

    try:
        if _load_post_restart in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_load_post_restart)
    except Exception:
        pass
    if DRAW_HANDLE is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(DRAW_HANDLE, 'WINDOW')
        except Exception:
            pass
        DRAW_HANDLE = None
    if hasattr(bpy.types.Scene, "fourdesinno_browser"):
        del bpy.types.Scene.fourdesinno_browser
    with STATE_LOCK:
        STATE["modal_running"] = False
        STATE["assets"] = []
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

